#!/usr/bin/env python3
# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  ACHE_AUDITORIA_TOTAL.py  v2.0                                             ║
# ║  Auditoría profunda del ecosistema ACHE — COOPECRUCENOS R.L.               ║
# ║  Célula: GONZAGA-CBM-Ω-001 · La Cruz, Guanacaste, Costa Rica               ║
# ║                                                                              ║
# ║  EJECUCIÓN:                                                                 ║
# ║    python ACHE_AUDITORIA_TOTAL.py              → consola + HTML             ║
# ║    python ACHE_AUDITORIA_TOTAL.py --json       → también imprime JSON       ║
# ║    python ACHE_AUDITORIA_TOTAL.py --only-html  → solo genera HTML           ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

import os, sys, json, time, socket, hashlib, sqlite3, argparse, platform
import subprocess, threading, re
from pathlib import Path
from datetime import datetime, timezone

# ── ANSI ─────────────────────────────────────────────────────────────────────
class C:
    R="\033[0m"; B="\033[1m"; D="\033[2m"
    CY="\033[96m"; GR="\033[92m"; YL="\033[93m"; RD="\033[91m"
    BL="\033[94m"; MG="\033[95m"; WH="\033[97m"; AM="\033[33m"

def ok(t):   return f"{C.GR}  ✓  {t}{C.R}"
def warn(t): return f"{C.YL}  ⚠  {t}{C.R}"
def err(t):  return f"{C.RD}  ✕  {t}{C.R}"
def info(t): return f"{C.D}  ·  {t}{C.R}"
def head(t): return f"\n{C.BL}{'━'*72}{C.R}\n{C.CY}{C.B}  {t}{C.R}\n{C.BL}{'━'*72}{C.R}"

def _hr(b):
    for u in ["B","KB","MB","GB","TB"]:
        if b < 1024: return f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} PB"

NOW = datetime.now()

# ─────────────────────────────────────────────────────────────────────────────
# CONFIGURACIÓN ACHE
# ─────────────────────────────────────────────────────────────────────────────

SCAN_ROOTS = [
    Path("C:/ACHE"),
    Path("C:/"),
    Path.home(),
    Path.home() / "Desktop",
    Path.home() / "Documents",
    Path.home() / "Downloads",
    Path.cwd(),
]

ACHE_DIR_NAMES = [
    "ACHE","ACHE_UNIVERSAL","ACHE_NEXUS","ACHE_GENESIS","ACHE_META_FINAL",
    "ACHE_BRAIN","ACHE_MONEY","ACHE_MOBILE","ACHE_TRAILERO","ACHE_V7_STRATEGIC_CORE",
    "AURORA","NEXUS","NEPTUNO","EVA","GONZAGA","COOPECRUCENOS","LYRA",
    "ache","ache_v2_real","ache-lab","hotel_coopecrucenos","aurora-hotel",
]

ACHE_PORTS = {
    8080: "AURORA NEXUS / Flask Backend",
    5299: "ACHE_META_FINAL (Express)",
    5099: "ACHE_BRAIN (Express)",
    5600: "ACHE_UNIVERSAL",
    5700: "ACHE_FASE9",
    5800: "ACHE_FASE10",
    7777: "AURORA Suprema",
    9000: "NEXUS Cerebro",
    5000: "EVA / Drones ROS2",
    8090: "NEPTUNO Pacífico",
    3001: "ACHE Mobile / CBM",
    3000: "ACHE MONEY / Dev Server",
    3002: "ACHE MOBILE 2",
    5100: "ACHE Genesis Mother",
    5200: "ACHE Genesis Nodo 0",
    5201: "ACHE Genesis Nodo 1",
    5202: "ACHE Genesis Nodo 2",
    8000: "FastAPI / Uvicorn",
    4000: "Socket.IO",
    1883: "MQTT Broker",
    4040: "Ngrok Inspector",
    6333: "Qdrant VectorDB",
    6379: "Redis",
    5432: "PostgreSQL",
    27017: "MongoDB",
}

ACHE_KEY_FILES = {
    "backend_py":   ["boot.py","ache_universal.py","ache_core.py","ache_master.py",
                     "nexus.py","main.py","app.py","server.py","aurora.py"],
    "backend_js":   ["server.js","index.js","app.js","nexus.js"],
    "frontend":     ["ACHE_v6.html","ache_suprema.html","ACHE_NEXUS.html",
                     "ACHE_CONEXION_TOTAL_v1.html","ACHE_GENESIS_v1.html",
                     "ACHE_GENESIS.html","hotel_v6_final.html","ACHE_MADRE_GOVERNMENT.html",
                     "LYRA.html","hotel.html","nexus-bridge.html"],
    "config":       [".env","ache.env","ache_config.json","config.json",
                     "ache_genome.json","ache_genome_v2.json"],
    "genome_master":["MASTER.md","CLAUDE.md","README.md","genome.json"],
    "databases":    [],  # detected separately via glob *.db
    "scripts_ps1":  ["ACHE_BOOT.ps1","ACHE_AUTOSTART.ps1","ACHE_MASTER_BOOT.ps1",
                     "ACHE_STATUS.ps1","CREAR_ACHE_v6.ps1"],
    "scripts_py":   ["ache_status.py","ACHE_AUDITORIA_TOTAL.py","auto_programmer.py",
                     "ia_router.py","state_manager.py","cloud_bridge.py"],
}

API_KEY_VARS = [
    "ANTHROPIC_API_KEY","GROQ_API_KEY","OPENAI_API_KEY","OPENROUTER_API_KEY",
    "RAILWAY_TOKEN","GITHUB_TOKEN","CLOUDFLARE_API_TOKEN",
]

CRITICAL_PKGS_PY  = ["fastapi","uvicorn","flask","requests","anthropic",
                      "websockets","aiohttp","pydantic","sqlalchemy"]
CRITICAL_PKGS_NPM = ["express","cors","anthropic","dotenv","ws","axios"]

# ─────────────────────────────────────────────────────────────────────────────
# REPORTE GLOBAL
# ─────────────────────────────────────────────────────────────────────────────
R = {
    "meta":      {"ts": NOW.isoformat(), "version": "2.0", "entity": "COOPECRUCENOS R.L.", "cedula": "3-004-757068"},
    "system":    {},
    "tools":     {},
    "dirs":      [],
    "files":     {},
    "ports":     {},
    "processes": [],
    "databases": [],
    "git_repos": [],
    "node_pkgs": [],
    "api_keys":  {},
    "py_pkgs":   {},
    "issues":    [],
    "warnings":  [],
    "oks":       [],
    "score":     0,
}

# ─────────────────────────────────────────────────────────────────────────────
# 0. BANNER
# ─────────────────────────────────────────────────────────────────────────────
def banner():
    print(f"\n{C.CY}{'╔'+'═'*70+'╗'}")
    print(f"║{C.WH}{C.B}   ⬡  ACHE AUDITORÍA TOTAL v2.0{' '*41}{C.CY}║")
    print(f"║{C.D}   COOPECRUCENOS R.L. · 3-004-757068 · La Cruz, Guanacaste, CR{' '*8}{C.CY}║")
    print(f"║{C.D}   Célula: GONZAGA-CBM-Ω-001{' '*43}{C.CY}║")
    print(f"╚{'═'*70}╝{C.R}")
    print(f"{C.D}   {NOW.strftime('%A %d/%m/%Y  %H:%M:%S')}   ·   {platform.system()} {platform.release()}{C.R}\n")

# ─────────────────────────────────────────────────────────────────────────────
# 1. SISTEMA Y HERRAMIENTAS
# ─────────────────────────────────────────────────────────────────────────────
def scan_system():
    print(head("1/9  SISTEMA & HERRAMIENTAS"))
    u = platform.uname()
    R["system"] = {
        "os": f"{u.system} {u.release}", "machine": u.machine,
        "node": u.node, "python": platform.python_version(),
        "cwd": str(Path.cwd()), "home": str(Path.home()),
    }
    print(ok(f"OS:       {u.system} {u.release} ({u.machine})"))
    print(ok(f"Host:     {u.node}"))
    print(ok(f"Python:   {platform.python_version()}"))
    print(ok(f"CWD:      {Path.cwd()}"))

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close()
        print(ok(f"IP Local: {ip}")); R["system"]["ip"] = ip
    except:
        print(warn("IP Local: no determinada"))

    # Herramientas externas
    tools = {
        "node":    (["node", "--version"], r"v[\d.]+"),
        "npm":     (["npm",  "--version"], r"[\d.]+"),
        "git":     (["git",  "--version"], r"[\d.]+"),
        "ngrok":   (["ngrok", "version"],  r"[\d.]+"),
        "railway": (["railway", "--version"], r"[\d.]+"),
    }
    print()
    for name, (cmd, pat) in tools.items():
        try:
            out = subprocess.check_output(cmd, stderr=subprocess.DEVNULL,
                                          text=True, timeout=4).strip()
            m = re.search(pat, out)
            ver = m.group(0) if m else out[:20]
            print(ok(f"{name:<10} {ver}"))
            R["tools"][name] = ver
        except:
            print(warn(f"{name:<10} no encontrado / no en PATH"))
            R["tools"][name] = None
    print()

# ─────────────────────────────────────────────────────────────────────────────
# 2. DIRECTORIOS ACHE
# ─────────────────────────────────────────────────────────────────────────────
def scan_dirs():
    print(head("2/9  DIRECTORIOS ACHE"))
    found = {}
    searched = set()

    # Buscar desde raíces comunes
    search_paths = [
        Path("C:/"),
        Path.home(),
        Path.home() / "Desktop",
        Path.home() / "Documents",
        Path.home() / "Downloads",
        Path.home() / "dev",
        Path.home() / "Projects",
        Path.cwd(),
    ]

    for root in search_paths:
        if not root.exists() or root in searched:
            continue
        searched.add(root)
        try:
            # Nivel 1 y 2 solamente (rápido)
            for p in root.iterdir():
                if not p.is_dir(): continue
                if any(name.lower() in p.name.lower() for name in ACHE_DIR_NAMES):
                    if str(p) not in found:
                        found[str(p)] = p
                # Nivel 2
                try:
                    for p2 in p.iterdir():
                        if not p2.is_dir(): continue
                        if any(name.lower() == p2.name.lower() for name in ACHE_DIR_NAMES):
                            if str(p2) not in found:
                                found[str(p2)] = p2
                except (PermissionError, OSError):
                    pass
        except (PermissionError, OSError):
            pass

    if not found:
        print(warn("No se encontraron directorios ACHE en rutas estándar"))
        R["issues"].append("Ningún directorio ACHE encontrado")
        return

    total_size = 0
    for path_str, path in sorted(found.items()):
        try:
            files = [f for f in path.rglob("*") if f.is_file()]
            fcount = len(files)
            size = sum(f.stat().st_size for f in files if f.exists())
            last_mod_ts = max((f.stat().st_mtime for f in files), default=0)
            last_mod = datetime.fromtimestamp(last_mod_ts).strftime("%d/%m/%Y %H:%M") if last_mod_ts else "?"
            total_size += size
            print(ok(f"{path}"))
            print(info(f"     {fcount:>5} archivos  ·  {_hr(size):>10}  ·  Último cambio: {last_mod}"))
            R["dirs"].append({
                "path": path_str, "files": fcount,
                "size_bytes": size, "last_modified": last_mod
            })
        except Exception as e:
            print(warn(f"{path}  (error al leer: {e})"))

    print()
    print(ok(f"Total directorios ACHE: {len(found)}  ·  Tamaño acumulado: {_hr(total_size)}"))
    if len(found) > 10:
        print(warn(f"Hay {len(found)} directorios ACHE — considera consolidar"))
        R["warnings"].append(f"{len(found)} directorios ACHE fragmentados")
    print()

# ─────────────────────────────────────────────────────────────────────────────
# 3. ARCHIVOS CLAVE
# ─────────────────────────────────────────────────────────────────────────────
def scan_files():
    print(head("3/9  ARCHIVOS CLAVE ACHE"))

    search_roots_files = [Path("C:/ACHE"), Path.home(), Path.cwd()]

    EXCLUDE = {".git","node_modules",".cache","__pycache__","venv",".venv","dist","build"}

    def find_file(name):
        results = []
        for root in search_roots_files:
            if not root.exists(): continue
            try:
                for p in root.rglob(name):
                    parts = set(p.parts)
                    if p.is_file() and not parts & EXCLUDE:
                        results.append(p)
            except (PermissionError, OSError):
                pass
        return results

    total_found = 0
    for category, names in ACHE_KEY_FILES.items():
        if category == "databases": continue
        cat_hits = []
        for name in names:
            hits = find_file(name)
            cat_hits.extend(hits)

        cat_hits = list({str(p): p for p in cat_hits}.values())

        label = category.replace("_", " ").upper()
        if cat_hits:
            print(f"\n  {C.AM}[{label}]{C.R}")
            for p in cat_hits:
                try:
                    sz = p.stat().st_size
                    mt = datetime.fromtimestamp(p.stat().st_mtime).strftime("%d/%m/%Y %H:%M")
                    print(ok(f"  {p.name}"))
                    print(info(f"       {p}  ·  {_hr(sz)}  ·  {mt}"))
                    total_found += 1
                    R["files"].setdefault(category, []).append({
                        "name": p.name, "path": str(p),
                        "size": sz, "modified": mt
                    })
                except:
                    pass
        else:
            print(f"\n  {C.D}[{label}]{C.R}")
            print(warn(f"  Sin archivos encontrados"))
            if category in ("backend_py", "genome_master"):
                R["issues"].append(f"Archivos faltantes: {label}")

    # Buscar .env files especialmente
    print(f"\n  {C.AM}[ENV / CONFIG]{C.R}")
    for root in [Path("C:/ACHE"), Path.home()]:
        if not root.exists(): continue
        try:
            for p in root.rglob(".env"):
                if "node_modules" not in str(p):
                    sz = p.stat().st_size
                    print(ok(f"  .env → {p}  ({_hr(sz)})"))
                    R["files"].setdefault("env", []).append({"path": str(p), "size": sz})
        except: pass
    print()

# ─────────────────────────────────────────────────────────────────────────────
# 4. PUERTOS / SERVICIOS
# ─────────────────────────────────────────────────────────────────────────────
def scan_ports():
    print(head("4/9  PUERTOS / SERVICIOS"))
    results = {}
    lock = threading.Lock()

    def chk(port):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(0.4)
            ok_res = s.connect_ex(("localhost", port)) == 0
            s.close()
        except:
            ok_res = False
        with lock:
            results[port] = ok_res

    threads = [threading.Thread(target=chk, args=(p,)) for p in ACHE_PORTS]
    for t in threads: t.start()
    for t in threads: t.join(timeout=3)

    activos = 0
    for port, label in sorted(ACHE_PORTS.items()):
        up = results.get(port, False)
        if up:
            print(ok(f":{port:<6} {label}  [ACTIVO]"))
            R["ports"][port] = {"label": label, "status": "ACTIVO"}
            activos += 1
        else:
            print(info(f":{port:<6} {label}  [offline]"))
            R["ports"][port] = {"label": label, "status": "offline"}

    print()
    if activos > 0:
        print(ok(f"{activos} servicio(s) activo(s) en localhost"))
        R["oks"].append(f"{activos} puertos ACHE activos")
    else:
        print(warn("Ningún servicio ACHE está corriendo"))
        R["issues"].append("Ningún puerto ACHE activo — ejecutar ACHE_BOOT.ps1")
    print()

# ─────────────────────────────────────────────────────────────────────────────
# 5. PROCESOS
# ─────────────────────────────────────────────────────────────────────────────
def scan_processes():
    print(head("5/9  PROCESOS EN EJECUCIÓN"))
    KEYWORDS = ["python","python3","uvicorn","node","npm","flask",
                 "fastapi","ngrok","mosquitto","pwsh","railway"]
    procs = []

    try:
        if platform.system() == "Windows":
            # wmic para obtener info completa del proceso
            out = subprocess.check_output(
                ["wmic","process","get","ProcessId,Name,CommandLine","/format:csv"],
                text=True, stderr=subprocess.DEVNULL, timeout=10
            )
            for line in out.splitlines():
                parts = line.split(",", 2)
                if len(parts) < 3: continue
                cmd, name, pid = parts[0], parts[1], parts[2]
                name_l = name.lower()
                if any(k in name_l for k in KEYWORDS):
                    if "ACHE_AUDITORIA" not in cmd and "wmic" not in cmd:
                        procs.append({"name": name, "pid": pid.strip(), "cmd": cmd[:100]})
        else:
            out = subprocess.check_output(
                ["ps","auxww"], text=True, stderr=subprocess.DEVNULL, timeout=5
            )
            for line in out.splitlines()[1:]:
                parts = line.split(None, 10)
                if len(parts) < 11: continue
                cmd = parts[10].lower()
                if any(k in cmd for k in KEYWORDS) and "ACHE_AUDITORIA" not in cmd:
                    procs.append({"name": parts[10][:40], "pid": parts[1], "cmd": parts[10][:100]})
    except Exception as e:
        print(warn(f"No se pudo leer procesos: {e}"))

    seen = set()
    for p in procs:
        pid = p.get("pid", "")
        if pid in seen: continue
        seen.add(pid)
        print(ok(f"PID {pid:>6}  {p['name']:<20}  {p['cmd'][:60]}"))
        R["processes"].append(p)

    if not seen:
        print(warn("Sin procesos Python/Node detectados — servicios offline"))
        R["issues"].append("Ningún proceso ACHE en ejecución")
    print()

# ─────────────────────────────────────────────────────────────────────────────
# 6. BASES DE DATOS SQLITE
# ─────────────────────────────────────────────────────────────────────────────
def scan_databases():
    print(head("6/9  BASES DE DATOS SQLite (MEMORIA ACHE)"))
    SKIP_DB = {".cache","node_modules","__pycache__","AppData","uv"}
    db_files = []
    for root in [Path("C:/ACHE"), Path.home(), Path.cwd()]:
        if not root.exists(): continue
        try:
            for p in root.rglob("*.db"):
                parts = set(p.parts)
                if not parts & SKIP_DB:
                    db_files.append(p)
        except: pass
    db_files = list({str(p): p for p in db_files}.values())

    if not db_files:
        print(warn("No se encontraron archivos .db"))
        R["issues"].append("Sin bases de datos SQLite encontradas")
        return

    for db in db_files:
        try:
            sz = db.stat().st_size
            mt = datetime.fromtimestamp(db.stat().st_mtime).strftime("%d/%m/%Y %H:%M")
            conn = sqlite3.connect(str(db), timeout=2)
            tables = [row[0] for row in
                      conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
            row_counts = {}
            for t in tables:
                try:
                    cnt = conn.execute(f"SELECT COUNT(*) FROM [{t}]").fetchone()[0]
                    row_counts[t] = cnt
                except: row_counts[t] = "?"
            conn.close()
            print(ok(f"{db.name}  ({_hr(sz)})  ·  {mt}"))
            print(info(f"     Ruta: {db}"))
            for t, c in row_counts.items():
                print(info(f"     tabla [{t}] → {c} filas"))
            R["databases"].append({
                "path": str(db), "size": sz, "modified": mt,
                "tables": row_counts
            })
        except Exception as e:
            print(warn(f"{db}  (error: {e})"))
    print()

# ─────────────────────────────────────────────────────────────────────────────
# 7. REPOSITORIOS GIT
# ─────────────────────────────────────────────────────────────────────────────
def scan_git():
    print(head("7/9  REPOSITORIOS GIT"))
    git_dirs = []
    SKIP_GIT = {".cache","__pycache__","node_modules","venv",".venv","AppData","uv"}
    for root in [Path("C:/ACHE"), Path.home(), Path.cwd()]:
        if not root.exists(): continue
        try:
            for p in root.rglob(".git"):
                if p.is_dir():
                    parts = set(p.parent.parts)
                    if not parts & SKIP_GIT:
                        git_dirs.append(p.parent)
        except: pass
    git_dirs = list({str(p): p for p in git_dirs}.values())

    if not git_dirs:
        print(warn("No se encontraron repositorios Git en rutas ACHE"))
        R["warnings"].append("Sin repositorios Git — considera versionar el código")
        return

    for repo in git_dirs:
        try:
            # branch actual
            branch = subprocess.check_output(
                ["git","-C",str(repo),"branch","--show-current"],
                text=True, stderr=subprocess.DEVNULL, timeout=3
            ).strip() or "detached"

            # último commit
            last = subprocess.check_output(
                ["git","-C",str(repo),"log","-1","--format=%h %s (%ar)"],
                text=True, stderr=subprocess.DEVNULL, timeout=3
            ).strip()

            # archivos sin commit
            status = subprocess.check_output(
                ["git","-C",str(repo),"status","--short"],
                text=True, stderr=subprocess.DEVNULL, timeout=3
            ).strip()
            dirty = len(status.splitlines()) if status else 0

            # remote
            try:
                remote = subprocess.check_output(
                    ["git","-C",str(repo),"remote","get-url","origin"],
                    text=True, stderr=subprocess.DEVNULL, timeout=3
                ).strip()
            except:
                remote = "sin remote"

            color = C.YL if dirty > 0 else C.GR
            sym   = "⚠" if dirty > 0 else "✓"
            print(f"  {color}{sym}  {repo}{C.R}")
            print(info(f"     Branch: {branch}  ·  Remote: {remote}"))
            print(info(f"     Último commit: {last}"))
            if dirty > 0:
                print(warn(f"     {dirty} archivo(s) sin commitear"))
            R["git_repos"].append({
                "path": str(repo), "branch": branch, "remote": remote,
                "last_commit": last, "dirty_files": dirty
            })
        except Exception as e:
            print(warn(f"  {repo}  (error git: {e})"))
    print()

# ─────────────────────────────────────────────────────────────────────────────
# 8. PAQUETES PYTHON & NODE
# ─────────────────────────────────────────────────────────────────────────────
def scan_packages():
    print(head("8/9  PAQUETES PYTHON & NODE.JS"))

    # Python
    print(f"  {C.AM}[Python packages críticos]{C.R}")
    try:
        out = subprocess.check_output(
            [sys.executable, "-m", "pip", "list", "--format=json"],
            text=True, stderr=subprocess.DEVNULL, timeout=15
        )
        installed = {pkg["name"].lower(): pkg["version"] for pkg in json.loads(out)}
        for pkg in CRITICAL_PKGS_PY:
            ver = installed.get(pkg.lower())
            if ver:
                print(ok(f"  {pkg:<20} {ver}"))
                R["py_pkgs"][pkg] = ver
            else:
                print(warn(f"  {pkg:<20} NO INSTALADO"))
                R["py_pkgs"][pkg] = None
                R["warnings"].append(f"Paquete Python faltante: {pkg}")
    except Exception as e:
        print(warn(f"  No se pudo consultar pip: {e}"))

    # Node / package.json
    print(f"\n  {C.AM}[Node.js — package.json detectados]{C.R}")
    pkgjsons = []
    for root in [Path("C:/ACHE"), Path.home(), Path.cwd()]:
        if not root.exists(): continue
        try:
            for p in root.rglob("package.json"):
                if "node_modules" not in str(p):
                    pkgjsons.append(p)
        except: pass

    if pkgjsons:
        for pj in pkgjsons[:10]:  # max 10
            try:
                data = json.loads(pj.read_text(encoding="utf-8", errors="ignore"))
                name = data.get("name","?")
                ver  = data.get("version","?")
                deps = list(data.get("dependencies",{}).keys())
                print(ok(f"  {pj.parent.name}/{pj.name}  →  {name} v{ver}"))
                print(info(f"     Deps: {', '.join(deps[:6])}{'...' if len(deps)>6 else ''}"))
                R["node_pkgs"].append({"path": str(pj), "name": name, "deps": deps})
            except:
                print(info(f"  {pj}  (error al leer)"))
    else:
        print(warn("  No se encontraron package.json en rutas ACHE"))
    print()

# ─────────────────────────────────────────────────────────────────────────────
# 9. API KEYS & VARIABLES DE ENTORNO
# ─────────────────────────────────────────────────────────────────────────────
def scan_api_keys():
    print(head("9/9  API KEYS & VARIABLES DE ENTORNO"))

    # Desde env del sistema
    for key in API_KEY_VARS:
        val = os.environ.get(key) or os.environ.get(key.upper())
        if val and len(val) > 6:
            masked = val[:8] + "..." + val[-4:]
            print(ok(f"  {key:<30} [{masked}]"))
            R["api_keys"][key] = "SET"
        else:
            print(warn(f"  {key:<30} [NO CONFIGURADA]"))
            R["api_keys"][key] = "MISSING"
            if key in ("ANTHROPIC_API_KEY","GROQ_API_KEY"):
                R["issues"].append(f"API Key crítica faltante: {key}")

    # Buscar en archivos .env
    print()
    print(f"  {C.D}Buscando keys en archivos .env y ache.env ...{C.R}")
    env_files = []
    for root in [Path("C:/ACHE"), Path.home(), Path.cwd()]:
        if not root.exists(): continue
        try:
            env_files += list(root.rglob(".env")) + list(root.rglob("ache.env"))
        except: pass

    found_in_files = {}
    for ef in env_files:
        if "node_modules" in str(ef): continue
        try:
            for line in ef.read_text(errors="ignore").splitlines():
                line = line.strip()
                if "=" in line and not line.startswith("#"):
                    k, _, v = line.partition("=")
                    k = k.strip()
                    if k in API_KEY_VARS and v.strip():
                        found_in_files[k] = ef
        except: pass

    if found_in_files:
        for k, ef in found_in_files.items():
            print(ok(f"  {k} encontrada en archivo: {ef}"))
    else:
        print(warn("  No se encontraron keys en archivos .env"))
    print()

# ─────────────────────────────────────────────────────────────────────────────
# RESUMEN FINAL
# ─────────────────────────────────────────────────────────────────────────────
def print_summary():
    # Calcular score
    score = 10
    score -= min(len(R["issues"]) * 2, 6)
    score -= min(len(R["warnings"]) * 1, 3)
    score = max(0, min(10, score))
    R["score"] = score

    bar_color = C.GR if score >= 7 else C.YL if score >= 4 else C.RD
    bar = "█" * score + "░" * (10 - score)

    print(f"\n{C.BL}{'═'*72}{C.R}")
    print(f"{C.CY}{C.B}  RESUMEN DE AUDITORÍA — ACHE ECOSYSTEM{C.R}")
    print(f"{C.BL}{'═'*72}{C.R}")
    print(f"  {bar_color}{C.B}SALUD DEL ECOSISTEMA: [{bar}] {score}/10{C.R}")
    print()

    if R["oks"]:
        print(f"  {C.GR}✓ Todo correcto:{C.R}")
        for o in R["oks"]:
            print(ok(f"  {o}"))
        print()

    if R["warnings"]:
        print(f"  {C.YL}⚠ Advertencias:{C.R}")
        for w in R["warnings"]:
            print(warn(f"  {w}"))
        print()

    if R["issues"]:
        print(f"  {C.RD}✕ Problemas críticos:{C.R}")
        for i in R["issues"]:
            print(err(f"  {i}"))
        print()

    print(f"  {C.D}Directorios ACHE encontrados: {len(R['dirs'])}{C.R}")
    print(f"  {C.D}Servicios activos: {sum(1 for v in R['ports'].values() if v['status']=='ACTIVO')} / {len(R['ports'])}{C.R}")
    print(f"  {C.D}Procesos en ejecución: {len(R['processes'])}{C.R}")
    print(f"  {C.D}Bases de datos encontradas: {len(R['databases'])}{C.R}")
    print(f"  {C.D}Repositorios Git: {len(R['git_repos'])}{C.R}")
    print(f"  {C.D}API Keys configuradas: {sum(1 for v in R['api_keys'].values() if v=='SET')} / {len(R['api_keys'])}{C.R}")
    print()

# ─────────────────────────────────────────────────────────────────────────────
# REPORTE HTML
# ─────────────────────────────────────────────────────────────────────────────
def export_html():
    score = R["score"]
    bar = "█" * score + "░" * (10 - score)
    color = "#00ff88" if score >= 7 else "#ffb300" if score >= 4 else "#ff5252"
    ts = NOW.strftime("%d/%m/%Y %H:%M:%S")

    def rows(items, keys, colors=None):
        out = ""
        for item in items:
            cls = ""
            if colors:
                for col_key, col_val, col_class in colors:
                    if item.get(col_key) == col_val:
                        cls = col_class
            tds = "".join(f"<td>{item.get(k,'')}</td>" for k in keys)
            out += f"<tr class='{cls}'>{tds}</tr>"
        return out or "<tr><td colspan='99' style='color:#4a7090'>Sin datos</td></tr>"

    ports_rows = "".join(
        f"<tr class='{'ok' if v['status']=='ACTIVO' else 'dim'}'>"
        f"<td>:{k}</td><td>{v['label']}</td><td>{v['status']}</td></tr>"
        for k, v in sorted(R["ports"].items(), key=lambda x: int(x[0]))
    )
    dirs_rows = rows(R["dirs"], ["path","files","size_bytes","last_modified"])
    db_rows = "".join(
        f"<tr><td>{Path(d['path']).name}</td><td>{_hr(d['size'])}</td>"
        f"<td>{', '.join(f'{t}({c})' for t,c in d['tables'].items())}</td></tr>"
        for d in R["databases"]
    ) or "<tr><td colspan='3' style='color:#4a7090'>Sin bases de datos</td></tr>"
    git_rows = "".join(
        f"<tr class='{'warn' if g['dirty_files']>0 else 'ok'}'>"
        f"<td>{Path(g['path']).name}</td><td>{g['branch']}</td>"
        f"<td>{g['remote'][:40]}</td><td>{g['dirty_files']} sin commit</td></tr>"
        for g in R["git_repos"]
    ) or "<tr><td colspan='4' style='color:#4a7090'>Sin repos Git</td></tr>"
    apikeys_rows = "".join(
        f"<tr class='{'ok' if v=='SET' else 'err'}'>"
        f"<td>{k}</td><td>{'✓ Configurada' if v=='SET' else '✕ Faltante'}</td></tr>"
        for k, v in R["api_keys"].items()
    )
    pypkgs_rows = "".join(
        f"<tr class='{'ok' if v else 'err'}'>"
        f"<td>{k}</td><td>{v or '✕ No instalado'}</td></tr>"
        for k, v in R["py_pkgs"].items()
    )
    issues_html = "".join(f"<li class='err'>✕ {i}</li>" for i in R["issues"]) or "<li class='ok'>✓ Sin problemas críticos</li>"
    warns_html  = "".join(f"<li class='warn'>⚠ {w}</li>" for w in R["warnings"]) or "<li class='ok'>✓ Sin advertencias</li>"
    oks_html    = "".join(f"<li class='ok'>✓ {o}</li>" for o in R["oks"]) or ""
    procs_rows  = "".join(
        f"<tr><td>{p.get('pid','')}</td><td>{p.get('name','')[:30]}</td><td>{p.get('cmd','')[:60]}</td></tr>"
        for p in R["processes"]
    ) or "<tr><td colspan='3' style='color:#4a7090'>Sin procesos activos</td></tr>"
    tools_rows  = "".join(
        f"<tr class='{'ok' if v else 'dim'}'><td>{k}</td><td>{v or '— no encontrado'}</td></tr>"
        for k, v in R["tools"].items()
    )

    html = f"""<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>ACHE Auditoría Total — {ts}</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@700;900&family=JetBrains+Mono:wght@400;500;700&family=Rajdhani:wght@400;500;700&display=swap" rel="stylesheet">
<style>
:root{{
  --bg:#020c10;--surf:#061820;--card:#091c28;--bdr:#163550;
  --cyan:#00e5ff;--grn:#00ff88;--amber:#ffb300;--red:#ff5252;
  --mut:#3a6080;--text:#c8e8f8;--text2:#7aaccc;
}}
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:'Rajdhani',sans-serif;background:var(--bg);color:var(--text);padding:20px 28px;font-size:14px;line-height:1.5}}
h1{{font-family:'Orbitron',monospace;font-size:17px;color:var(--cyan);letter-spacing:3px;text-transform:uppercase}}
.meta{{font-size:11px;color:var(--mut);font-family:'JetBrains Mono',monospace;margin:4px 0 24px}}
.score-bar{{font-family:'JetBrains Mono',monospace;font-size:22px;color:{color};letter-spacing:2px;margin:6px 0 2px}}
.score-label{{font-size:11px;color:var(--mut)}}
.hero{{background:var(--card);border:1px solid var(--bdr);border-radius:12px;padding:20px 24px;margin-bottom:20px;display:flex;gap:40px;align-items:center;flex-wrap:wrap}}
.stat{{text-align:center}}
.stat .num{{font-family:'Orbitron',monospace;font-size:28px;font-weight:900;color:var(--cyan)}}
.stat .lbl{{font-size:10px;color:var(--mut);text-transform:uppercase;letter-spacing:1px}}
.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:14px}}
.card{{background:var(--card);border:1px solid var(--bdr);border-radius:10px;padding:16px;overflow:hidden}}
.card h2{{font-family:'Orbitron',monospace;font-size:9px;color:var(--amber);letter-spacing:2px;text-transform:uppercase;margin-bottom:12px;border-bottom:1px solid var(--bdr);padding-bottom:8px}}
table{{width:100%;border-collapse:collapse;font-size:11px;font-family:'JetBrains Mono',monospace}}
td,th{{padding:4px 7px;text-align:left;border-bottom:1px solid rgba(22,53,80,.5)}}
th{{font-size:9px;color:var(--mut);font-weight:400;letter-spacing:.5px}}
tr:last-child td{{border-bottom:none}}
tr.ok td{{color:var(--grn)}}
tr.err td{{color:var(--red)}}
tr.warn td{{color:var(--amber)}}
tr.dim td{{color:var(--mut)}}
ul.issues{{list-style:none;font-size:11px;font-family:'JetBrains Mono',monospace}}
ul.issues li{{padding:5px 0;border-bottom:1px solid rgba(22,53,80,.4)}}
ul.issues li:last-child{{border-bottom:none}}
.ok{{color:var(--grn)}} .err{{color:var(--red)}} .warn{{color:var(--amber)}}
.full{{grid-column:1/-1}}
pre{{font-size:9px;color:var(--mut);overflow:auto;max-height:180px;font-family:'JetBrains Mono',monospace;margin-top:8px}}
.footer{{margin-top:24px;font-size:10px;color:var(--mut);font-family:'JetBrains Mono',monospace;text-align:center;border-top:1px solid var(--bdr);padding-top:12px}}
@media(max-width:700px){{.grid{{grid-template-columns:1fr}}.full{{grid-column:1}}}}
</style>
</head>
<body>
<h1>⬡ ACHE Auditoría Total</h1>
<div class="meta">COOPECRUCENOS R.L. · 3-004-757068 · La Cruz, Guanacaste, CR · {R['meta']['ts']} · Célula: {R['system'].get('node','?')}</div>

<div class="hero">
  <div>
    <div class="score-bar">[{bar}]</div>
    <div class="score-label">Salud del ecosistema: {score}/10</div>
  </div>
  <div class="stat"><div class="num">{len(R['dirs'])}</div><div class="lbl">Directorios ACHE</div></div>
  <div class="stat"><div class="num">{sum(1 for v in R['ports'].values() if v['status']=='ACTIVO')}</div><div class="lbl">Puertos activos</div></div>
  <div class="stat"><div class="num">{len(R['processes'])}</div><div class="lbl">Procesos</div></div>
  <div class="stat"><div class="num">{len(R['databases'])}</div><div class="lbl">Bases de datos</div></div>
  <div class="stat"><div class="num">{sum(1 for v in R['api_keys'].values() if v=='SET')}/{len(R['api_keys'])}</div><div class="lbl">API Keys</div></div>
  <div class="stat"><div class="num">{len(R['git_repos'])}</div><div class="lbl">Repos Git</div></div>
</div>

<div class="grid">

<div class="card">
  <h2>Diagnóstico — Problemas críticos</h2>
  <ul class="issues">{issues_html}</ul>
</div>

<div class="card">
  <h2>Advertencias & OK</h2>
  <ul class="issues">{warns_html}{oks_html}</ul>
</div>

<div class="card">
  <h2>Puertos / Servicios ACHE</h2>
  <table><tr><th>Puerto</th><th>Servicio</th><th>Estado</th></tr>{ports_rows}</table>
</div>

<div class="card">
  <h2>API Keys & Variables</h2>
  <table><tr><th>Variable</th><th>Estado</th></tr>{apikeys_rows}</table>
</div>

<div class="card">
  <h2>Procesos en ejecución</h2>
  <table><tr><th>PID</th><th>Nombre</th><th>Comando</th></tr>{procs_rows}</table>
</div>

<div class="card">
  <h2>Herramientas del sistema</h2>
  <table><tr><th>Herramienta</th><th>Versión</th></tr>{tools_rows}</table>
</div>

<div class="card full">
  <h2>Directorios ACHE detectados</h2>
  <table><tr><th>Ruta</th><th>Archivos</th><th>Tamaño</th><th>Último cambio</th></tr>{dirs_rows}</table>
</div>

<div class="card">
  <h2>Bases de datos SQLite</h2>
  <table><tr><th>Archivo</th><th>Tamaño</th><th>Tablas (filas)</th></tr>{db_rows}</table>
</div>

<div class="card">
  <h2>Repositorios Git</h2>
  <table><tr><th>Repo</th><th>Branch</th><th>Remote</th><th>Estado</th></tr>{git_rows}</table>
</div>

<div class="card">
  <h2>Paquetes Python críticos</h2>
  <table><tr><th>Paquete</th><th>Versión</th></tr>{pypkgs_rows}</table>
</div>

<div class="card full">
  <h2>JSON completo del reporte</h2>
  <pre>{json.dumps(R, indent=2, ensure_ascii=False)[:4000]}...</pre>
</div>

</div>
<div class="footer">
  ACHE Auditoría Total v2.0 · Generado el {ts} · COOPECRUCENOS R.L. · 3-004-757068
  <br>Ejecutar: <code>python ACHE_AUDITORIA_TOTAL.py</code> · Abrir HTML para ver este reporte
</div>
</body>
</html>"""

    out_name = f"ACHE_AUDITORIA_{NOW.strftime('%Y%m%d_%H%M%S')}.html"
    out_path = Path.cwd() / out_name
    out_path.write_text(html, encoding="utf-8")
    print(ok(f"Reporte HTML generado: {out_path.resolve()}"))
    return out_path

# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser(description="ACHE Auditoría Total v2.0")
    ap.add_argument("--json",       action="store_true", help="Imprimir JSON al final")
    ap.add_argument("--only-html",  action="store_true", help="Saltar consola, solo HTML")
    args = ap.parse_args()

    banner()

    if not args.only_html:
        scan_system()
        scan_dirs()
        scan_files()
        scan_ports()
        scan_processes()
        scan_databases()
        scan_git()
        scan_packages()
        scan_api_keys()
        print_summary()
    else:
        # Correr todo silencioso para el HTML
        import io, contextlib
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            scan_system(); scan_dirs(); scan_files(); scan_ports()
            scan_processes(); scan_databases(); scan_git()
            scan_packages(); scan_api_keys(); print_summary()

    html_path = export_html()

    # Intentar abrir en navegador
    try:
        import webbrowser
        webbrowser.open(html_path.as_uri())
        print(info("Abriendo reporte en navegador..."))
    except: pass

    # Guardar JSON
    json_path = Path.cwd() / f"ACHE_AUDITORIA_{NOW.strftime('%Y%m%d_%H%M%S')}.json"
    json_path.write_text(json.dumps(R, indent=2, ensure_ascii=False), encoding="utf-8")
    print(info(f"JSON guardado: {json_path}"))

    if args.json:
        print(json.dumps(R, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
