# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  ACHE_AUDITAR.ps1 — Launcher de Auditoría Total                            ║
# ║  COOPECRUCENOS R.L. · La Cruz, Guanacaste, Costa Rica                      ║
# ║  Compatible con PowerShell 5.1 — GONZAGA-CBM-Ω-001                        ║
# ║                                                                              ║
# ║  USO (como usuario normal, sin Admin requerido):                            ║
# ║    .\ACHE_AUDITAR.ps1              → Auditoría completa                    ║
# ║    .\ACHE_AUDITAR.ps1 -SoloHTML   → Solo genera HTML sin output consola    ║
# ║    .\ACHE_AUDITAR.ps1 -JSON       → Incluye JSON al final                  ║
# ║    .\ACHE_AUDITAR.ps1 -Instalar   → Copia script a C:\ACHE\ automático     ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

param(
    [switch]$SoloHTML,
    [switch]$JSON,
    [switch]$Instalar
)

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force -ErrorAction SilentlyContinue

# ── COLORES ─────────────────────────────────────────────────────────────────
function Write-Ok($m)   { Write-Host "  [OK]  $m" -ForegroundColor Green }
function Write-Err($m)  { Write-Host "  [!!]  $m" -ForegroundColor Red }
function Write-Info($m) { Write-Host "  [--]  $m" -ForegroundColor DarkGray }
function Write-Warn($m) { Write-Host "  [>>]  $m" -ForegroundColor Yellow }
function Write-Head($m) { Write-Host "`n  $m" -ForegroundColor Cyan }
function Write-Sep      { Write-Host ("═" * 68) -ForegroundColor DarkBlue }

# ── BANNER ─────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ⬡  ACHE AUDITOR — Launcher v2.0" -ForegroundColor Cyan
Write-Host "  COOPECRUCENOS R.L. · GONZAGA-CBM-001" -ForegroundColor DarkGray
Write-Host "  $(Get-Date -Format 'dddd dd/MM/yyyy HH:mm:ss')" -ForegroundColor DarkGray
Write-Sep

# ── MODO INSTALAR ─────────────────────────────────────────────────────────
if ($Instalar) {
    Write-Head "INSTALANDO AUDITOR EN C:\ACHE\"

    $dest = "C:\ACHE"
    if (-not (Test-Path $dest)) {
        New-Item -ItemType Directory -Path $dest -Force | Out-Null
        Write-Ok "Carpeta C:\ACHE\ creada"
    }

    $scriptSrc = Join-Path $PSScriptRoot "ACHE_AUDITORIA_TOTAL.py"
    $launcherSrc = $PSCommandPath

    if (Test-Path $scriptSrc) {
        Copy-Item $scriptSrc "$dest\ACHE_AUDITORIA_TOTAL.py" -Force
        Write-Ok "ACHE_AUDITORIA_TOTAL.py copiado a $dest\"
    } else {
        Write-Err "No se encontro ACHE_AUDITORIA_TOTAL.py en la misma carpeta"
        Write-Warn "Asegurate de que ACHE_AUDITAR.ps1 y ACHE_AUDITORIA_TOTAL.py esten en la misma carpeta"
        exit 1
    }

    Copy-Item $launcherSrc "$dest\ACHE_AUDITAR.ps1" -Force
    Write-Ok "ACHE_AUDITAR.ps1 copiado a $dest\"

    Write-Sep
    Write-Ok "Instalacion completada."
    Write-Info "Ahora puedes correr: cd C:\ACHE; .\ACHE_AUDITAR.ps1"
    exit 0
}

# ── VERIFICAR PYTHON ──────────────────────────────────────────────────────
Write-Head "VERIFICANDO ENTORNO"
Write-Sep

$pythonCmd = $null

# Buscar python en orden de preferencia
$pythonCandidates = @("python", "python3", "py")
foreach ($candidate in $pythonCandidates) {
    $found = Get-Command $candidate -ErrorAction SilentlyContinue
    if ($found -ne $null) {
        try {
            $ver = & $candidate --version 2>&1
            if ($ver -match "Python 3") {
                $pythonCmd = $candidate
                Write-Ok "Python encontrado: $candidate ($ver)"
                break
            }
        } catch {}
    }
}

if ($pythonCmd -eq $null) {
    Write-Err "Python 3 no encontrado en PATH"
    Write-Warn "Instala Python desde: https://python.org"
    Write-Warn "O verifica que Python este en tu PATH del sistema"
    exit 1
}

# ── BUSCAR EL SCRIPT PYTHON ────────────────────────────────────────────────
$scriptName = "ACHE_AUDITORIA_TOTAL.py"
$searchPaths = @(
    (Join-Path $PSScriptRoot $scriptName),
    "C:\ACHE\$scriptName",
    "C:\ACHE_UNIVERSAL\$scriptName",
    (Join-Path $env:USERPROFILE "Desktop\$scriptName"),
    (Join-Path $env:USERPROFILE "$scriptName"),
    (Join-Path (Get-Location) $scriptName)
)

$scriptPath = $null
foreach ($path in $searchPaths) {
    if (Test-Path $path) {
        $scriptPath = $path
        Write-Ok "Script encontrado: $path"
        break
    }
}

if ($scriptPath -eq $null) {
    Write-Err "No se encontro $scriptName"
    Write-Warn "Rutas buscadas:"
    foreach ($p in $searchPaths) { Write-Info "  $p" }
    Write-Warn ""
    Write-Warn "Soluciones:"
    Write-Warn "  1. Coloca ACHE_AUDITAR.ps1 y ACHE_AUDITORIA_TOTAL.py en la misma carpeta"
    Write-Warn "  2. O ejecuta: .\ACHE_AUDITAR.ps1 -Instalar  (si estas en la carpeta correcta)"
    exit 1
}

# ── CARGAR API KEYS DESDE ARCHIVO ─────────────────────────────────────────
$envFile = "C:\ACHE\config\ache.env"
if (Test-Path $envFile) {
    Write-Ok "Cargando API keys desde: $envFile"
    Get-Content $envFile | ForEach-Object {
        $line = $_.Trim()
        if ($line -ne "" -and -not $line.StartsWith("#") -and $line -match "^([^=]+)=(.+)$") {
            $k = $matches[1].Trim()
            $v = $matches[2].Trim()
            [System.Environment]::SetEnvironmentVariable($k, $v, "Process")
            Write-Info "  ENV: $k cargada"
        }
    }
} else {
    Write-Warn "Archivo ache.env no encontrado en C:\ACHE\config\"
    Write-Info "  Las API keys se leeran del entorno del sistema"
}

Write-Sep

# ── CONSTRUIR ARGUMENTOS ───────────────────────────────────────────────────
$pyArgs = @($scriptPath)
if ($SoloHTML)  { $pyArgs += "--only-html" }
if ($JSON)      { $pyArgs += "--json" }

# ── EJECUTAR AUDITORÍA ─────────────────────────────────────────────────────
Write-Head "EJECUTANDO AUDITORIA TOTAL"
Write-Host ""

$startTime = Get-Date

try {
    & $pythonCmd @pyArgs
    $exitCode = $LASTEXITCODE
} catch {
    Write-Err "Error al ejecutar Python: $_"
    exit 1
}

$elapsed = (Get-Date) - $startTime

Write-Sep
if ($exitCode -eq 0) {
    Write-Ok "Auditoria completada en $([math]::Round($elapsed.TotalSeconds, 1))s"
    Write-Info "  El reporte HTML fue abierto automaticamente en tu navegador"
    Write-Info "  Busca ACHE_AUDITORIA_*.html en la carpeta actual"
} else {
    Write-Err "El script termino con codigo de error: $exitCode"
}

Write-Sep
Write-Host ""
