#Requires -Version 5.1
# ╔══════════════════════════════════════════════════════════════════════════════╗
# ║  CHOROTEGA_INSTALL.ps1 v2.0                                                ║
# ║  Instalador Universal — La Cruz, Guanacaste, Costa Rica                    ║
# ║  COOPECRUCENOS R.L. · Cédula 3-004-757068 · PCL-φ-1618                    ║
# ║                                                                              ║
# ║  EJECUTAR (PowerShell como usuario normal):                                 ║
# ║     .\CHOROTEGA_INSTALL.ps1             → Instalación completa             ║
# ║     .\CHOROTEGA_INSTALL.ps1 -Fix        → Reparar instalación              ║
# ║     .\CHOROTEGA_INSTALL.ps1 -Start      → Solo iniciar servicios           ║
# ║     .\CHOROTEGA_INSTALL.ps1 -Status     → Ver estado del ecosistema        ║
# ║     .\CHOROTEGA_INSTALL.ps1 -Nicoya     → Instalar para Lab Nicoya (LAN)   ║
# ║     .\CHOROTEGA_INSTALL.ps1 -Uninstall  → Desinstalar                      ║
# ╚══════════════════════════════════════════════════════════════════════════════╝

param(
    [switch]$Fix,
    [switch]$Start,
    [switch]$Status,
    [switch]$Nicoya,
    [switch]$Uninstall
)

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force -ErrorAction SilentlyContinue

# ── COLORES ───────────────────────────────────────────────────────────────────
function G($m){ Write-Host "  [OK]  $m" -ForegroundColor Green }
function W($m){ Write-Host "  [!!]  $m" -ForegroundColor Yellow }
function E($m){ Write-Host "  [ERR] $m" -ForegroundColor Red }
function I($m){ Write-Host "   ..   $m" -ForegroundColor DarkGray }
function H($m){ Write-Host "  $m" -ForegroundColor Cyan }
function Sep  { Write-Host ("─" * 70) -ForegroundColor DarkGray }

# ── CONFIGURACION ──────────────────────────────────────────────────────────────
$BASE     = "C:\Chorotega"
$HTML     = "$BASE\CHOROTEGA_v2.html"
$NEXUS    = "$BASE\nexus.py"
$CENTRAL  = "$BASE\central.js"
$BOOT     = "$BASE\CHOROTEGA_BOOT.ps1"
$ENVFILE  = "$BASE\ache.env"
$LOGDIR   = "$BASE\logs"
$MEMDIR   = "$BASE\memory"
$MODDIR   = "$BASE\modules"
$FEDIR    = "$BASE\frontends"
$PORT_UI  = 8888
$PORT_NEX = 8080
$PORT_CTR = 9999

function Banner {
    Write-Host ""
    Write-Host "  ╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "  ║  CHOROTEGA JADE SUPREMO v2.0 — INSTALADOR UNIVERSAL            ║" -ForegroundColor White
    Write-Host "  ║  COOPECRUCENOS R.L. · La Cruz, Guanacaste, Costa Rica          ║" -ForegroundColor DarkGray
    Write-Host "  ║  PCL-φ-1618 · GONZAGA-CBM-Ω-001                               ║" -ForegroundColor DarkGray
    Write-Host "  ╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host "  $(Get-Date -Format 'dddd dd/MM/yyyy  HH:mm:ss')" -ForegroundColor DarkGray
    Write-Host ""
}

function TestPort($p) {
    try {
        $tcp  = New-Object System.Net.Sockets.TcpClient
        $conn = $tcp.BeginConnect("127.0.0.1",$p,$null,$null)
        $ok   = $conn.AsyncWaitHandle.WaitOne(500,$false)
        $tcp.Close()
        return $ok
    } catch { return $false }
}

function GetLocalIP {
    try {
        $addrs = [System.Net.Dns]::GetHostAddresses([System.Net.Dns]::GetHostName())
        foreach($a in $addrs){
            if($a.AddressFamily -eq "InterNetwork" -and $a.IPAddressToString -notlike "127.*"){
                return $a.IPAddressToString
            }
        }
    } catch {}
    return "desconocida"
}

# ════════════════════════════════════════════════════════════════
# 1. CREAR ESTRUCTURA DE CARPETAS
# ════════════════════════════════════════════════════════════════
function Create-Folders {
    Sep; H "CREANDO ESTRUCTURA C:\Chorotega\"; Sep
    $dirs = @($BASE,$LOGDIR,$MEMDIR,$MODDIR,$FEDIR,"$BASE\config","$BASE\db","$BASE\static")
    foreach($d in $dirs){
        if(-not (Test-Path $d)){
            New-Item -ItemType Directory -Path $d -Force | Out-Null
            G "Creada: $d"
        } else { I "Existe: $d" }
    }
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 2. COPIAR HTML (si existe en la misma carpeta que el script)
# ════════════════════════════════════════════════════════════════
function Copy-HTML {
    Sep; H "HTML CHOROTEGA"; Sep
    $src = Join-Path $PSScriptRoot "CHOROTEGA_v2.html"
    if(Test-Path $src){
        Copy-Item $src $HTML -Force
        G "CHOROTEGA_v2.html copiado a $BASE"
    } elseif(Test-Path $HTML){
        G "CHOROTEGA_v2.html ya existe en $BASE"
    } else {
        W "CHOROTEGA_v2.html no encontrado junto al script"
        I "Copialo manualmente a: $HTML"
    }
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 3. GENOMA ACHE (ache_genome.json)
# ════════════════════════════════════════════════════════════════
function Create-Genome {
    $gf = "$BASE\ache_genome.json"
    if(-not (Test-Path $gf)){
        Sep; H "GENOMA ACHE (11 CCPs)"; Sep
        $g = [ordered]@{
            version="2.0"; nombre="CHOROTEGA"; apellido="JADE SUPREMO"
            creado=(Get-Date -Format "o"); entidad="COOPECRUCENOS R.L."
            cedula="3-004-757068"; celula="GONZAGA-CBM-Omega-001"
            referencia="PCL-phi-1618"; lugar="La Cruz, Guanacaste, Costa Rica"
            railway="https://web-production-5f8ef.up.railway.app"
            sinpe="8301-0520"; modelo="claude-sonnet-4-20250514"
            ccps=@(
                @{id=1;n="SQLite append-only";r="Nunca DELETE/UPDATE"}
                @{id=2;n="SHA-256 inmutable";r="Cada evento tiene hash"}
                @{id=3;n="Modo advisory";r="CHOROTEGA propone, humano decide"}
                @{id=4;n="Offline-first";r="Funciona sin internet"}
                @{id=5;n="Sin vendor lock-in";r="No dependencia unica"}
                @{id=6;n="MASTER.md manda";r="Constitucion del sistema"}
                @{id=7;n="Transparencia total";r="Todo auditable"}
                @{id=8;n="Dignidad humana";r="Personas primero siempre"}
                @{id=9;n="Cooperativismo";r="Beneficio colectivo"}
                @{id=10;n="Soberania digital";r="Codigo propio y abierto"}
                @{id=11;n="Resiliencia";r="Sobrevive a fallos"}
            )
        }
        $g | ConvertTo-Json -Depth 5 | Out-File $gf -Encoding UTF8
        G "Genoma creado con 11 CCPs: $gf"
    } else { I "Genoma ya existe" }
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 4. NEXUS BACKEND (Python Flask :8080)
# ════════════════════════════════════════════════════════════════
function Create-Nexus {
    Sep; H "NEXUS BACKEND (Flask :$PORT_NEX)"; Sep
    $code = @'
"""
CHOROTEGA NEXUS v2.0
Backend Flask para el ecosistema ACHE
COOPECRUCENOS R.L. · La Cruz, Guanacaste, Costa Rica
Puerto: 8080
"""
import os, time, json, logging, requests
from datetime import datetime
from flask import Flask, request, jsonify, make_response, send_from_directory
from flask_cors import CORS

PORT = int(os.environ.get("PORT", 8080))
ANTHROPIC_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
GROQ_KEY = os.environ.get("GROQ_API_KEY", "")
BASE = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__, static_folder=BASE, static_url_path="/static")
CORS(app, resources={r"/*": {"origins":"*","methods":["GET","POST","OPTIONS","PUT","DELETE"],"allow_headers":["Content-Type","Authorization","x-api-key","anthropic-version","anthropic-dangerous-direct-browser-access","Accept","Origin","X-Requested-With"]}})
logging.basicConfig(level=logging.INFO, format="%(asctime)s [NEXUS] %(message)s", datefmt="%H:%M:%S")
log = logging.getLogger("NEXUS")

SERVICES = {"brain":5099,"universal":5600,"fase9":5700,"meta":5299,"aurora":7777,"central":9999}

@app.after_request
def cors_headers(r):
    r.headers["Access-Control-Allow-Origin"] = "*"
    r.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
    r.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization,x-api-key,anthropic-version,anthropic-dangerous-direct-browser-access,Accept,Origin"
    r.headers["X-ACHE-Node"] = "NEXUS-8080"; r.headers["X-ACHE-Version"] = "2.0"
    return r

@app.before_request
def preflight():
    if request.method == "OPTIONS":
        r = make_response(); r.headers["Access-Control-Allow-Origin"] = "*"
        r.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
        r.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization,x-api-key,anthropic-version,anthropic-dangerous-direct-browser-access"
        return r

@app.route("/")
def root():
    return jsonify({"ache":"CHOROTEGA NEXUS v2","status":"online","port":PORT,"entity":"COOPECRUCENOS R.L.","cors":"all-origins","time":datetime.now().isoformat()})

@app.route("/health")
def health():
    svc = {}
    for n,p in SERVICES.items():
        try: r=requests.get(f"http://localhost:{p}",timeout=1); svc[n]="online"
        except: svc[n]="offline"
    return jsonify({"status":"healthy","nexus":f":{PORT}-online","services":svc,"anthropic":"ok" if ANTHROPIC_KEY else "missing","groq":"ok" if GROQ_KEY else "missing"})

@app.route("/claude", methods=["POST","OPTIONS"])
def proxy_claude():
    if request.method=="OPTIONS": return make_response("",200)
    d = request.get_json(force=True,silent=True) or {}
    key = d.get("api_key") or ANTHROPIC_KEY
    if not key: return jsonify({"error":"ANTHROPIC_API_KEY no configurada"}),400
    try:
        payload={"model":d.get("model","claude-sonnet-4-20250514"),"max_tokens":d.get("max_tokens",1500),"system":d.get("system","Sos CHOROTEGA de COOPECRUCENOS R.L."),"messages":d.get("messages") or [{"role":"user","content":d.get("prompt","")}]}
        r=requests.post("https://api.anthropic.com/v1/messages",json=payload,headers={"x-api-key":key,"anthropic-version":"2023-06-01","Content-Type":"application/json"},timeout=30)
        r.raise_for_status()
        rd=r.json(); reply=rd.get("content",[{}])[0].get("text","")
        log.info(f"Claude OK | {rd.get('usage',{})}")
        return jsonify({"reply":reply,"provider":"Claude","model":d.get("model","claude-sonnet-4-20250514")})
    except Exception as e:
        log.error(f"Claude error: {e}"); return jsonify({"error":str(e)}),500

@app.route("/groq", methods=["POST","OPTIONS"])
def proxy_groq():
    if request.method=="OPTIONS": return make_response("",200)
    d=request.get_json(force=True,silent=True) or {}
    key=d.get("api_key") or GROQ_KEY
    if not key: return jsonify({"error":"GROQ_API_KEY no configurada"}),400
    try:
        msgs=d.get("messages") or [{"role":"user","content":d.get("prompt","")}]
        r=requests.post("https://api.groq.com/openai/v1/chat/completions",json={"model":d.get("model","llama-3.3-70b-versatile"),"max_tokens":1400,"messages":[{"role":"system","content":d.get("system","")}]+msgs},headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"},timeout=20)
        r.raise_for_status(); rd=r.json()
        return jsonify({"reply":rd["choices"][0]["message"]["content"],"provider":"Groq"})
    except Exception as e:
        log.error(f"Groq error: {e}"); return jsonify({"error":str(e)}),500

@app.route("/network")
def network():
    results={}
    for name,port in SERVICES.items():
        t0=time.time()
        try:
            r=requests.get(f"http://localhost:{port}",timeout=1.5); results[name]={"status":"online","ms":int((time.time()-t0)*1000)}
        except requests.exceptions.ConnectionError: results[name]={"status":"offline","ms":-1}
        except: results[name]={"status":"error","ms":-1}
    online=sum(1 for v in results.values() if v["status"]=="online")
    return jsonify({"ts":datetime.now().isoformat(),"online":online,"total":len(SERVICES),"services":results})

_kv={}
@app.route("/memory",methods=["GET","POST"])
def memory():
    if request.method=="GET":
        k=request.args.get("key"); return jsonify({k:_kv.get(k)} if k else _kv)
    d=request.get_json(force=True,silent=True) or {}
    if not d.get("key"): return jsonify({"error":"key requerida"}),400
    _kv[d["key"]]=d.get("value")
    return jsonify({"ok":True})

@app.route("/chorotega")
@app.route("/dashboard")
def serve_main():
    try: return send_from_directory(BASE,"CHOROTEGA_v2.html")
    except: return jsonify({"error":"CHOROTEGA_v2.html no encontrado en "+BASE}),404

if __name__=="__main__":
    print(f"""
  ╔══════════════════════════════════════════════════════════════════╗
  ║  CHOROTEGA NEXUS v2 · COOPECRUCENOS R.L.                       ║
  ║  :8080  /claude  /groq  /network  /memory  /chorotega          ║
  ║  CORS: ALL ORIGINS · GONZAGA-CBM-Omega-001                     ║
  ╚══════════════════════════════════════════════════════════════════╝
  Anthropic: {"CONFIGURADA" if ANTHROPIC_KEY else "FALTA — setea ANTHROPIC_API_KEY"}
  Groq:      {"CONFIGURADA" if GROQ_KEY else "FALTA — setea GROQ_API_KEY (gratis en console.groq.com)"}
  Chorotega: http://localhost:{PORT}/chorotega
    """)
    app.run(host="0.0.0.0",port=PORT,debug=False,threaded=True)
'@
    $code | Out-File $NEXUS -Encoding UTF8
    G "nexus.py creado en $BASE"
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 5. SERVIDOR HTTP SIMPLE (para servir CHOROTEGA en LAN)
# ════════════════════════════════════════════════════════════════
function Create-HTTPServer {
    $srv = "$BASE\serve.py"
    $code = @"
"""Servidor HTTP simple para servir CHOROTEGA en la LAN — Puerto $PORT_UI"""
import http.server, socketserver, os, webbrowser, threading, time
os.chdir(r"$BASE")
Handler = http.server.SimpleHTTPRequestHandler
Handler.extensions_map = {'.html':'text/html','.js':'application/javascript','.css':'text/css','.json':'application/json','':'application/octet-stream'}
with socketserver.TCPServer(("0.0.0.0",$PORT_UI), Handler) as httpd:
    import socket
    ip = socket.gethostbyname(socket.gethostname())
    print(f"CHOROTEGA disponible en:")
    print(f"  Local:  http://localhost:$PORT_UI/CHOROTEGA_v2.html")
    print(f"  LAN:    http://{ip}:$PORT_UI/CHOROTEGA_v2.html")
    print(f"  Nicoya: http://{ip}:$PORT_UI/CHOROTEGA_v2.html")
    threading.Timer(1.5, lambda: webbrowser.open(f"http://localhost:$PORT_UI/CHOROTEGA_v2.html")).start()
    httpd.serve_forever()
"@
    $code | Out-File $srv -Encoding UTF8
    G "serve.py creado (puerto $PORT_UI para LAN)"
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 6. BOOTLOADER MAESTRO
# ════════════════════════════════════════════════════════════════
function Create-Bootloader {
    Sep; H "BOOTLOADER MAESTRO"; Sep
    $code = @"
# CHOROTEGA_BOOT.ps1 — Bootloader del Ecosistema
# COOPECRUCENOS R.L. · La Cruz, Guanacaste · PCL-phi-1618
# Ejecutar como usuario (no admin requerido)

`$BASE   = "C:\Chorotega"
`$LOG    = "`$BASE\logs\boot_`$(Get-Date -Format 'yyyyMMdd').log"
`$ENV    = "`$BASE\ache.env"

function Log(`$m){ `$t=Get-Date -Format 'HH:mm:ss'; `$line="`$t | `$m"; Add-Content -Path `$LOG -Value `$line -EA SilentlyContinue; Write-Host `$line }
function TestPort(`$p){ try{ `$c=New-Object System.Net.Sockets.TcpClient; `$r=`$c.BeginConnect("127.0.0.1",`$p,`$null,`$null); `$ok=`$r.AsyncWaitHandle.WaitOne(600,`$false); `$c.Close(); return `$ok }catch{ return `$false } }

Log "CHOROTEGA JADE SUPREMO v2 — Iniciando ecosistema"
Log "COOPECRUCENOS R.L. · Celula GONZAGA-CBM-Omega-001"

# Cargar variables desde .env
if(Test-Path `$ENV){
    Get-Content `$ENV | ForEach-Object {
        if(`$_ -match "^([^#=\s]+)=(.+)`$"){
            [System.Environment]::SetEnvironmentVariable(`$Matches[1].Trim(),`$Matches[2].Trim(),"Process")
            Log ".env: `$(`$Matches[1].Trim()) configurada"
        }
    }
}

# Verificar herramientas
`$hasPy   = (Get-Command python -EA SilentlyContinue) -ne `$null
`$hasNode = (Get-Command node   -EA SilentlyContinue) -ne `$null
Log "Python: `$(if(`$hasPy){'OK'}else{'NO ENCONTRADO'})"
Log "Node.js: `$(if(`$hasNode){'OK'}else{'NO ENCONTRADO'})"

# Iniciar NEXUS Flask :8080
if(`$hasPy -and (Test-Path "`$BASE\nexus.py") -and -not (TestPort 8080)){
    Start-Process powershell -WindowStyle Minimized -ArgumentList "-NoProfile -Command `"cd C:\Chorotega; python nexus.py`""
    Log "NEXUS :8080 iniciado"
} else { if(TestPort 8080){ Log "NEXUS :8080 ya activo" } else { Log "NEXUS: Python o nexus.py no disponible" } }

# Iniciar servidor HTTP LAN :8888
if(`$hasPy -and (Test-Path "`$BASE\serve.py") -and -not (TestPort $PORT_UI)){
    Start-Process powershell -WindowStyle Minimized -ArgumentList "-NoProfile -Command `"cd C:\Chorotega; python serve.py`""
    Log "HTTP LAN :$PORT_UI iniciado"
}

Start-Sleep 3

# Abrir CHOROTEGA
if(TestPort $PORT_UI){
    Start-Process "http://localhost:$PORT_UI/CHOROTEGA_v2.html"
    Log "CHOROTEGA abierta en navegador via HTTP"
} elseif(Test-Path "`$BASE\CHOROTEGA_v2.html"){
    Start-Process "`$BASE\CHOROTEGA_v2.html"
    Log "CHOROTEGA abierta directo desde archivo"
} else {
    Log "ERROR: CHOROTEGA_v2.html no encontrado en `$BASE"
}

Log "Ecosistema CHOROTEGA iniciado — PCL-phi-1618"
"@
    $code | Out-File $BOOT -Encoding UTF8
    G "Bootloader creado: $BOOT"
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 7. ARCHIVO .ENV TEMPLATE
# ════════════════════════════════════════════════════════════════
function Create-EnvTemplate {
    if(-not (Test-Path $ENVFILE)){
        @"
# CHOROTEGA API Keys — COOPECRUCENOS R.L.
# Editá este archivo con tus keys reales
# NO commitear al repositorio Git

# Claude (Anthropic) — https://console.anthropic.com
ANTHROPIC_API_KEY=sk-ant-api03-PEGA-TU-KEY-AQUI

# Groq (gratis, muy rápido) — https://console.groq.com
GROQ_API_KEY=gsk_PEGA-TU-KEY-AQUI

# OpenRouter (opcional) — https://openrouter.ai
# OPENROUTER_API_KEY=sk-or-PEGA-TU-KEY-AQUI

# HuggingFace (para imágenes, opcional) — https://huggingface.co
# HUGGINGFACE_API_KEY=hf_PEGA-TU-KEY-AQUI
"@ | Out-File $ENVFILE -Encoding UTF8
        G "Plantilla .env creada: $ENVFILE"
        I "Editá $ENVFILE con tus API keys reales"
    } else {
        I "ache.env ya existe"
    }
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 8. INSTALAR DEPENDENCIAS PYTHON
# ════════════════════════════════════════════════════════════════
function Install-PythonDeps {
    Sep; H "DEPENDENCIAS PYTHON"; Sep
    $hasPy = (Get-Command python -EA SilentlyContinue) -ne $null
    if(-not $hasPy){ W "Python no encontrado — descargalo de python.org"; Write-Host ""; return }
    $pkgs = @("flask","flask-cors","requests")
    foreach($pkg in $pkgs){
        $chk = & python -c "import $($pkg.Replace('-','_')); print('ok')" 2>$null
        if($chk -ne "ok"){
            I "Instalando $pkg..."
            & python -m pip install $pkg --quiet 2>&1 | Out-Null
            G "$pkg instalado"
        } else { I "$pkg ya instalado" }
    }
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 9. TAREA PROGRAMADA WINDOWS (autostart)
# ════════════════════════════════════════════════════════════════
function Create-Task {
    Sep; H "TAREA PROGRAMADA — INICIO DE SESION"; Sep
    $tn = "CHOROTEGA_AUTOSTART"
    $existing = Get-ScheduledTask -TaskName $tn -EA SilentlyContinue
    if($existing){
        I "Tarea ya existe: $tn"
        Write-Host ""
        return
    }
    try {
        $action  = New-ScheduledTaskAction -Execute "powershell.exe" -Argument "-WindowStyle Minimized -ExecutionPolicy RemoteSigned -File `"$BOOT`""
        $trigger = New-ScheduledTaskTrigger -AtLogon
        $settings= New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 10) -StartWhenAvailable
        Register-ScheduledTask -TaskName $tn -Action $action -Trigger $trigger -Settings $settings -RunLevel Limited -Force | Out-Null
        G "Tarea programada creada: '$tn' — se ejecuta al iniciar sesión"
    } catch {
        W "No se pudo crear tarea programada (puede requerir admin)"
        I "Alternativa: agrega acceso directo a $BOOT en:"
        I "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup"
    }
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 10. MODO NICOYA (instalacion para compartir en LAN)
# ════════════════════════════════════════════════════════════════
function Install-Nicoya {
    Sep; H "MODO NICOYA — DESPLIEGUE EN LAN"; Sep
    $ip = GetLocalIP
    Write-Host ""
    G "Servidor HTTP listo en este equipo:"
    Write-Host "  http://$ip`:$PORT_UI/CHOROTEGA_v2.html" -ForegroundColor Cyan
    Write-Host ""
    I "Para que otros equipos en la red accedan a CHOROTEGA:"
    I "1. Ejecuta: python C:\Chorotega\serve.py"
    I "2. Abre el firewall para el puerto $PORT_UI"
    I "3. Comparte la URL de arriba con los participantes del lab"
    Write-Host ""
    I "Abrir firewall (requiere admin):"
    Write-Host "  netsh advfirewall firewall add rule name=`"CHOROTEGA-HTTP`" dir=in action=allow protocol=TCP localport=$PORT_UI" -ForegroundColor DarkYellow
    Write-Host ""
    G "CHOROTEGA puede correr simultáneamente en:"
    I "• GONZAGA (La Cruz) — IP 192.168.100.134"
    I "• Nicoya Lab — IP $ip"
    I "• Cualquier máquina con Python o Node.js"
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 11. STATUS
# ════════════════════════════════════════════════════════════════
function Show-Status {
    Sep; H "ESTADO DEL ECOSISTEMA CHOROTEGA"; Sep
    Write-Host ""

    $ip = GetLocalIP

    # Puertos clave
    $ports = @{8080="NEXUS Flask";8888="HTTP LAN ($PORT_UI)";9999="ACHE CENTRAL";5099="ACHE BRAIN";5299="ACHE META";7777="AURORA"}
    foreach($p in $ports.Keys | Sort-Object){
        $ok = TestPort $p
        $sym = if($ok){"[ON] "}else{"[--] "}
        $col = if($ok){"Green"}else{"DarkGray"}
        Write-Host "  $sym :$p  $($ports[$p])" -ForegroundColor $col
    }
    Write-Host ""

    # API Keys
    $ak = [System.Environment]::GetEnvironmentVariable("ANTHROPIC_API_KEY","User")
    $gk = [System.Environment]::GetEnvironmentVariable("GROQ_API_KEY","User")
    if($ak){ G "ANTHROPIC_API_KEY configurada" } else { W "ANTHROPIC_API_KEY no configurada" }
    if($gk){ G "GROQ_API_KEY configurada" } else { W "GROQ_API_KEY no configurada (gratis en console.groq.com)" }
    Write-Host ""

    # Archivos
    $files = @($HTML,$NEXUS,$BOOT,$ENVFILE)
    foreach($f in $files){
        $n = Split-Path $f -Leaf
        if(Test-Path $f){ G "$n" } else { W "$n NO ENCONTRADO" }
    }
    Write-Host ""

    G "IP de este equipo: $ip"
    I "CHOROTEGA en LAN: http://$ip`:$PORT_UI/CHOROTEGA_v2.html"
    Write-Host ""
}

# ════════════════════════════════════════════════════════════════
# 12. UNINSTALL
# ════════════════════════════════════════════════════════════════
function Do-Uninstall {
    Sep; H "DESINSTALAR CHOROTEGA"; Sep
    if(-not (Get-YesNo "¿Seguro que querés eliminar C:\Chorotega y la tarea programada?")){ Write-Host "  Cancelado."; return }
    try {
        Unregister-ScheduledTask -TaskName "CHOROTEGA_AUTOSTART" -Confirm:$false -EA SilentlyContinue
        G "Tarea programada eliminada"
    } catch {}
    if(Test-Path $BASE){
        Remove-Item $BASE -Recurse -Force
        G "C:\Chorotega eliminado"
    }
    Write-Host ""
    G "Desinstalación completada"
    Write-Host ""
}

function Get-YesNo($prompt){ Write-Host "  $prompt [S/N] " -ForegroundColor Yellow -NoNewline; $r=Read-Host; return $r -ieq "s" }

# ════════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════════
Banner

if($Status){
    Show-Status
    exit
}

if($Nicoya){
    Install-Nicoya
    exit
}

if($Uninstall){
    Do-Uninstall
    exit
}

# Instalación completa o Fix
if($Fix -or (-not $Status -and -not $Nicoya -and -not $Start)){
    Create-Folders
    Copy-HTML
    Create-Genome
    Create-Nexus
    Create-HTTPServer
    Create-Bootloader
    Create-EnvTemplate
    Install-PythonDeps
    if(-not $Fix){ Create-Task }
}

# Iniciar servicios
Sep; H "INICIANDO SERVICIOS"; Sep

$hasPy = (Get-Command python -EA SilentlyContinue) -ne $null

if($hasPy -and (Test-Path $NEXUS) -and -not (TestPort $PORT_NEX)){
    Start-Process powershell -WindowStyle Minimized -ArgumentList "-NoProfile -Command `"cd C:\Chorotega; python nexus.py`""
    G "NEXUS :$PORT_NEX iniciado"
    Start-Sleep 2
} else {
    if(TestPort $PORT_NEX){ I "NEXUS :$PORT_NEX ya activo" }
}

if($hasPy -and (Test-Path "$BASE\serve.py") -and -not (TestPort $PORT_UI)){
    Start-Process powershell -WindowStyle Minimized -ArgumentList "-NoProfile -Command `"cd C:\Chorotega; python serve.py`""
    G "HTTP LAN :$PORT_UI iniciado"
    Start-Sleep 2
}

# Resultado final
Sep; Sep
$ip = GetLocalIP
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║  CHOROTEGA JADE SUPREMO v2 — INSTALADO Y ACTIVO               ║" -ForegroundColor Green
Write-Host "  ╠══════════════════════════════════════════════════════════════════╣" -ForegroundColor Cyan
Write-Host "  ║  Local:   http://localhost:$PORT_UI/CHOROTEGA_v2.html              ║" -ForegroundColor White
Write-Host "  ║  LAN:     http://$ip`:$PORT_UI/CHOROTEGA_v2.html               ║" -ForegroundColor White
Write-Host "  ║  NEXUS:   http://localhost:$PORT_NEX                                ║" -ForegroundColor White
Write-Host "  ║                                                                  ║" -ForegroundColor Cyan
Write-Host "  ║  Nicoya:  .\CHOROTEGA_INSTALL.ps1 -Nicoya                      ║" -ForegroundColor DarkGray
Write-Host "  ║  Status:  .\CHOROTEGA_INSTALL.ps1 -Status                      ║" -ForegroundColor DarkGray
Write-Host "  ║  Ayuda:   .\CHOROTEGA_INSTALL.ps1 -Help                        ║" -ForegroundColor DarkGray
Write-Host "  ╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# Configurar API Key si no está
$ak = [System.Environment]::GetEnvironmentVariable("ANTHROPIC_API_KEY","User")
if(-not $ak){
    Write-Host ""
    W "API Key de Anthropic no configurada. Para configurarla:"
    Write-Host '  [System.Environment]::SetEnvironmentVariable("ANTHROPIC_API_KEY","sk-ant-api03-TU-KEY","User")' -ForegroundColor Yellow
    Write-Host '  [System.Environment]::SetEnvironmentVariable("GROQ_API_KEY","gsk_TU-KEY","User")' -ForegroundColor Yellow
    Write-Host ""
    I "(Scope valido = 'User', 'Machine' o 'Process' — nunca texto libre)"
    Write-Host ""
}

# Abrir navegador
Start-Sleep 1
if(TestPort $PORT_UI){
    Start-Process "http://localhost:$PORT_UI/CHOROTEGA_v2.html"
} elseif(Test-Path $HTML){
    Start-Process $HTML
}

Write-Host "  Pura vida, mae. CHOROTEGA está viva. — PCL-φ-1618" -ForegroundColor Green
Write-Host ""
