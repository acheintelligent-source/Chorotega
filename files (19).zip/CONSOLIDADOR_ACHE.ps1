#Requires -Version 5.1
# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  CONSOLIDADOR_ACHE.ps1 v1.0                                            ║
# ║  Consolida 50+ directorios ACHE fragmentados → C:\Chorotega            ║
# ║  COOPECRUCENOS R.L. · La Cruz, Guanacaste · PCL-φ-1618                ║
# ║                                                                          ║
# ║  EJECUTAR: .\CONSOLIDADOR_ACHE.ps1                                     ║
# ║            .\CONSOLIDADOR_ACHE.ps1 -DryRun   (solo muestra, no copia) ║
# ║            .\CONSOLIDADOR_ACHE.ps1 -Full      (incluye node_modules)  ║
# ╚══════════════════════════════════════════════════════════════════════════╝

param(
    [switch]$DryRun,
    [switch]$Full,
    [string]$Dest = "C:\Chorotega"
)

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force -ErrorAction SilentlyContinue

function G($m){ Write-Host "  [OK]  $m" -ForegroundColor Green }
function W($m){ Write-Host "  [!!]  $m" -ForegroundColor Yellow }
function I($m){ Write-Host "   ..   $m" -ForegroundColor DarkGray }
function H($m){ Write-Host "`n  $m" -ForegroundColor Cyan }
function Sep  { Write-Host ("─" * 72) -ForegroundColor DarkGray }
function Dry($m){ Write-Host "  [DR]  $m" -ForegroundColor Magenta }

$LOG = "$Dest\logs\consolidacion_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
function Log($m){ Add-Content -Path $LOG -Value "$(Get-Date -Format 'HH:mm:ss') | $m" -EA SilentlyContinue }

function HumanSize($b){
    if($null -eq $b -or $b -eq 0){ return "0 B" }
    $lb = [long]$b
    if($lb -lt 1024){ return "$lb B" }
    if($lb -lt 1048576){ return "{0:N1} KB" -f ($lb/1024) }
    if($lb -lt 1073741824){ return "{0:N1} MB" -f ($lb/1048576) }
    return "{0:N2} GB" -f ($lb/1073741824)
}

# ── BANNER ─────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║  ACHE CONSOLIDADOR v1.0 — UNIFICADOR DE ECOSISTEMA            ║" -ForegroundColor White
Write-Host "  ║  COOPECRUCENOS R.L. · La Cruz, Guanacaste, Costa Rica         ║" -ForegroundColor DarkGray
if($DryRun){ Write-Host "  ║  MODO: DRY RUN — Solo lectura, sin cambios en disco            ║" -ForegroundColor Yellow }
else        { Write-Host "  ║  MODO: CONSOLIDACION REAL — Copia archivos a $Dest          ║" -ForegroundColor Green }
Write-Host "  ╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host "  $(Get-Date -Format 'dddd dd/MM/yyyy HH:mm:ss')" -ForegroundColor DarkGray
Write-Host ""

# ── CREAR DESTINO ───────────────────────────────────────────────────────────
if(-not $DryRun){
    $subdirs = @("frontends","memory","modules","logs","static","config","db","backups","legacy")
    foreach($s in $subdirs){
        New-Item -ItemType Directory -Path "$Dest\$s" -Force | Out-Null
    }
    G "Estructura $Dest\ creada"
}

# ── PALABRAS CLAVE PARA DETECTAR DIRECTORIOS ACHE ──────────────────────────
$ACHE_KWS = @(
    "ACHE","AURORA","NEXUS","EVA","NEPTUNO","GONZAGA","COOPECRUCENOS",
    "TRAILERO","GENESIS","SUPREMA","SUPREMO","UNIVERSAL","MATRIARCA","BRAIN",
    "CONSCIENTIA","PACIFICA","META","FASE","MOTHER","ALMA","LYRA","COSMOS",
    "OMEGA","CENTRAL","MASTER","CHOROTEGA","INTEL","HARMONY","PROD"
)

# ── TIPOS DE ARCHIVOS PRIORITARIOS ─────────────────────────────────────────
$PRIO = @{
    "Frontend HTML" = @("*.html","*.htm")
    "Backend Python" = @("*.py")
    "Backend Node"  = @("*.js")
    "Base de datos" = @("*.db","*.sqlite","*.sqlite3")
    "Configuracion" = @("*.json","*.env","*.ini","*.toml","*.yaml","*.yml")
    "Scripts PS"    = @("*.ps1","*.bat","*.sh")
    "Docs"          = @("*.md","*.txt","MASTER*","CLAUDE*","README*")
    "Datos"         = @("*.csv","*.xlsx")
}

# Archivos a ignorar siempre
$IGNORE_DIRS  = @("node_modules",".git","__pycache__",".cache","dist","build",".venv","venv","env")
$IGNORE_FILES = @("package-lock.json","yarn.lock","*.pyc","*.pyo","thumbs.db",".DS_Store","desktop.ini")

# ── PASO 1: DESCUBRIR DIRECTORIOS ACHE ─────────────────────────────────────
Sep; H "PASO 1 — DESCUBRIENDO DIRECTORIOS ACHE EN GONZAGA"
Sep

$SEARCH_ROOTS = @(
    "C:\",
    "$env:USERPROFILE",
    "$env:USERPROFILE\Desktop",
    "$env:USERPROFILE\Documents",
    "$env:USERPROFILE\Downloads"
)

$found_dirs = New-Object System.Collections.ArrayList

foreach($root in $SEARCH_ROOTS){
    if(-not (Test-Path $root)){ continue }
    try {
        $dirs = Get-ChildItem -Path $root -Directory -Depth 1 -ErrorAction SilentlyContinue
        foreach($d in $dirs){
            if($d.FullName -eq $Dest){ continue } # skip destino
            $hit = $false
            foreach($kw in $ACHE_KWS){
                if($d.Name -like "*$kw*"){ $hit=$true; break }
            }
            if($hit -and $found_dirs -notcontains $d.FullName){
                $null = $found_dirs.Add($d.FullName)
            }
        }
    } catch {}
}

# También buscar en subdirectorios del perfil (más profundo)
try {
    $deep = Get-ChildItem -Path $env:USERPROFILE -Directory -Depth 2 -ErrorAction SilentlyContinue
    foreach($d in $deep){
        if($d.FullName -eq $Dest){ continue }
        $hit=$false
        foreach($kw in $ACHE_KWS){ if($d.Name -like "*$kw*"){ $hit=$true; break } }
        if($hit -and $found_dirs -notcontains $d.FullName){ $null=$found_dirs.Add($d.FullName) }
    }
} catch {}

$found_dirs = $found_dirs | Sort-Object
Write-Host ""
I "Directorios ACHE detectados: $($found_dirs.Count)"
Write-Host ""

# ── PASO 2: AUDITORÍA ───────────────────────────────────────────────────────
Sep; H "PASO 2 — AUDITORÍA DE ARCHIVOS CLAVE"
Sep

$all_files = New-Object System.Collections.ArrayList
$stats = @{
    total_dirs=0; total_files=0; total_bytes=0
    htmls=0; pys=0; jss=0; dbs=0; jsons=0; ps1s=0
    html_biggest=$null; html_biggest_sz=0
    db_biggest=$null; db_biggest_sz=0
}

foreach($dir in $found_dirs){
    if(-not (Test-Path $dir)){ continue }
    $stats.total_dirs++

    $skip = $false
    foreach($ig in $IGNORE_DIRS){ if($dir -like "*\$ig*"){ $skip=$true; break } }
    if($skip){ continue }

    try {
        $files = Get-ChildItem -Path $dir -File -Recurse -ErrorAction SilentlyContinue -Depth $(if($Full){10}else{4}) |
            Where-Object {
                $n = $_.Name.ToLower()
                $skip2=$false
                foreach($ig in $IGNORE_DIRS){ if($_.FullName -like "*\$ig\*"){ $skip2=$true; break } }
                foreach($ig in $IGNORE_FILES){ if($n -like $ig.ToLower()){ $skip2=$true; break } }
                -not $skip2
            }

        foreach($f in $files){
            $stats.total_files++
            $stats.total_bytes += $f.Length
            $ext = $f.Extension.ToLower()
            switch($ext){
                ".html"{ $stats.htmls++; if($f.Length -gt $stats.html_biggest_sz){ $stats.html_biggest=$f.FullName; $stats.html_biggest_sz=$f.Length } }
                ".py"  { $stats.pys++ }
                ".js"  { $stats.jss++ }
                ".db"  { $stats.dbs++; if($f.Length -gt $stats.db_biggest_sz){ $stats.db_biggest=$f.FullName; $stats.db_biggest_sz=$f.Length } }
                ".json"{ $stats.jsons++ }
                ".ps1" { $stats.ps1s++ }
            }
            $null = $all_files.Add($f)
        }
    } catch {}
}

Write-Host ""
G "Directorios auditados:   $($stats.total_dirs)"
G "Archivos totales:        $($stats.total_files)   ($( HumanSize $stats.total_bytes ))"
I "HTML:   $($stats.htmls)    Python: $($stats.pys)    JS: $($stats.jss)"
I "SQLite: $($stats.dbs)     JSON: $($stats.jsons)   PS1: $($stats.ps1s)"
if($stats.html_biggest){ I "HTML más grande: $(Split-Path $stats.html_biggest -Leaf) ($( HumanSize $stats.html_biggest_sz ))"; I "  → $($stats.html_biggest)" }
if($stats.db_biggest)  { I "DB más grande: $(Split-Path $stats.db_biggest -Leaf) ($( HumanSize $stats.db_biggest_sz ))";     I "  → $($stats.db_biggest)" }
Write-Host ""

# ── PASO 3: IDENTIFICAR ARCHIVOS ESTRELLA ───────────────────────────────────
Sep; H "PASO 3 — ARCHIVOS ESTRELLA (los más importantes)"
Sep

# Reglas para identificar las joyas del sistema
$STAR_RULES = @(
    @{pat="CHOROTEGA*.html";    cat="frontends"; desc="CHOROTEGA IA" }
    @{pat="hotel_v6_final.html";cat="frontends"; desc="Hotel v6 Final" }
    @{pat="ACHE_ALMA_v1.html";  cat="frontends"; desc="ACHE ALMA" }
    @{pat="ACHE_NEXUS_SUPREMO*.html"; cat="frontends"; desc="NEXUS Supremo" }
    @{pat="ACHE_CONEXION_TOTAL*.html";cat="frontends"; desc="Conexion Total" }
    @{pat="ACHE_TRAILERO*.html"; cat="frontends"; desc="Trailero Aduana" }
    @{pat="ACHE_MADRE_GOV*.html";cat="frontends"; desc="MADRE Government" }
    @{pat="nexus_cors_patch.py"; cat="";          desc="NEXUS Flask :8080" }
    @{pat="nexus.py";            cat="";          desc="NEXUS Backend" }
    @{pat="ache_universal.py";   cat="";          desc="ACHE Universal" }
    @{pat="central.js";          cat="";          desc="ACHE Central :9999" }
    @{pat="server.js";           cat="";          desc="Server Node" }
    @{pat="ache_genome.json";    cat="config";    desc="Genoma ACHE" }
    @{pat="MASTER.md";           cat="config";    desc="MASTER (constitución)" }
    @{pat="CLAUDE.md";           cat="config";    desc="Instrucciones Claude Code" }
    @{pat="ACHE_AUTOSTART*.ps1"; cat="";          desc="Autostart" }
    @{pat="ache_status.ps1";     cat="";          desc="Status script" }
    @{pat="*.db";                cat="memory";    desc="Base de datos SQLite" }
    @{pat="memory.json";         cat="memory";    desc="Memoria JSON" }
    @{pat="ache.env";            cat="config";    desc="Config .env" }
)

$to_copy = New-Object System.Collections.ArrayList
$found_stars = @{}

foreach($rule in $STAR_RULES){
    $matches_r = $all_files | Where-Object { $_.Name -like $rule.pat } |
                 Sort-Object -Property LastWriteTime -Descending
    if($matches_r){
        foreach($m in $matches_r){
            $key = $rule.pat
            if(-not $found_stars.ContainsKey($key)){
                $found_stars[$key]=$m.FullName
                Write-Host ("  [{0,-18}]  {1,-30} {2}" -f $rule.desc, $m.Name, (HumanSize $m.Length)) -ForegroundColor Green
                I "  Origen: $($m.DirectoryName)"
                $dest_sub = if($rule.cat){ "$Dest\$($rule.cat)" } else { $Dest }
                $null = $to_copy.Add(@{src=$m.FullName; dst=$dest_sub; name=$m.Name; desc=$rule.desc})
            } else {
                I "  Dup: $($m.FullName)"
            }
        }
    }
}

Write-Host ""
I "Archivos estrella identificados: $($to_copy.Count)"
Write-Host ""

# ── PASO 4: COPIAR ARCHIVOS ─────────────────────────────────────────────────
Sep; H "PASO 4 — $( if($DryRun){'[DRY RUN] SIMULANDO COPIA'}else{'COPIANDO ARCHIVOS'} )"
Sep

$copied = 0; $skipped = 0; $errors = 0

foreach($item in $to_copy){
    $dst_path = Join-Path $item.dst $item.name
    if($DryRun){
        Dry "$($item.desc): $($item.name) → $($item.dst)"
        $copied++
    } else {
        try {
            if(-not (Test-Path $item.dst)){ New-Item -ItemType Directory -Path $item.dst -Force | Out-Null }
            # No sobreescribir si el destino es más reciente
            if(Test-Path $dst_path){
                $src_dt = (Get-Item $item.src).LastWriteTime
                $dst_dt = (Get-Item $dst_path).LastWriteTime
                if($dst_dt -ge $src_dt){
                    I "Skip (más reciente): $($item.name)"
                    $skipped++
                    continue
                }
                # Backup del existente
                Copy-Item $dst_path "$Dest\backups\$($item.name)_backup_$(Get-Date -Format 'yyyyMMddHHmm')" -EA SilentlyContinue
            }
            Copy-Item $item.src $dst_path -Force
            G "$($item.desc): $($item.name)"
            Log "COPIADO: $($item.src) → $dst_path"
            $copied++
        } catch {
            W "Error copiando $($item.name): $_"
            $errors++
        }
    }
}

Write-Host ""
G "Copiados: $copied   Saltados (ya actualizados): $skipped   Errores: $errors"
Write-Host ""

# ── PASO 5: MAPA DEL ECOSISTEMA ─────────────────────────────────────────────
Sep; H "PASO 5 — MAPA DEL ECOSISTEMA CONSOLIDADO"
Sep

Write-Host ""
Write-Host "  C:\Chorotega\" -ForegroundColor Cyan
$tree_items = @(
    @{p="  ├─ CHOROTEGA_v3_OMEGA.html";   c="Cyan";  n="IA completa (chat+hotel+células+SIEU)"}
    @{p="  ├─ CHOROTEGA_v2.html";          c="Green"; n="IA v2 (chat+crear+ACHE)"}
    @{p="  ├─ CHOROTEGA_INSTALL.ps1";      c="Yellow";n="Instalador universal"}
    @{p="  ├─ CONSOLIDADOR_ACHE.ps1";      c="Yellow";n="Este script"}
    @{p="  ├─ nexus.py";                   c="White"; n="Backend Flask :8080"}
    @{p="  ├─ serve.py";                   c="White"; n="HTTP LAN :8888"}
    @{p="  ├─ CHOROTEGA_BOOT.ps1";         c="Yellow";n="Bootloader autostart"}
    @{p="  ├─ ache.env";                   c="Red";   n="API Keys (editar)"}
    @{p="  ├─ ache_genome.json";           c="White"; n="ADN del sistema (11 CCPs)"}
    @{p="  ├─ frontends\";                 c="Cyan";  n="hotel_v6, ALMA, NEXUS, TRAILERO..."}
    @{p="  ├─ memory\";                    c="Cyan";  n="*.db SQLite append-only"}
    @{p="  ├─ config\";                    c="Cyan";  n="MASTER.md, CLAUDE.md, .env"}
    @{p="  ├─ modules\";                   c="Cyan";  n="AutoProgrammer genera aquí"}
    @{p="  ├─ logs\";                      c="DarkGray";n="boot_*.log, consolidacion_*.log"}
    @{p="  └─ backups\";                   c="DarkGray";n="Backups automáticos antes de sobreescribir"}
)
foreach($ti in $tree_items){
    Write-Host $ti.p -ForegroundColor $ti.c -NoNewline
    Write-Host "  ← $($ti.n)" -ForegroundColor DarkGray
}
Write-Host ""

# ── PASO 6: LEGACY — DIRECTORIOS LEGADOS ───────────────────────────────────
Sep; H "PASO 6 — DIRECTORIOS LEGADOS (podés eliminar después de verificar)"
Sep

Write-Host ""
$total_legacy = 0
foreach($d in $found_dirs){
    if($d -eq $Dest){ continue }
    $cnt = 0; $sz = 0
    try {
        $ff = Get-ChildItem -Path $d -Recurse -File -EA SilentlyContinue -Depth 2 |
              Where-Object { $_.FullName -notlike "*\node_modules\*" }
        $cnt = ($ff | Measure-Object).Count
        $sz  = ($ff | Measure-Object -Property Length -Sum).Sum
        if($null -eq $sz){ $sz=0 }
    } catch {}
    Write-Host ("  {0,-60} {1,8} archivos  {2}" -f $d, $cnt, (HumanSize $sz)) -ForegroundColor DarkGray
    $total_legacy += $sz
}
Write-Host ""
I "Espacio total en directorios legados: $( HumanSize $total_legacy )"
I "Para liberar espacio, verificá que todo está en C:\Chorotega\ y luego eliminá manualmente."
Write-Host ""

# ── RESUMEN FINAL ───────────────────────────────────────────────────────────
Sep
$ok = (Test-Path "$Dest\nexus.py") -or (Test-Path "$Dest\CHOROTEGA_v2.html")
Write-Host ""
Write-Host "  ╔══════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "  ║  CONSOLIDACION $( if($DryRun){'SIMULADA'}else{'COMPLETADA'} ) — PCL-φ-1618                      ║" -ForegroundColor $(if($ok){"Green"}else{"Yellow"})
Write-Host "  ╠══════════════════════════════════════════════════════════════════╣" -ForegroundColor Cyan
Write-Host ("  ║  Directorios auditados:  {0,-42}║" -f $stats.total_dirs) -ForegroundColor White
Write-Host ("  ║  Archivos analizados:    {0,-42}║" -f $stats.total_files) -ForegroundColor White
Write-Host ("  ║  Archivos estrella:      {0,-42}║" -f $to_copy.Count) -ForegroundColor White
Write-Host ("  ║  Copiados/Simulados:     {0,-42}║" -f $copied) -ForegroundColor White
Write-Host ("  ║  Destino:                {0,-42}║" -f $Dest) -ForegroundColor White
Write-Host "  ╚══════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

if(-not $DryRun){
    Write-Host "  SIGUIENTE PASO:" -ForegroundColor Cyan
    I "  1. Abre C:\Chorotega\CHOROTEGA_v3_OMEGA.html en el navegador"
    I "  2. Configurá API Keys: .\CHOROTEGA_INSTALL.ps1 -Status"
    I "  3. Para compartir en Nicoya: python C:\Chorotega\serve.py"
    Write-Host ""
    if(Test-Path "$Dest\CHOROTEGA_v2.html"){
        Write-Host "  Abriendo CHOROTEGA..." -ForegroundColor Green
        Start-Process "$Dest\CHOROTEGA_v2.html" -EA SilentlyContinue
    }
}

Write-Host "  Pura vida, mae. El ecosistema está unificado en $Dest" -ForegroundColor Green
Write-Host ""
