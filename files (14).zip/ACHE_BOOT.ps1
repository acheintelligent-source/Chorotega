# ╔══════════════════════════════════════════════════════════════════════════╗
# ║   ACHE_BOOT v2.0 — Bootloader Maestro del Ecosistema                   ║
# ║   COOPECRUCENOS R.L. · La Cruz, Guanacaste, Costa Rica                 ║
# ║   Compatible con PowerShell 5.1 (Windows 11)                           ║
# ║                                                                          ║
# ║   USO:                                                                   ║
# ║     .\ACHE_BOOT.ps1              # Arranque completo                   ║
# ║     .\ACHE_BOOT.ps1 -Kill        # Solo matar node/python              ║
# ║     .\ACHE_BOOT.ps1 -Status      # Ver estado puertos                  ║
# ║     .\ACHE_BOOT.ps1 -SetKey      # Configurar API keys                 ║
# ╚══════════════════════════════════════════════════════════════════════════╝

param(
    [switch]$Kill,
    [switch]$Status,
    [switch]$SetKey
)

Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force

# ── COLORES ────────────────────────────────────────────────────────────────
function Write-Ok($msg)   { Write-Host "  [OK]  $msg" -ForegroundColor Green }
function Write-Err($msg)  { Write-Host "  [!!]  $msg" -ForegroundColor Red }
function Write-Info($msg) { Write-Host "  [--]  $msg" -ForegroundColor DarkGray }
function Write-Warn($msg) { Write-Host "  [>>]  $msg" -ForegroundColor Yellow }
function Write-Head($msg) { Write-Host "`n$msg" -ForegroundColor Cyan }
function Write-Sep       { Write-Host ("=" * 68) -ForegroundColor DarkBlue }

# ── BANNER ─────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "  ACHE ECOSYSTEM BOOT v2.0" -ForegroundColor Cyan
Write-Host "  COOPECRUCENOS R.L. - La Cruz, Guanacaste, CR" -ForegroundColor DarkGray
Write-Host "  $(Get-Date -Format 'dddd dd/MM/yyyy HH:mm:ss')" -ForegroundColor DarkGray
Write-Sep

# ── TEST-PORT (PS 5.1 compatible) ──────────────────────────────────────────
function Test-Port($port) {
    try {
        $tcp = New-Object System.Net.Sockets.TcpClient
        $ar  = $tcp.BeginConnect("localhost", $port, $null, $null)
        $ok  = $ar.AsyncWaitHandle.WaitOne(400, $false)
        try { $tcp.Close() } catch {}
        return $ok
    } catch {
        return $false
    }
}

# ── MATAR PROCESOS (PS 5.1 compatible, sin ??) ─────────────────────────────
function Stop-AllAche {
    Write-Head "LIMPIEZA DE PROCESOS"
    Write-Sep

    $procs = @("node", "python", "flask", "uvicorn", "ngrok")
    foreach ($name in $procs) {
        $found = Get-Process -Name $name -ErrorAction SilentlyContinue
        if ($found) {
            $found | Stop-Process -Force
            Write-Ok "Terminado: $name ($($found.Count) proceso(s))"
        } else {
            Write-Info "No activo: $name"
        }
    }

    Start-Sleep -Seconds 2
    Write-Ok "Puertos liberados. Esperando 2s..."
}

# ── ESTADO DE PUERTOS ──────────────────────────────────────────────────────
function Show-Status {
    Write-Head "ESTADO DEL ECOSISTEMA ACHE"
    Write-Sep

    $ports = @{
        8080 = "AURORA NEXUS v1.0 (Flask)"
        5299 = "ACHE_META_FINAL (Express)"
        5099 = "ACHE_BRAIN (Express)"
        9000 = "NEXUS Cerebro"
        7777 = "AURORA Suprema"
        3000 = "ACHE MONEY"
        3002 = "ACHE MOBILE"
        5600 = "ACHE_UNIVERSAL"
        5700 = "ACHE_FASE9"
        5800 = "ACHE_FASE10"
    }

    $activos = 0
    foreach ($port in ($ports.Keys | Sort-Object)) {
        $label = $ports[$port]
        $ok    = Test-Port $port
        if ($ok) {
            Write-Ok (":$port  $label  [ACTIVO]")
            $activos++
        } else {
            Write-Info (":$port  $label  [offline]")
        }
    }

    Write-Host ""
    if ($activos -gt 0) {
        Write-Ok "$activos servicio(s) activos en localhost"
    } else {
        Write-Warn "Ningun servicio ACHE esta corriendo"
    }

    # API Keys (PS 5.1: sin ?. operator)
    Write-Head "API KEYS"
    Write-Sep
    $keys = @("ANTHROPIC_API_KEY", "GROQ_API_KEY", "OPENAI_API_KEY")
    foreach ($k in $keys) {
        $val = [System.Environment]::GetEnvironmentVariable($k)
        if ($val -ne $null -and $val -ne "") {
            $masked = $val.Substring(0, [Math]::Min(8, $val.Length)) + "..."
            Write-Ok "$k  [$masked]"
        } else {
            Write-Warn "$k  [NO CONFIGURADA]"
        }
    }
}

# ── CONFIGURAR API KEYS ────────────────────────────────────────────────────
function Set-ApiKeys {
    Write-Head "CONFIGURAR API KEYS"
    Write-Sep

    Write-Host "  Ingresa tu ANTHROPIC_API_KEY (sk-ant-...): " -NoNewline -ForegroundColor Yellow
    $ant = Read-Host

    if ($ant -ne "" -and $ant -ne $null) {
        [System.Environment]::SetEnvironmentVariable("ANTHROPIC_API_KEY", $ant, "User")
        $env:ANTHROPIC_API_KEY = $ant
        Write-Ok "ANTHROPIC_API_KEY guardada (scope: User)"
    }

    Write-Host "  Ingresa tu GROQ_API_KEY (gsk_...): " -NoNewline -ForegroundColor Yellow
    $groq = Read-Host

    if ($groq -ne "" -and $groq -ne $null) {
        [System.Environment]::SetEnvironmentVariable("GROQ_API_KEY", $groq, "User")
        $env:GROQ_API_KEY = $groq
        Write-Ok "GROQ_API_KEY guardada (scope: User)"
    }

    Write-Ok "Keys configuradas. Reinicia PowerShell para que tomen efecto global."
}

# ── LEVANTAR STACK PRINCIPAL ───────────────────────────────────────────────
function Start-AcheStack {
    Write-Head "LEVANTANDO STACK ACHE"
    Write-Sep

    # 1. NEXUS Flask :8080 (si tiene boot.py o nexus.py)
    $nexusPaths = @(
        "C:\Users\achei\ACHE\nexus.py",
        "C:\Users\achei\ACHE\boot.py",
        "C:\ACHE_META_FINAL\server.js"
    )

    $nexusFound = $null
    foreach ($p in $nexusPaths) {
        if (Test-Path $p) {
            $nexusFound = $p
            break
        }
    }

    # Verificar si :8080 ya responde
    if (Test-Port 8080) {
        Write-Ok ":8080 ya esta activo (NEXUS/AURORA)"
    } else {
        if ($nexusFound -ne $null) {
            Write-Warn "Intentando levantar :8080 desde: $nexusFound"
            $dir = Split-Path $nexusFound
            if ($nexusFound -match "\.py$") {
                Start-Process powershell -ArgumentList "-NoExit -Command cd '$dir'; python '$nexusFound'"
            }
            Start-Sleep -Seconds 3
            if (Test-Port 8080) {
                Write-Ok ":8080 ACTIVO"
            } else {
                Write-Err ":8080 no respondio — verifica el backend Python"
            }
        } else {
            Write-Err ":8080 offline y no se encontro boot.py — levantalo manualmente"
        }
    }

    # 2. META_FINAL :5299
    $metaPath = "C:\ACHE_META_FINAL"
    if (Test-Port 5299) {
        Write-Ok ":5299 ya esta activo (ACHE_META_FINAL)"
    } elseif (Test-Path "$metaPath\server.js") {
        Start-Process powershell -ArgumentList "-NoExit -Command cd '$metaPath'; node server.js"
        Start-Sleep -Seconds 3
        if (Test-Port 5299) {
            Write-Ok ":5299 ACTIVO"
        } else {
            Write-Err ":5299 no respondio"
        }
    } else {
        Write-Warn ":5299 — no se encontro C:\ACHE_META_FINAL\server.js"
    }

    # 3. BRAIN :5099
    $brainPath = "C:\ACHE_BRAIN"
    if (Test-Port 5099) {
        Write-Ok ":5099 ya esta activo (ACHE_BRAIN)"
    } elseif (Test-Path "$brainPath\server.js") {
        Start-Process powershell -ArgumentList "-NoExit -Command cd '$brainPath'; node server.js"
        Start-Sleep -Seconds 2
        if (Test-Port 5099) {
            Write-Ok ":5099 ACTIVO"
        } else {
            Write-Err ":5099 no respondio"
        }
    } else {
        Write-Info ":5099 — ACHE_BRAIN no encontrado, omitiendo"
    }

    # 4. NGROK (si esta instalado)
    $ngrokExe = Get-Command ngrok -ErrorAction SilentlyContinue
    if ($ngrokExe -ne $null) {
        Write-Info "Ngrok detectado — si quieres tunel: ngrok http 5299"
    }

    Write-Host ""
    Write-Sep
    Write-Host "  STACK ACHE INICIADO" -ForegroundColor Green
    Write-Host "  Dashboard: http://localhost:5299" -ForegroundColor DarkGray
    Write-Host "  NEXUS:     http://localhost:8080" -ForegroundColor DarkGray
    Write-Sep
}

# ── MAIN ───────────────────────────────────────────────────────────────────
if ($Kill) {
    Stop-AllAche
    exit 0
}

if ($Status) {
    Show-Status
    exit 0
}

if ($SetKey) {
    Set-ApiKeys
    exit 0
}

# Arranque completo
Stop-AllAche
Start-AcheStack
Show-Status
