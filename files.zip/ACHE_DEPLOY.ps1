# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  ACHE DEPLOY · PCL-φ-1618 · COOPECRUCENOS R.L.                         ║
# ║  Script de Diagnóstico Total + Despliegue + Enlace entre computadoras   ║
# ║  Ejecución:  Set-ExecutionPolicy Bypass -Scope Process                   ║
# ║              .\ACHE_DEPLOY.ps1                                           ║
# ╚══════════════════════════════════════════════════════════════════════════╝

param(
    [string]$Modo        = "menu",       # menu | diagnostico | servidor | enlazar | todo
    [string]$ServidorA   = "",           # IP del servidor primario (ej: 192.168.100.10)
    [int]   $Puerto      = 7777,
    [string]$Carpeta     = "C:\ACHE"
)

# ── COLORES ───────────────────────────────────────────────────────────────
$C = @{
    Cyan    = "Cyan"; Green  = "Green"; Yellow = "Yellow"
    Red     = "Red";  White  = "White"; Magenta= "Magenta"; Gray = "Gray"
}
function W($msg, $color="White", $noNL=$false) {
    if($noNL){ Write-Host $msg -ForegroundColor $color -NoNewline }
    else      { Write-Host $msg -ForegroundColor $color }
}
function Sep { W ("─" * 70) "DarkGray" }
function OK  ($msg) { W "  ✓  $msg" "Green"   }
function WARN($msg) { W "  ⚠  $msg" "Yellow"  }
function ERR ($msg) { W "  ✗  $msg" "Red"     }
function INFO($msg) { W "  ·  $msg" "Cyan"    }

# ── BANNER ────────────────────────────────────────────────────────────────
function Show-Banner {
    Clear-Host
    W ""
    W "  ╔══════════════════════════════════════════════════════════════════╗" Cyan
    W "  ║  ⬡  ACHE DEPLOY v1  ·  PCL-φ-1618  ·  COOPECRUCENOS R.L.      ║" Cyan
    W "  ║  La Cruz, Guanacaste, Costa Rica  ·  GONZAGA-CBM-Ω-001          ║" Cyan
    W "  ╚══════════════════════════════════════════════════════════════════╝" Cyan
    W ""
}

# ════════════════════════════════════════════════════════════════════════════
# MÓDULO 1: DIAGNÓSTICO TOTAL DEL SISTEMA
# ════════════════════════════════════════════════════════════════════════════
function Invoke-Diagnostico {
    Show-Banner
    W "  DIAGNÓSTICO TOTAL DEL SISTEMA · $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" Yellow
    Sep

    $report = @{}

    # ── 1. SISTEMA OPERATIVO ─────────────────────────────────────────────
    W "`n  [1/9] SISTEMA OPERATIVO" Cyan
    $os = Get-CimInstance Win32_OperatingSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $mem = Get-CimInstance Win32_ComputerSystem
    $ramGB = [math]::Round($mem.TotalPhysicalMemory/1GB, 1)
    $ramLibreGB = [math]::Round(($os.FreePhysicalMemory * 1KB)/1GB, 1)
    OK  "$($os.Caption) $($os.Version)"
    INFO "CPU: $($cpu.Name.Trim())"
    INFO "RAM: $ramGB GB total · $ramLibreGB GB libre"
    INFO "Hostname: $env:COMPUTERNAME · Usuario: $env:USERNAME"
    $report.OS = @{nombre=$os.Caption; version=$os.Version; ram_gb=$ramGB; cpu=$cpu.Name.Trim()}

    # ── 2. RED ────────────────────────────────────────────────────────────
    W "`n  [2/9] RED E IP" Cyan
    $interfaces = Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notmatch "^127" -and $_.IPAddress -notmatch "^169" }
    $ipLocal = ""
    foreach($iface in $interfaces) {
        $estado = (Get-NetAdapter -InterfaceIndex $iface.InterfaceIndex -ErrorAction SilentlyContinue).Status
        if($estado -eq "Up") {
            OK  "Interface activa: $($iface.InterfaceAlias) → $($iface.IPAddress)"
            $ipLocal = $iface.IPAddress
        }
    }
    $gateway = (Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue | Sort-Object RouteMetric | Select-Object -First 1).NextHop
    INFO "Gateway: $gateway"

    # Test internet
    W "  Testeando internet..." Gray -noNL
    $internet = $false
    try {
        $ping = Test-Connection -ComputerName "8.8.8.8" -Count 1 -Quiet -ErrorAction Stop
        if($ping) { $internet = $true; W " ✓ OK ($([math]::Round((Test-Connection 8.8.8.8 -Count 1).Latency))ms)" Green }
        else       { W " ✗ Sin respuesta" Red }
    } catch { W " ✗ Error" Red }

    $report.Red = @{ip_local=$ipLocal; gateway=$gateway; internet=$internet}

    # ── 3. PYTHON ────────────────────────────────────────────────────────
    W "`n  [3/9] PYTHON" Cyan
    $pyVersion = ""
    try {
        $pyVersion = (python --version 2>&1).ToString().Trim()
        OK  $pyVersion
    } catch {
        try {
            $pyVersion = (python3 --version 2>&1).ToString().Trim()
            OK  $pyVersion
        } catch { ERR "Python NO encontrado — instalar desde python.org" }
    }

    # Paquetes requeridos por main_v14.py
    $paquetes = @("plotly","pandas","rich","colorama","flask","fastapi","uvicorn","requests")
    $pkgStatus = @{}
    foreach($pkg in $paquetes) {
        $installed = python -c "import $pkg; print('ok')" 2>&1
        if($installed -match "ok") {
            OK  "$pkg ✓"
            $pkgStatus[$pkg] = "ok"
        } else {
            WARN "$pkg — no instalado"
            $pkgStatus[$pkg] = "falta"
        }
    }
    $report.Python = @{version=$pyVersion; paquetes=$pkgStatus}

    # ── 4. NODE.JS ────────────────────────────────────────────────────────
    W "`n  [4/9] NODE.JS" Cyan
    try {
        $nodeV = (node --version 2>&1).ToString().Trim()
        OK  "Node.js $nodeV"
        $npmV = (npm --version 2>&1).ToString().Trim()
        OK  "npm $npmV"
    } catch { WARN "Node.js no encontrado (opcional para algunos módulos)" }

    # ── 5. CARPETA ACHE ───────────────────────────────────────────────────
    W "`n  [5/9] CARPETA ACHE · $Carpeta" Cyan
    $archivosEsperados = @(
        "main_v14.py",
        "ACHE_GENESIS_v1.html",
        "aurora_hotel_coopecrucenos_v3.html",
        "ACHE_MADRE_GOVERNMENT_v4.html",
        "hotel_v6_final.html",
        "ACHE_TRAILERO_PB_v1.html",
        "ache_memory.db",
        "MASTER.md",
        "README_ACHE.md"
    )
    $archivosEncontrados = @{}
    if(Test-Path $Carpeta) {
        OK  "Carpeta existe: $Carpeta"
        foreach($archivo in $archivosEsperados) {
            $ruta = Join-Path $Carpeta $archivo
            if(Test-Path $ruta) {
                $tam = [math]::Round((Get-Item $ruta).Length/1KB, 1)
                OK  "$archivo ($tam KB)"
                $archivosEncontrados[$archivo] = "ok"
            } else {
                WARN "$archivo — NO encontrado"
                $archivosEncontrados[$archivo] = "falta"
            }
        }
        # Archivos extra en la carpeta
        $extras = Get-ChildItem $Carpeta -File | Where-Object { $_.Name -notin $archivosEsperados }
        if($extras.Count -gt 0) {
            INFO "Archivos adicionales: $($extras.Count) ($($extras.Name -join ', '))"
        }
    } else {
        WARN "Carpeta C:\ACHE no existe — se creará al desplegar"
        $archivosEncontrados["carpeta"] = "falta"
    }
    $report.Archivos = $archivosEncontrados

    # ── 6. PUERTOS EN USO ─────────────────────────────────────────────────
    W "`n  [6/9] PUERTOS ACHE" Cyan
    $puertosACHE = @(7777, 8080, 9000, 3000, 3002, 8090, 5000)
    $puertosLibres = @()
    $puertosOcupados = @()
    foreach($p in $puertosACHE) {
        $conn = Get-NetTCPConnection -LocalPort $p -ErrorAction SilentlyContinue
        if($conn) {
            $proc = Get-Process -Id $conn.OwningProcess -ErrorAction SilentlyContinue
            WARN "Puerto $p · EN USO · proceso: $($proc.Name) (PID $($conn.OwningProcess))"
            $puertosOcupados += $p
        } else {
            OK  "Puerto $p · libre"
            $puertosLibres += $p
        }
    }
    $report.Puertos = @{libres=$puertosLibres; ocupados=$puertosOcupados}

    # ── 7. FIREWALL ───────────────────────────────────────────────────────
    W "`n  [7/9] FIREWALL WINDOWS" Cyan
    $fwProfiles = Get-NetFirewallProfile | Select-Object Name, Enabled
    foreach($fw in $fwProfiles) {
        if($fw.Enabled) { WARN "Firewall $($fw.Name): ACTIVO (puede bloquear conexiones)" }
        else            { OK  "Firewall $($fw.Name): inactivo" }
    }
    # Verificar regla ACHE existente
    $reglaACHE = Get-NetFirewallRule -DisplayName "ACHE*" -ErrorAction SilentlyContinue
    if($reglaACHE) { OK  "Regla firewall ACHE ya existe" }
    else           { WARN "No hay regla firewall para ACHE — se creará al desplegar" }
    $report.Firewall = @{perfiles=$fwProfiles; regla_ache=($null -ne $reglaACHE)}

    # ── 8. PROCESOS ACHE ACTIVOS ──────────────────────────────────────────
    W "`n  [8/9] PROCESOS ACHE ACTIVOS" Cyan
    $procesosACHE = Get-Process | Where-Object { $_.CommandLine -match "ache|aurora|main_v14|http.server" -or $_.MainWindowTitle -match "ACHE" } -ErrorAction SilentlyContinue
    if($procesosACHE) {
        foreach($proc in $procesosACHE) {
            OK  "Proceso activo: $($proc.Name) (PID $($proc.Id))"
        }
    } else {
        INFO "No hay procesos ACHE corriendo actualmente"
    }

    # Buscar python corriendo servidor
    $pyProcs = Get-Process python* -ErrorAction SilentlyContinue
    foreach($p in $pyProcs) {
        INFO "Python activo: PID $($p.Id)"
    }

    # ── 9. BASE DE DATOS ──────────────────────────────────────────────────
    W "`n  [9/9] BASE DE DATOS SQLITE" Cyan
    $dbPath = Join-Path $Carpeta "ache_memory.db"
    if(Test-Path $dbPath) {
        $dbSize = [math]::Round((Get-Item $dbPath).Length/1KB, 1)
        OK  "ache_memory.db encontrada ($dbSize KB)"
    } else {
        WARN "ache_memory.db no encontrada en $Carpeta"
        $dbPath2 = Get-ChildItem -Path "C:\" -Recurse -Name "ache_memory*.db" -ErrorAction SilentlyContinue | Select-Object -First 1
        if($dbPath2) { INFO "Encontrada en: $dbPath2" }
    }

    # ── RESUMEN FINAL ─────────────────────────────────────────────────────
    Sep
    W "`n  RESUMEN DEL DIAGNÓSTICO" Yellow
    W ""
    $checks = @(
        @{n="Sistema Operativo"; ok=$true},
        @{n="Conexión internet"; ok=$internet},
        @{n="IP local detectada"; ok=($ipLocal -ne "")},
        @{n="Python instalado"; ok=($pyVersion -ne "")},
        @{n="Carpeta C:\ACHE"; ok=(Test-Path $Carpeta)},
        @{n="Puertos disponibles"; ok=($puertosLibres.Count -gt 0)}
    )
    $pasa = 0
    foreach($c in $checks) {
        if($c.ok) { OK  $c.n; $pasa++ }
        else       { WARN $c.n }
    }
    W ""
    W "  $pasa/$($checks.Count) verificaciones OK" $(if($pasa -ge 4){"Green"}else{"Yellow"})
    W "  IP Local: $ipLocal" Cyan
    W "  Gateway:  $gateway" Cyan
    W ""

    # Guardar reporte JSON
    $reportPath = Join-Path $Carpeta "ache_diagnostico_$(Get-Date -Format 'yyyyMMdd_HHmmss').json"
    if(Test-Path $Carpeta) {
        $report | ConvertTo-Json -Depth 5 | Out-File $reportPath -Encoding UTF8
        OK  "Reporte guardado: $reportPath"
    }

    return @{ip=$ipLocal; gateway=$gateway; internet=$internet; python=($pyVersion -ne "")}
}

# ════════════════════════════════════════════════════════════════════════════
# MÓDULO 2: PREPARAR Y DESPLEGAR SERVIDOR
# ════════════════════════════════════════════════════════════════════════════
function Invoke-Despliegue {
    param($ipLocal)

    Show-Banner
    W "  PREPARANDO DESPLIEGUE · IP: $ipLocal" Yellow
    Sep

    # 1. Crear estructura de carpetas
    W "`n  [1/6] CREANDO ESTRUCTURA DE CARPETAS" Cyan
    $subcarpetas = @("data","modules","logs","exports","backups","static","sync")
    foreach($sub in @($Carpeta) + ($subcarpetas | ForEach-Object { Join-Path $Carpeta $_ })) {
        if(-not (Test-Path $sub)) {
            New-Item -ItemType Directory -Force -Path $sub | Out-Null
            OK  "Creada: $sub"
        } else {
            INFO "Ya existe: $sub"
        }
    }

    # 2. Instalar dependencias Python
    W "`n  [2/6] INSTALANDO DEPENDENCIAS PYTHON" Cyan
    $deps = @("plotly","pandas","rich","colorama","flask","requests","websockets")
    foreach($dep in $deps) {
        W "  Instalando $dep..." Gray -noNL
        $result = python -m pip install $dep --quiet 2>&1
        if($LASTEXITCODE -eq 0) { W " ✓" Green }
        else { W " ⚠ (verificar)" Yellow }
    }

    # 3. Crear el servidor redundante Python
    W "`n  [3/6] GENERANDO ache_server.py" Cyan
    $serverPy = @'
#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════╗
║  ACHE SERVER · Servidor Redundante + Bridge + Sync              ║
║  PCL-φ-1618 · COOPECRUCENOS R.L. · La Cruz, Guanacaste         ║
║  Ejecutar: python ache_server.py                                 ║
╚══════════════════════════════════════════════════════════════════╝
"""
import os, sys, json, sqlite3, hashlib, time, threading, socket
import datetime, logging, urllib.request, urllib.error
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

# ── CONFIG ──────────────────────────────────────────────────────
VERSION     = "1.0"
BASE_DIR    = Path(__file__).parent
DB_PATH     = BASE_DIR / "data" / "ache_server.db"
LOG_PATH    = BASE_DIR / "logs" / f"ache_{datetime.date.today()}.log"
SYNC_PATH   = BASE_DIR / "sync"
PUERTO      = 7777
HOST        = "0.0.0.0"

# Nodos conocidos del ecosistema (se actualiza dinámicamente)
NODOS_CONOCIDOS = [
    {"id": "GONZAGA-001", "nombre": "ACHE SUPREMO v5",   "puerto": 8080},
    {"id": "NEXUS-001",   "nombre": "ACHE NEXUS v2.0",   "puerto": 9000},
    {"id": "AURORA-001",  "nombre": "AURORA Hotel v1.0",  "puerto": 7777},
    {"id": "MONEY-001",   "nombre": "ACHE MONEY v1.0",    "puerto": 3000},
    {"id": "NEPTUNO-001", "nombre": "ACHE NEPTUNO α",     "puerto": 8090},
]

# ── LOGGING ─────────────────────────────────────────────────────
LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_PATH, encoding="utf-8"),
        logging.StreamHandler(sys.stdout)
    ]
)
log = logging.getLogger("ACHE")

# ── BASE DE DATOS ────────────────────────────────────────────────
def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""CREATE TABLE IF NOT EXISTS eventos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, tipo TEXT, agente TEXT,
        payload TEXT, hash TEXT
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS nodos_red (
        id TEXT PRIMARY KEY, ip TEXT, puerto INTEGER,
        nombre TEXT, estado TEXT, ultimo_ping TEXT,
        es_primario INTEGER DEFAULT 0
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS sync_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ts TEXT, origen TEXT, destino TEXT,
        archivo TEXT, estado TEXT
    )""")
    conn.execute("""CREATE TABLE IF NOT EXISTS config (
        clave TEXT PRIMARY KEY, valor TEXT
    )""")
    conn.commit()
    conn.close()
    log.info("DB inicializada: %s", DB_PATH)

def registrar_evento(tipo, agente, payload):
    ts = datetime.datetime.now().isoformat()
    h = hashlib.sha256(f"{ts}{tipo}{agente}{json.dumps(payload)}".encode()).hexdigest()[:16]
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT INTO eventos (ts, tipo, agente, payload, hash) VALUES (?,?,?,?,?)",
        (ts, tipo, agente, json.dumps(payload, ensure_ascii=False), h)
    )
    conn.commit()
    conn.close()
    return h

def get_config(clave, default=""):
    try:
        conn = sqlite3.connect(DB_PATH)
        row = conn.execute("SELECT valor FROM config WHERE clave=?", (clave,)).fetchone()
        conn.close()
        return row[0] if row else default
    except:
        return default

def set_config(clave, valor):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("INSERT OR REPLACE INTO config (clave, valor) VALUES (?,?)", (clave, valor))
    conn.commit()
    conn.close()

# ── ESTADO GLOBAL ────────────────────────────────────────────────
ESTADO = {
    "inicio": datetime.datetime.now().isoformat(),
    "version": VERSION,
    "nodo_id": f"REDUNDANTE-{socket.gethostname()}",
    "ip_local": "",
    "puerto": PUERTO,
    "servidor_primario": "",
    "nodos_activos": [],
    "total_eventos": 0,
    "total_requests": 0,
    "uptime_segundos": 0,
}

def get_ip_local():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

# ── DISCOVERY: buscar nodos activos en red ───────────────────────
def descubrir_nodos():
    """Escanea puertos conocidos en la red local para encontrar nodos ACHE."""
    ip_local = ESTADO["ip_local"]
    if not ip_local or ip_local == "127.0.0.1":
        return

    red_base = ".".join(ip_local.split(".")[:3])
    nodos_encontrados = []

    # Primero verificar nodos conocidos en localhost
    for nodo in NODOS_CONOCIDOS:
        urls = [
            f"http://localhost:{nodo['puerto']}",
            f"http://127.0.0.1:{nodo['puerto']}",
        ]
        for url in urls:
            try:
                req = urllib.request.Request(url, method="GET")
                with urllib.request.urlopen(req, timeout=1) as resp:
                    nodos_encontrados.append({
                        "id": nodo["id"], "ip": "localhost",
                        "puerto": nodo["puerto"], "nombre": nodo["nombre"],
                        "estado": "activo"
                    })
                    log.info("Nodo local detectado: %s en :%s", nodo["id"], nodo["puerto"])
                    break
            except:
                pass

    ESTADO["nodos_activos"] = nodos_encontrados

    # Registrar en DB
    if nodos_encontrados:
        conn = sqlite3.connect(DB_PATH)
        for n in nodos_encontrados:
            conn.execute("""INSERT OR REPLACE INTO nodos_red
                (id, ip, puerto, nombre, estado, ultimo_ping)
                VALUES (?,?,?,?,?,?)""",
                (n["id"], n["ip"], n["puerto"], n["nombre"],
                 n["estado"], datetime.datetime.now().isoformat())
            )
        conn.commit()
        conn.close()
        registrar_evento("DISCOVERY", "bridge", {"nodos": len(nodos_encontrados)})

def ping_servidor_primario():
    """Verifica si el servidor primario está activo. Si no, este nodo toma rol primario."""
    primario = ESTADO.get("servidor_primario", "")
    if not primario:
        return

    try:
        with urllib.request.urlopen(f"http://{primario}/estado", timeout=3) as resp:
            data = json.loads(resp.read())
            log.info("Servidor primario activo: %s", primario)
            registrar_evento("HEARTBEAT", "bridge", {"primario": primario, "estado": "activo"})
    except Exception as e:
        log.warning("Servidor primario NO responde: %s — %s", primario, e)
        registrar_evento("FAILOVER", "bridge", {"primario": primario, "error": str(e)})
        log.warning("⚡ ACTIVANDO MODO PRIMARIO REDUNDANTE")
        ESTADO["rol"] = "PRIMARIO_REDUNDANTE"

# ── SINCRONIZACIÓN DE ARCHIVOS ───────────────────────────────────
def sync_con_primario(ip_primario):
    """Sincroniza archivos críticos con el servidor primario."""
    archivos_sync = ["ache_memory.db", "MASTER.md", "adn.json"]
    SYNC_PATH.mkdir(parents=True, exist_ok=True)

    for archivo in archivos_sync:
        try:
            url = f"http://{ip_primario}/sync/{archivo}"
            dest = SYNC_PATH / archivo
            urllib.request.urlretrieve(url, dest)
            log.info("Sincronizado: %s", archivo)
            conn = sqlite3.connect(DB_PATH)
            conn.execute(
                "INSERT INTO sync_log (ts, origen, destino, archivo, estado) VALUES (?,?,?,?,?)",
                (datetime.datetime.now().isoformat(), ip_primario,
                 ESTADO["ip_local"], archivo, "ok")
            )
            conn.commit()
            conn.close()
        except Exception as e:
            log.warning("Error sync %s: %s", archivo, e)

# ── HTTP HANDLER ─────────────────────────────────────────────────
class ACHEHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass  # silenciar log por defecto

    def send_json(self, data, code=200):
        body = json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Content-Length", len(body))
        self.end_headers()
        self.wfile.write(body)
        ESTADO["total_requests"] += 1

    def send_html(self, html_path):
        try:
            with open(html_path, "rb") as f:
                content = f.read()
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", len(content))
            self.end_headers()
            self.wfile.write(content)
        except FileNotFoundError:
            self.send_json({"error": "archivo no encontrado"}, 404)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        ruta = parsed.path.rstrip("/") or "/"

        # ── Raíz: servir ACHE_GENESIS_v1.html ──────────────
        if ruta == "/" or ruta == "/index":
            genesis = BASE_DIR / "ACHE_GENESIS_v1.html"
            hotel   = BASE_DIR / "hotel_v6_final.html"
            aurora  = BASE_DIR / "aurora_hotel_coopecrucenos_v3.html"
            for f in [genesis, hotel, aurora]:
                if f.exists():
                    self.send_html(f)
                    return
            self.send_json({"msg": "ACHE Server activo — sube ACHE_GENESIS_v1.html a C:\\ACHE"})
            return

        # ── Estado del servidor ──────────────────────────────
        if ruta == "/estado":
            uptime = (datetime.datetime.now() - datetime.datetime.fromisoformat(ESTADO["inicio"])).seconds
            ESTADO["uptime_segundos"] = uptime
            conn = sqlite3.connect(DB_PATH)
            total_ev = conn.execute("SELECT COUNT(*) FROM eventos").fetchone()[0]
            conn.close()
            ESTADO["total_eventos"] = total_ev
            self.send_json({
                **ESTADO,
                "ts": datetime.datetime.now().isoformat(),
                "status": "OPERACIONAL",
                "ccps": 13,
                "trl": "TRL-5",
            })
            return

        # ── Diagnóstico completo ─────────────────────────────
        if ruta == "/diagnostico":
            conn = sqlite3.connect(DB_PATH)
            eventos = conn.execute("SELECT * FROM eventos ORDER BY id DESC LIMIT 20").fetchall()
            nodos = conn.execute("SELECT * FROM nodos_red").fetchall()
            conn.close()
            self.send_json({
                "estado": ESTADO,
                "ip_local": ESTADO["ip_local"],
                "nodos_activos": ESTADO["nodos_activos"],
                "ultimos_eventos": [{"id":e[0],"ts":e[1],"tipo":e[2],"agente":e[3],"hash":e[5]} for e in eventos],
            })
            return

        # ── Nodos en la red ──────────────────────────────────
        if ruta == "/nodos":
            self.send_json({
                "nodos": ESTADO["nodos_activos"],
                "total": len(ESTADO["nodos_activos"])
            })
            return

        # ── Sync: servir archivos para sincronización ────────
        if ruta.startswith("/sync/"):
            archivo = ruta.replace("/sync/", "")
            rutas_posibles = [
                BASE_DIR / archivo,
                BASE_DIR / "data" / archivo,
                BASE_DIR / "sync" / archivo,
            ]
            for ruta_arch in rutas_posibles:
                if ruta_arch.exists():
                    with open(ruta_arch, "rb") as f:
                        content = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/octet-stream")
                    self.send_header("Content-Length", len(content))
                    self.end_headers()
                    self.wfile.write(content)
                    return
            self.send_json({"error": f"archivo {archivo} no encontrado"}, 404)
            return

        # ── Healthcheck simple ───────────────────────────────
        if ruta == "/ping":
            self.send_json({"pong": True, "nodo": ESTADO["nodo_id"], "ts": datetime.datetime.now().isoformat()})
            return

        # ── Servir archivos estáticos ────────────────────────
        for ext, mime in [(".html","text/html"),(".js","application/javascript"),(".css","text/css"),(".json","application/json")]:
            if ruta.endswith(ext):
                path = BASE_DIR / ruta.lstrip("/")
                if path.exists():
                    with open(path, "rb") as f:
                        content = f.read()
                    self.send_response(200)
                    self.send_header("Content-Type", mime+"; charset=utf-8")
                    self.send_header("Content-Length", len(content))
                    self.end_headers()
                    self.wfile.write(content)
                    return

        self.send_json({"error": "ruta no encontrada", "ruta": ruta}, 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        ruta = parsed.path.rstrip("/")
        content_len = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_len) if content_len > 0 else b"{}"
        try:
            data = json.loads(body)
        except:
            data = {}

        # ── Registrar evento desde otro nodo ────────────────
        if ruta == "/evento":
            h = registrar_evento(
                data.get("tipo", "EXTERNO"),
                data.get("agente", "unknown"),
                data.get("payload", {})
            )
            self.send_json({"ok": True, "hash": h})
            return

        # ── Configurar servidor primario ─────────────────────
        if ruta == "/config/primario":
            ip_p = data.get("ip", "")
            set_config("servidor_primario", ip_p)
            ESTADO["servidor_primario"] = ip_p
            registrar_evento("CONFIG", "admin", {"servidor_primario": ip_p})
            log.info("Servidor primario configurado: %s", ip_p)
            self.send_json({"ok": True, "servidor_primario": ip_p})
            return

        # ── Trigger de sync manual ───────────────────────────
        if ruta == "/sync/trigger":
            ip_p = data.get("ip_primario", ESTADO.get("servidor_primario", ""))
            if ip_p:
                threading.Thread(target=sync_con_primario, args=(ip_p,), daemon=True).start()
                self.send_json({"ok": True, "msg": f"Sync iniciada con {ip_p}"})
            else:
                self.send_json({"ok": False, "msg": "No hay servidor primario configurado"}, 400)
            return

        self.send_json({"error": "endpoint no encontrado"}, 404)

# ── HILO DE MONITOREO ────────────────────────────────────────────
def hilo_monitor():
    """Corre en background: descubre nodos, hace ping al primario."""
    contador = 0
    while True:
        time.sleep(30)
        contador += 1
        try:
            if contador % 2 == 0:  # cada 60s: discovery
                descubrir_nodos()
            primario = ESTADO.get("servidor_primario", "")
            if primario:
                ping_servidor_primario()
        except Exception as e:
            log.error("Error en monitor: %s", e)

# ── MAIN ─────────────────────────────────────────────────────────
def main():
    init_db()
    ESTADO["ip_local"] = get_ip_local()
    ESTADO["servidor_primario"] = get_config("servidor_primario", "")

    # Banner
    print(f"""
╔══════════════════════════════════════════════════════════════╗
║  ⬡  ACHE SERVER v{VERSION} · GONZAGA-CBM-Ω-001                   ║
║  COOPECRUCENOS R.L. · La Cruz, Guanacaste, Costa Rica       ║
╠══════════════════════════════════════════════════════════════╣
║  Nodo ID:  {ESTADO['nodo_id']:<50} ║
║  IP Local: {ESTADO['ip_local']:<50} ║
║  Puerto:   {PUERTO:<50} ║
╠══════════════════════════════════════════════════════════════╣
║  Endpoints disponibles:                                      ║
║    GET  /           → ACHE GENESIS v1 (frontend)            ║
║    GET  /estado     → Estado completo del servidor           ║
║    GET  /diagnostico → Diagnóstico + eventos + nodos         ║
║    GET  /nodos      → Nodos activos en red                   ║
║    GET  /ping       → Healthcheck rápido                     ║
║    POST /evento     → Registrar evento desde otro nodo       ║
║    POST /config/primario → Configurar servidor primario      ║
║    POST /sync/trigger → Sincronizar con servidor primario    ║
╚══════════════════════════════════════════════════════════════╝
""")

    registrar_evento("BOOT", "kernel", {
        "version": VERSION,
        "ip": ESTADO["ip_local"],
        "puerto": PUERTO,
        "nodo_id": ESTADO["nodo_id"]
    })

    # Iniciar hilo de monitoreo
    threading.Thread(target=hilo_monitor, daemon=True).start()
    log.info("Monitor de red iniciado")

    # Discovery inicial
    threading.Thread(target=descubrir_nodos, daemon=True).start()

    # Iniciar servidor HTTP
    servidor = HTTPServer((HOST, PUERTO), ACHEHandler)
    ip = ESTADO["ip_local"]
    print(f"\n  ✓ Servidor corriendo en:")
    print(f"    → Local:      http://localhost:{PUERTO}")
    print(f"    → Red local:  http://{ip}:{PUERTO}")
    print(f"    → Estado:     http://{ip}:{PUERTO}/estado")
    print(f"    → Diagnóstico: http://{ip}:{PUERTO}/diagnostico\n")
    print(f"  Ctrl+C para detener\n")

    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\n  ⬡ ACHE Server detenido. ADN persiste.")
        registrar_evento("SHUTDOWN", "kernel", {"motivo": "KeyboardInterrupt"})

if __name__ == "__main__":
    main()
'@

    $serverPath = Join-Path $Carpeta "ache_server.py"
    $serverPy | Out-File -FilePath $serverPath -Encoding UTF8
    OK  "ache_server.py generado: $serverPath"

    # 4. Crear regla de firewall
    W "`n  [4/6] CONFIGURANDO FIREWALL" Cyan
    $puertosAbrir = @(7777, 8080)
    foreach($p in $puertosAbrir) {
        $regla = Get-NetFirewallRule -DisplayName "ACHE Puerto $p" -ErrorAction SilentlyContinue
        if(-not $regla) {
            try {
                New-NetFirewallRule -DisplayName "ACHE Puerto $p" `
                    -Direction Inbound -Protocol TCP -LocalPort $p `
                    -Action Allow -Profile Any -ErrorAction Stop | Out-Null
                OK  "Regla firewall creada para puerto $p"
            } catch {
                WARN "No se pudo crear regla (ejecutar como Administrador): puerto $p"
            }
        } else {
            OK  "Regla ya existe para puerto $p"
        }
    }

    # 5. Crear script de inicio rápido
    W "`n  [5/6] CREANDO SCRIPTS DE INICIO" Cyan

    $startServer = @"
@echo off
title ACHE SERVER - COOPECRUCENOS
echo.
echo   ACHE SERVER - Iniciando...
echo.
cd /d C:\ACHE
python ache_server.py
pause
"@
    $startServer | Out-File (Join-Path $Carpeta "INICIAR_SERVIDOR.bat") -Encoding ASCII
    OK  "INICIAR_SERVIDOR.bat creado"

    $startMain = @"
@echo off
title ACHE MAIN v14 - COOPECRUCENOS
cd /d C:\ACHE
python main_v14.py --modo servidor
pause
"@
    $startMain | Out-File (Join-Path $Carpeta "INICIAR_MAIN_V14.bat") -Encoding ASCII
    OK  "INICIAR_MAIN_V14.bat creado"

    # Atajo en escritorio
    $WshShell = New-Object -comObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\ACHE SERVER.lnk")
    $Shortcut.TargetPath = Join-Path $Carpeta "INICIAR_SERVIDOR.bat"
    $Shortcut.WorkingDirectory = $Carpeta
    $Shortcut.IconLocation = "C:\Windows\System32\shell32.dll,15"
    $Shortcut.Save()
    OK  "Acceso directo creado en el Escritorio"

    # 6. Crear archivo de configuración
    W "`n  [6/6] CREANDO ache_config.json" Cyan
    $config = @{
        version       = "1.0"
        nodo_id       = "GONZAGA-$(hostname)"
        ip_local      = $ipLocal
        puerto        = $Puerto
        carpeta       = $Carpeta
        servidor_primario = $ServidorA
        created_at    = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        ccps          = 13
        trl           = "TRL-5"
        org           = "COOPECRUCENOS R.L."
        ubicacion     = "La Cruz, Guanacaste, Costa Rica"
        operador      = "PCL-phi-1618"
    }
    $config | ConvertTo-Json | Out-File (Join-Path $Carpeta "ache_config.json") -Encoding UTF8
    OK  "ache_config.json guardado"

    Sep
    W ""
    W "  DESPLIEGUE COMPLETADO" Green
    W ""
    W "  Para iniciar el servidor:" Cyan
    W "    Opción A: Doble clic en 'ACHE SERVER' en el Escritorio" White
    W "    Opción B: cd C:\ACHE && python ache_server.py" White
    W ""
    W "  URLs disponibles:" Cyan
    W "    http://localhost:7777         (esta computadora)" White
    W "    http://${ipLocal}:7777        (desde tu red local)" White
    W ""
}

# ════════════════════════════════════════════════════════════════════════════
# MÓDULO 3: ENLAZAR DOS COMPUTADORAS
# ════════════════════════════════════════════════════════════════════════════
function Invoke-Enlazar {
    param($ipLocal)

    Show-Banner
    W "  ENLAZAR COMPUTADORAS · SERVIDOR REDUNDANTE" Yellow
    Sep

    W ""
    W "  Esta computadora: $ipLocal" Cyan
    W ""

    # Pedir IP del servidor primario si no se pasó
    if(-not $ServidorA) {
        W "  IP de la otra computadora (servidor primario):" White
        W "  (ej: 192.168.100.10 — la IP que ves en ipconfig de la otra PC)" Gray
        $ServidorA = Read-Host "  IP servidor primario"
    }

    if(-not $ServidorA) {
        ERR "No se proporcionó IP del servidor primario"
        return
    }

    W ""
    W "  [1/4] VERIFICANDO CONECTIVIDAD CON $ServidorA" Cyan
    $ping = Test-Connection -ComputerName $ServidorA -Count 2 -Quiet -ErrorAction SilentlyContinue
    if($ping) {
        OK  "Ping OK a $ServidorA"
    } else {
        WARN "Sin respuesta ping a $ServidorA"
        WARN "Verificá que ambas computadoras estén en la misma red WiFi"
    }

    W "`n  [2/4] VERIFICANDO PUERTO ACHE EN $ServidorA" Cyan
    $puertosTestear = @(7777, 8080, 3000)
    $puertoEncontrado = 0
    foreach($p in $puertosTestear) {
        $tcp = Test-NetConnection -ComputerName $ServidorA -Port $p -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
        if($tcp.TcpTestSucceeded) {
            OK  "Puerto $p responde en $ServidorA — ACHE activo"
            $puertoEncontrado = $p
            break
        } else {
            INFO "Puerto $p en $ServidorA: sin respuesta"
        }
    }

    if($puertoEncontrado -eq 0) {
        WARN "No se detectó servidor ACHE activo en $ServidorA"
        WARN "Asegurate de iniciar ache_server.py en la otra computadora primero"
    }

    W "`n  [3/4] CONFIGURANDO ESTE NODO COMO REDUNDANTE" Cyan
    # Guardar IP primario en config
    $configPath = Join-Path $Carpeta "ache_config.json"
    if(Test-Path $configPath) {
        $cfg = Get-Content $configPath | ConvertFrom-Json
        $cfg | Add-Member -NotePropertyName "servidor_primario" -NotePropertyValue $ServidorA -Force
        $cfg | ConvertTo-Json | Out-File $configPath -Encoding UTF8
        OK  "Config actualizada: servidor_primario = $ServidorA"
    }

    # Notificar al servidor local vía POST si está corriendo
    try {
        $body = @{ip=$ServidorA} | ConvertTo-Json
        $resp = Invoke-RestMethod -Uri "http://localhost:$Puerto/config/primario" `
            -Method POST -Body $body -ContentType "application/json" -TimeoutSec 3
        OK  "Servidor local notificado del primario"
    } catch {
        INFO "Servidor local no activo aún — se configurará al iniciar"
    }

    W "`n  [4/4] GENERANDO SCRIPT DE ENLACE PERMANENTE" Cyan
    $enlaceScript = @"
@echo off
title ACHE ENLACE - Sync con servidor primario
echo.
echo   ACHE ENLACE
echo   Esta computadora: $ipLocal (REDUNDANTE)
echo   Servidor primario: $ServidorA
echo.
cd /d C:\ACHE
python -c "
import urllib.request, json, time
primario = '$ServidorA'
local_puerto = $Puerto
print(f'Enlazando con servidor primario: {primario}')
while True:
    try:
        with urllib.request.urlopen(f'http://{primario}/ping', timeout=3) as r:
            data = json.loads(r.read())
            print(f'  OK - Primario activo: {data.get(chr(110)+chr(111)+chr(100)+chr(111))}')
    except Exception as e:
        print(f'  WARN - Primario sin respuesta: {e}')
    try:
        body = json.dumps({'tipo':'HEARTBEAT','agente':'REDUNDANTE','payload':{'ip':'$ipLocal'}}).encode()
        req = urllib.request.Request(f'http://{primario}/evento', data=body, headers={'Content-Type':'application/json'}, method='POST')
        urllib.request.urlopen(req, timeout=3)
        print('  Heartbeat enviado al primario')
    except:
        pass
    time.sleep(30)
"
pause
"@
    $enlaceScript | Out-File (Join-Path $Carpeta "ENLACE_PRIMARIO.bat") -Encoding ASCII
    OK  "ENLACE_PRIMARIO.bat creado"

    Sep
    W ""
    W "  ENLACE CONFIGURADO" Green
    W ""
    W "  Esta PC:           $ipLocal (REDUNDANTE/SECUNDARIO)" White
    W "  Servidor primario: $ServidorA" White
    W ""
    W "  Para activar el enlace permanente:" Cyan
    W "    Doble clic en C:\ACHE\ENLACE_PRIMARIO.bat" White
    W ""
    if($puertoEncontrado -gt 0) {
        W "  Acceder al servidor primario desde aquí:" Cyan
        W "    http://${ServidorA}:${puertoEncontrado}" White
    }
    W ""
}

# ════════════════════════════════════════════════════════════════════════════
# MENÚ PRINCIPAL
# ════════════════════════════════════════════════════════════════════════════
function Show-Menu {
    param($ipLocal)
    Show-Banner
    W "  IP detectada: $ipLocal" Cyan
    W ""
    W "  ┌─────────────────────────────────────────────┐" White
    W "  │  1  · Diagnóstico completo del sistema      │" White
    W "  │  2  · Preparar + desplegar servidor         │" White
    W "  │  3  · Enlazar con otro servidor (redundante)│" White
    W "  │  4  · Todo: diagnóstico + deploy + enlazar  │" White
    W "  │  5  · Iniciar servidor ahora (python)       │" White
    W "  │  0  · Salir                                 │" White
    W "  └─────────────────────────────────────────────┘" White
    W ""
    $opcion = Read-Host "  Opción"
    return $opcion
}

# ════════════════════════════════════════════════════════════════════════════
# PUNTO DE ENTRADA
# ════════════════════════════════════════════════════════════════════════════
function Main {
    # Detectar IP local
    $ipLocal = ""
    try {
        $ifaces = Get-NetIPAddress -AddressFamily IPv4 | Where-Object {
            $_.IPAddress -notmatch "^127" -and $_.IPAddress -notmatch "^169"
        }
        foreach($iface in $ifaces) {
            $estado = (Get-NetAdapter -InterfaceIndex $iface.InterfaceIndex -ErrorAction SilentlyContinue).Status
            if($estado -eq "Up") { $ipLocal = $iface.IPAddress; break }
        }
    } catch {}
    if(-not $ipLocal) { $ipLocal = "192.168.100.134" }  # fallback conocido

    if($Modo -eq "diagnostico") {
        Invoke-Diagnostico | Out-Null
    } elseif($Modo -eq "servidor") {
        Invoke-Despliegue -ipLocal $ipLocal
    } elseif($Modo -eq "enlazar") {
        Invoke-Enlazar -ipLocal $ipLocal
    } elseif($Modo -eq "todo") {
        $diag = Invoke-Diagnostico
        Invoke-Despliegue -ipLocal $ipLocal
        Invoke-Enlazar -ipLocal $ipLocal
    } else {
        # Menú interactivo
        while($true) {
            $op = Show-Menu -ipLocal $ipLocal
            switch($op) {
                "1" { Invoke-Diagnostico | Out-Null }
                "2" { Invoke-Despliegue -ipLocal $ipLocal }
                "3" { Invoke-Enlazar -ipLocal $ipLocal }
                "4" {
                    $diag = Invoke-Diagnostico
                    Invoke-Despliegue -ipLocal $ipLocal
                    Invoke-Enlazar -ipLocal $ipLocal
                }
                "5" {
                    W "`n  Iniciando servidor en puerto $Puerto..." Cyan
                    $serverPath = Join-Path $Carpeta "ache_server.py"
                    if(Test-Path $serverPath) {
                        Start-Process python -ArgumentList $serverPath -WorkingDirectory $Carpeta
                        W "  ✓ Servidor iniciado" Green
                        W "    http://localhost:$Puerto" Cyan
                        W "    http://${ipLocal}:$Puerto" Cyan
                        Start-Sleep 2
                        Start-Process "http://localhost:$Puerto"
                    } else {
                        ERR "ache_server.py no encontrado — ejecutá primero la opción 2"
                    }
                }
                "0" { W "`n  ⬡ Hasta pronto. ADN persiste." Cyan; break }
                default { WARN "Opción no válida" }
            }
            if($op -eq "0") { break }
            W ""
            Read-Host "  Presioná Enter para continuar"
        }
    }
}

Main
