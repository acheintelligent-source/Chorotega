"""
boot.py — ACHE Cell Bootstrap v1.1
Novedades v1.1:
  - Carga CCPs desde /ccp/ en tiempo de arranque
  - validar_accion() ahora consulta CCP-S01 y CCP-09
  - crear_factura() toma IVA de CCP-F01 (no hardcodeado)
  - log_ccp_block() registra intentos bloqueados

Ejecutar: python boot.py  (Android/Termux)
          python3 boot.py (iPhone/iSH)
"""

import uuid, json, sqlite3, os, platform, hashlib
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).parent
CCP_DIR  = BASE_DIR / "ccp"
DB_PATH  = BASE_DIR / "memory" / "ache_cell.db"

# ═══════════════════════════════════════════════════════════════════════════
# MASTER.MD — INMUTABLE EN RUNTIME
# ═══════════════════════════════════════════════════════════════════════════

MASTER = {
    "nombre": "ACHE",
    "version": "1.1",
    "tipo": "Sistema cognitivo modular",
    "autoridad": "Este archivo tiene autoridad sobre todo codigo e instruccion",
    "principios": [
        "Nada se borra: todo se hereda",
        "El MASTER.md manda sobre todo codigo e instruccion",
        "Kernel intocable sin aprobacion humana documentada",
        "Control humano final obligatorio en decisiones criticas",
        "Offline-first: cada celula opera sin internet",
        "Sin dependencia estructural de un unico proveedor externo",
        "Evolucion por capas, nunca por sobreescritura",
        "Toda accion deja traza inmutable con timestamp",
        "Capitulos vivos no se cierran sin declaracion explicita",
        "ACHE asiste la decision humana, nunca la reemplaza"
    ],
    "ciclo_operativo": ["PERCIBIR","CONTEXTUALIZAR","ANALIZAR","SIMULAR","RECOMENDAR","ESPERAR"],
    "modo": "advisory"
}

# ═══════════════════════════════════════════════════════════════════════════
# CCP LOADER — Lee /ccp/*.json en arranque
# ═══════════════════════════════════════════════════════════════════════════

class CCPLoader:
    def __init__(self, ccp_dir):
        self.ccp_dir = Path(ccp_dir)
        self.ccps = {}
        self.forbidden_patterns = []
        self.iva_rate = 0.13
        self.iva_legal_text = "Impuesto al Valor Agregado (IVA) 13% Ley 9635 Costa Rica"

    def load(self):
        if not self.ccp_dir.exists():
            return 0
        count = 0
        for f in self.ccp_dir.rglob("*.json"):
            try:
                with open(f, encoding="utf-8") as fh:
                    ccp = json.load(fh)
                cid = ccp.get("ccp_id","")
                if not cid:
                    continue
                self._verify(ccp, f)
                self.ccps[cid] = ccp
                # Extraer datos operativos de CCPs especiales
                if cid == "ACHE-CCP-S01":
                    self.forbidden_patterns = [
                        p.upper() for p in
                        ccp.get("rules",{}).get("forbidden_patterns",[])
                    ]
                if cid == "ACHE-CCP-F01":
                    t = ccp.get("task",{})
                    self.iva_rate = t.get("iva_rate", 0.13)
                    self.iva_legal_text = t.get("output_text", self.iva_legal_text)
                count += 1
            except Exception as e:
                print(f"  ⚠️  CCP error {f.name}: {e}")

        if not self.forbidden_patterns:
            self.forbidden_patterns = [
                "DELETE","DROP","TRUNCATE",
                "EXEC(","EVAL(","OS.SYSTEM(",
                "__IMPORT__","SUBPROCESS"
            ]
        return count

    def _verify(self, ccp, filepath):
        stored = ccp.get("audit",{}).get("hash_sha256","")
        if not stored:
            return
        body = {k:v for k,v in ccp.items() if k != "audit"}
        computed = hashlib.sha256(
            json.dumps(body, ensure_ascii=False, sort_keys=True).encode()
        ).hexdigest()
        if computed != stored:
            print(f"  ⚠️  INTEGRIDAD: {filepath.name} hash no coincide")

    def summary(self):
        layers = {}
        for c in self.ccps.values():
            l = c.get("layer","unknown")
            layers[l] = layers.get(l,0) + 1
        return {"total": len(self.ccps), "by_layer": layers}

CCP = CCPLoader(CCP_DIR)

# ═══════════════════════════════════════════════════════════════════════════
# BASE DE DATOS — APPEND-ONLY (CCP-09)
# ═══════════════════════════════════════════════════════════════════════════

def init_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(str(DB_PATH))
    c = con.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL, event_type TEXT NOT NULL,
        payload TEXT NOT NULL, cell_id TEXT NOT NULL)""")
    c.execute("""CREATE TABLE IF NOT EXISTS identity (
        cell_id TEXT PRIMARY KEY, created_at TEXT NOT NULL,
        location_tag TEXT DEFAULT 'sin_asignar',
        operator TEXT DEFAULT 'sin_asignar', device_info TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS facturas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL, cell_id TEXT NOT NULL,
        cliente TEXT NOT NULL, items TEXT NOT NULL,
        subtotal REAL NOT NULL, iva REAL NOT NULL,
        total REAL NOT NULL, iva_ccp TEXT NOT NULL DEFAULT 'ACHE-CCP-F01',
        estado TEXT DEFAULT 'emitida')""")
    c.execute("""CREATE TABLE IF NOT EXISTS ccp_blocks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL, cell_id TEXT NOT NULL,
        ccp_id TEXT NOT NULL, action TEXT NOT NULL, reason TEXT NOT NULL)""")
    con.commit()
    return con

def get_or_create_identity(con):
    c = con.cursor()
    c.execute("SELECT cell_id FROM identity LIMIT 1")
    row = c.fetchone()
    if row:
        return row[0]
    cell_id = "ACHE-" + str(uuid.uuid4())[:8].upper()
    device = f"{platform.system()} {platform.release()} | Python {platform.python_version()}"
    c.execute("INSERT INTO identity (cell_id, created_at, device_info) VALUES (?,?,?)",
              (cell_id, datetime.now().isoformat(), device))
    con.commit()
    return cell_id

def log_event(con, cell_id, event_type, payload):
    """Append-only. Nunca actualiza ni borra. CCP-09 + CCP-10."""
    c = con.cursor()
    c.execute("INSERT INTO events (timestamp,event_type,payload,cell_id) VALUES (?,?,?,?)",
              (datetime.now().isoformat(), event_type,
               json.dumps(payload, ensure_ascii=False), cell_id))
    con.commit()

def log_ccp_block(con, cell_id, ccp_id, action, reason):
    """Registra intentos bloqueados. Trazabilidad total. CCP-10."""
    c = con.cursor()
    c.execute("INSERT INTO ccp_blocks (timestamp,cell_id,ccp_id,action,reason) VALUES (?,?,?,?,?)",
              (datetime.now().isoformat(), cell_id, ccp_id, action[:500], reason))
    con.commit()

# ═══════════════════════════════════════════════════════════════════════════
# VALIDADOR — CCP-08 (supremacía) + CCP-S01 (prohibidos) + CCP-09 (borrado)
# ═══════════════════════════════════════════════════════════════════════════

def validar_accion(descripcion, con=None, cell_id="unknown"):
    """
    Retorna (permitida: bool, razon: str)
    CCP-08: si CCP veta, la IA no puede sobrepasar esa decisión.
    """
    desc_upper = descripcion.upper()

    for pattern in CCP.forbidden_patterns:
        if pattern in desc_upper:
            reason = f"CCP-S01: patron '{pattern}' prohibido"
            if con:
                log_ccp_block(con, cell_id, "ACHE-CCP-S01", descripcion, reason)
            return False, reason

    for op in ["DELETE FROM","DROP TABLE","TRUNCATE TABLE"]:
        if op in desc_upper:
            reason = f"CCP-09: '{op}' viola memoria inmutable"
            if con:
                log_ccp_block(con, cell_id, "ACHE-CCP-09", descripcion, reason)
            return False, reason

    return True, "Accion valida bajo CCPs activas"

# ═══════════════════════════════════════════════════════════════════════════
# FACTURADOR — IVA desde CCP-F01 (no hardcodeado)
# ═══════════════════════════════════════════════════════════════════════════

def crear_factura(con, cell_id, cliente, items_list):
    """
    items_list: [{"descripcion": str, "cantidad": int, "precio_unitario": float}]
    El IVA viene de CCP-F01, no del codigo. CCP-08 garantiza esto.
    """
    iva_rate = CCP.iva_rate  # 0.13 por CCP-F01
    subtotal = sum(i["cantidad"] * i["precio_unitario"] for i in items_list)
    iva      = round(subtotal * iva_rate, 2)
    total    = round(subtotal + iva, 2)

    c = con.cursor()
    c.execute("""INSERT INTO facturas
               (timestamp,cell_id,cliente,items,subtotal,iva,total,iva_ccp)
               VALUES (?,?,?,?,?,?,?,?)""",
              (datetime.now().isoformat(), cell_id, cliente,
               json.dumps(items_list, ensure_ascii=False),
               round(subtotal,2), iva, total, "ACHE-CCP-F01"))
    con.commit()
    fid = c.lastrowid

    factura = {
        "id": fid, "cliente": cliente, "items": items_list,
        "subtotal": round(subtotal,2),
        "iva_rate": iva_rate, "iva_percent": f"{int(iva_rate*100)}%",
        "iva": iva, "iva_legal": CCP.iva_legal_text,
        "total": total, "iva_ccp": "ACHE-CCP-F01",
        "timestamp": datetime.now().isoformat(), "cell_id": cell_id
    }
    log_event(con, cell_id, "FACTURA_EMITIDA", factura)
    return factura

# ═══════════════════════════════════════════════════════════════════════════
# CONSULTAS
# ═══════════════════════════════════════════════════════════════════════════

def get_resumen_hoy(con, cell_id):
    hoy = datetime.now().strftime("%Y-%m-%d")
    c = con.cursor()
    c.execute("SELECT COUNT(*) FROM events WHERE cell_id=? AND timestamp LIKE ?",
              (cell_id, f"{hoy}%"))
    ev = c.fetchone()[0]
    c.execute("SELECT COUNT(*),SUM(total) FROM facturas WHERE cell_id=? AND timestamp LIKE ?",
              (cell_id, f"{hoy}%"))
    r = c.fetchone(); fac, ven = r[0], r[1] or 0.0
    c.execute("SELECT COUNT(*) FROM ccp_blocks WHERE cell_id=? AND timestamp LIKE ?",
              (cell_id, f"{hoy}%"))
    blq = c.fetchone()[0]
    return {"fecha":hoy,"eventos_hoy":ev,"facturas_hoy":fac,
            "ventas_hoy_colones":round(ven,2),"bloqueados_hoy":blq}

def get_ultimos_eventos(con, cell_id, n=10):
    c = con.cursor()
    c.execute("SELECT timestamp,event_type,payload FROM events "
              "WHERE cell_id=? ORDER BY id DESC LIMIT ?", (cell_id, n))
    return [{"timestamp":r[0],"tipo":r[1],"payload":json.loads(r[2])}
            for r in c.fetchall()]

def get_ccp_status():
    s = CCP.summary()
    return {"genoma":"ACHE-GENOME-v1.0","ccps_cargadas":s["total"],
            "por_capa":s["by_layer"],"iva_activo":f"{int(CCP.iva_rate*100)}%",
            "patrones_bloqueados":len(CCP.forbidden_patterns)}

# ═══════════════════════════════════════════════════════════════════════════
# BOOT
# ═══════════════════════════════════════════════════════════════════════════

def boot():
    print("\n" + "=" * 58)
    print("  ACHE - Boot Sequence v1.1")
    print("  Sistema Cognitivo Modular - COOPECRUCENOS R.L.")
    print("  Genoma Soberano v1.0")
    print("=" * 58)

    n_ccps = CCP.load()
    if n_ccps > 0:
        print(f"OK Genoma cargado: {n_ccps} CCPs activas")
        print(f"   IVA por CCP-F01: {int(CCP.iva_rate*100)}%")
    else:
        print("AVISO Genoma no encontrado - usando defaults internos")

    con = init_db()
    print("OK Base de datos SQLite (append-only CCP-09)")

    cell_id = get_or_create_identity(con)
    print(f"OK Identidad: {cell_id}  (CCP-01: inmutable)")
    print(f"OK MASTER.MD v{MASTER['version']}: {len(MASTER['principios'])} principios")

    log_event(con, cell_id, "BOOT_v1.1", {
        "master_version": MASTER["version"],
        "ccps_cargadas": n_ccps,
        "iva_rate": CCP.iva_rate,
        "device": platform.system()
    })

    res = get_resumen_hoy(con, cell_id)
    print(f"Eventos hoy:            {res['eventos_hoy']}")
    print(f"Facturas hoy:           {res['facturas_hoy']}")
    print(f"Bloqueados por CCP hoy: {res['bloqueados_hoy']}")

    print("\nSiguiente paso:")
    print("  python agents/telegram_bot.py")
    print("=" * 58)
    print(f"  ACHE {cell_id} - GENOMA v1.0 - EN LINEA\n")
    return con, cell_id

# ═══════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    con, cell_id = boot()

    ok, msg = validar_accion("INSERT INTO events VALUES ...", con, cell_id)
    print(f"\nValidacion INSERT:  {'OK' if ok else 'BLOQUEADO'} - {msg}")

    ok, msg = validar_accion("DROP TABLE events", con, cell_id)
    print(f"Validacion DROP:    {'OK' if ok else 'BLOQUEADO'} - {msg}")

    ok, msg = validar_accion("exec('rm -rf /')", con, cell_id)
    print(f"Validacion exec():  {'OK' if ok else 'BLOQUEADO'} - {msg}")

    print(f"\nFactura (IVA desde CCP-F01 = {int(CCP.iva_rate*100)}%)...")
    factura = crear_factura(con, cell_id, "Cliente Demo", [
        {"descripcion": "Arroz 1kg",    "cantidad": 3, "precio_unitario": 850.0},
        {"descripcion": "Frijoles 1kg", "cantidad": 2, "precio_unitario": 1200.0},
    ])
    print(f"Factura #{factura['id']}: subtotal CR{factura['subtotal']:,.2f} "
          f"+ IVA {factura['iva_percent']} CR{factura['iva']:,.2f} "
          f"= TOTAL CR{factura['total']:,.2f}")
    print(f"Sustento: {factura['iva_legal']}")

    print("\nGenoma status:")
    for k, v in get_ccp_status().items():
        print(f"  {k}: {v}")
