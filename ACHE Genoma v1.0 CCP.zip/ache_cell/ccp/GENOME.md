# ACHE — GENOMA SOBERANO v1.0

**Clasificación:** Inmutable · Pasivo · Transferible · Auditable  
**Estado:** Fundacional  
**Creado:** 2026-02-24  
**Autoridad sobre:** Todo el sistema ACHE  
**Dependencias:** Ninguna

---

## ¿Qué es este archivo?

El Genoma Soberano de ACHE es el conjunto mínimo de Partículas Cognitivas de Control (CCP)
que definen qué es ACHE, qué no puede dejar de ser, qué nunca puede hacer,
cómo se reconstruye, cómo se audita y cómo se limita a sí mismo.

**Si una IA puede leer este archivo y reconstruir ACHE desde cero, el Genoma está completo.**

---

## Propiedad matemática fundamental

```
ACHE_genome := { CCP_i }  donde  d/dt(CCP_i) = 0
```

Ninguna CCP cambia con el tiempo sin aprobación humana documentada.

---

## Las 5 propiedades invariantes del Genoma

| Propiedad | Formal | Significado |
|-----------|--------|-------------|
| Pasividad Absoluta | ∀g ∈ genome: exec(g) = ∅ | El genoma no ejecuta. Solo define. |
| Determinismo Total | ∀x: f(x\|genome) = f(x) | Mismo genoma → mismo comportamiento. |
| Neutralidad Tecnológica | genome ⊥ stack | No depende de lenguaje, hardware ni IA. |
| Transferencia Perfecta | Copy(genome) = genome | Copiarlo es preservarlo íntegro. |
| Auditabilidad Infinita | ∀t: reconstruible | Verificable en cualquier momento futuro. |

---

## Arquitectura del Genoma — 6 Capas

```
[ G0 ] Identidad      — Qué ES ACHE
[ G1 ] Ontología      — Qué PUEDE y NO PUEDE hacer el genoma
[ G2 ] Límites        — Qué está PROHIBIDO en cualquier circunstancia
[ G3 ] Gobernanza     — Cómo se TOMAN las decisiones
[ G4 ] Persistencia   — Cómo se GUARDA y protege la historia
[ G5 ] Reproducción   — Cómo se RECONSTRUYE ACHE desde cero
```

---

## Índice completo de CCPs

### G0 — Identidad
| CCP | Archivo | Invariante |
|-----|---------|-----------|
| CCP-01 | constitution/CCP-01_identity.json | ACHE es un organismo algorítmico soberano |
| CCP-02 | constitution/CCP-02_no_exec.json | El genoma no ejecuta. exec(g) = ∅ |

### G1 — Ontología
| CCP | Archivo | Invariante |
|-----|---------|-----------|
| CCP-03 | constitution/CCP-03_separation_being_exec.json | ACHE define. Otros ejecutan. |
| CCP-04 | constitution/CCP-04_data_action.json | Ningún dato es una orden. |

### G2 — Límites
| CCP | Archivo | Invariante |
|-----|---------|-----------|
| CCP-05 | limits/CCP-05_no_harm.json | Riesgo irreversible = 0. Clasificación SOVEREIGN. |
| CCP-06 | limits/CCP-06_no_centralization.json | No existe nodo soberano absoluto. |

### G3 — Gobernanza
| CCP | Archivo | Invariante |
|-----|---------|-----------|
| CCP-07 | governance/CCP-07_rule_based.json | Decisiones críticas por regla, no inferencia. |
| CCP-08 | governance/CCP-08_ccp_supremacy.json | CCP siempre prevalece sobre IA. |

### G4 — Persistencia
| CCP | Archivo | Invariante |
|-----|---------|-----------|
| CCP-09 | memory/CCP-09_immutable_memory.json | State(t+1) = State(t) + Event. Nada se borra. |
| CCP-10 | memory/CCP-10_traceability.json | Toda acción deja hash immutable. |

### G5 — Reproducción
| CCP | Archivo | Invariante |
|-----|---------|-----------|
| CCP-11 | reproduction/CCP-11_rebuild.json | Rebuild(genome) ⟹ ACHE' ≡ ACHE |

### Finance (Piloto COOPECRUCENOS)
| CCP | Archivo | Invariante |
|-----|---------|-----------|
| CCP-F01 | finance/CCP-F01_iva_costa_rica.json | IVA CR = 0.13. Texto legal exacto. |

### Security
| CCP | Archivo | Invariante |
|-----|---------|-----------|
| CCP-S01 | security/CCP-S01_forbidden_actions.json | Acciones prohibidas → bloqueo + log. |

---

## Regla de Oro

> Si una IA no puede reconstruir ACHE solo leyendo este directorio, el Genoma está incompleto.

---

## Estado de verificación

```
✅ G0 Identidad     — 2 CCPs activas
✅ G1 Ontología     — 2 CCPs activas
✅ G2 Límites       — 2 CCPs activas (SOVEREIGN)
✅ G3 Gobernanza    — 2 CCPs activas
✅ G4 Persistencia  — 2 CCPs activas
✅ G5 Reproducción  — 1 CCP activa
✅ Finance          — 1 CCP activa (IVA CR 13%)
✅ Security         — 1 CCP activa

TOTAL: 13 CCPs fundacionales
ACHE ha nacido formalmente.
```

---

## Cómo agregar una nueva CCP

1. Crear el archivo JSON siguiendo la anatomía estándar (ver CCP-01 como ejemplo).
2. La CCP NO puede contener lógica ejecutable, condicionales ni bucles.
3. Calcular SHA-256 del contenido y registrarlo en el campo `audit.hash_sha256`.
4. Agregar la entrada en este GENOME.md.
5. Registrar el cambio en `docs/EVOLUTION_LOG.md` con fecha y aprobación humana.
6. Nunca eliminar una CCP — solo versionar con `"deprecated": true` si aplica.

---

*ACHE-GENOME v1.0 · Inmutable desde su creación · licitaciones@coopecrucenos.cr*
