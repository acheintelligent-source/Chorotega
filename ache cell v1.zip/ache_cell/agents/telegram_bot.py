"""
agents/telegram_bot.py — Bot de Telegram para ACHE v1.0
Ejecutar: python agents/telegram_bot.py

Configuración requerida en config/config.env:
  TELEGRAM_TOKEN=tu_token_de_botfather
  CELL_LOCATION=supermercado_1
  OPERATOR_NAME=cristhian_gonzaga

Obtener token:
  1. Abrir Telegram → buscar @BotFather
  2. Enviar /newbot → elegir nombre
  3. Copiar el token → pegar en config.env
"""

import os, sys, json
from datetime import datetime

# Agregar directorio raíz al path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from boot import init_db, get_or_create_identity, log_event, crear_factura, get_resumen_hoy, get_ultimos_eventos, MASTER

try:
    from telegram import Update, ReplyKeyboardMarkup
    from telegram.ext import Application, CommandHandler, MessageHandler, ConversationHandler, filters, ContextTypes
except ImportError:
    print("❌ Instalar: pip install python-telegram-bot")
    exit(1)

# ── Cargar configuración ───────────────────────────────────────────────────
def load_config():
    config = {}
    config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "config", "config.env")
    if os.path.exists(config_path):
        with open(config_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    config[k.strip()] = v.strip()
    return config

config = load_config()
TOKEN = config.get("TELEGRAM_TOKEN") or os.environ.get("TELEGRAM_TOKEN")

if not TOKEN:
    print("❌ TELEGRAM_TOKEN no configurado.")
    print("   Crear archivo config/config.env con: TELEGRAM_TOKEN=tu_token")
    exit(1)

# ── Inicializar ACHE ───────────────────────────────────────────────────────
con = init_db()
CELL_ID = get_or_create_identity(con)
log_event(con, CELL_ID, "BOT_START", {"mensaje": "Bot de Telegram iniciado"})

# ── Estados para conversación de factura ──────────────────────────────────
FACTURA_CLIENTE, FACTURA_ITEMS, FACTURA_CONFIRMAR = range(3)
factura_temp = {}  # Estado temporal de factura en progreso

# ═══════════════════════════════════════════════════════════════════════════
# HANDLERS
# ═══════════════════════════════════════════════════════════════════════════

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Bienvenida."""
    msg = (
        f"🧠 *ACHE Cell Activa*\n"
        f"ID: `{CELL_ID}`\n\n"
        f"Comandos disponibles:\n"
        f"/estado — Estado de la célula\n"
        f"/factura — Crear nueva factura\n"
        f"/hoy — Resumen del día\n"
        f"/log — Últimos eventos\n"
        f"/principios — Canon de ACHE\n"
        f"/ayuda — Esta pantalla\n\n"
        f"_ACHE asiste, no reemplaza la decisión humana._"
    )
    await update.message.reply_text(msg, parse_mode="Markdown")
    log_event(con, CELL_ID, "BOT_CMD", {"cmd": "/start", "user": update.effective_user.username})


async def cmd_estado(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Estado actual de la célula."""
    import sqlite3
    cur = con.cursor()
    cur.execute("SELECT COUNT(*) FROM events WHERE cell_id=?", (CELL_ID,))
    total_eventos = cur.fetchone()[0]
    cur.execute("SELECT COUNT(*) FROM facturas WHERE cell_id=?", (CELL_ID,))
    total_facturas = cur.fetchone()[0]

    resumen = get_resumen_hoy(con, CELL_ID)
    msg = (
        f"📡 *Estado ACHE Cell*\n\n"
        f"🆔 ID: `{CELL_ID}`\n"
        f"📅 Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        f"📊 Eventos totales: {total_eventos}\n"
        f"🧾 Facturas totales: {total_facturas}\n\n"
        f"*Hoy:*\n"
        f"  Eventos: {resumen['eventos_hoy']}\n"
        f"  Facturas: {resumen['facturas_hoy']}\n"
        f"  Ventas: ₡{resumen['ventas_hoy_colones']:,.2f}\n\n"
        f"✅ Sistema operativo · Modo: advisory"
    )
    await update.message.reply_text(msg, parse_mode="Markdown")
    log_event(con, CELL_ID, "BOT_CMD", {"cmd": "/estado"})


async def cmd_hoy(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Resumen del día."""
    resumen = get_resumen_hoy(con, CELL_ID)
    msg = (
        f"📊 *Resumen del día — {resumen['fecha']}*\n\n"
        f"🔔 Eventos registrados: {resumen['eventos_hoy']}\n"
        f"🧾 Facturas emitidas: {resumen['facturas_hoy']}\n"
        f"💰 Ventas totales: ₡{resumen['ventas_hoy_colones']:,.2f}\n\n"
        f"_Todos los datos están registrados en memoria inmutable._"
    )
    await update.message.reply_text(msg, parse_mode="Markdown")


async def cmd_log(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Últimos 10 eventos."""
    eventos = get_ultimos_eventos(con, CELL_ID, 10)
    if not eventos:
        await update.message.reply_text("📋 No hay eventos registrados aún.")
        return
    lines = ["📋 *Últimos eventos:*\n"]
    for ev in eventos:
        ts = ev['timestamp'][:19].replace('T', ' ')
        lines.append(f"`{ts}` — {ev['tipo']}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_principios(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Muestra los principios invariantes del canon."""
    lines = ["🧠 *Principios Invariantes ACHE:*\n"]
    for i, p in enumerate(MASTER["principios"], 1):
        lines.append(f"{i}. {p}")
    lines.append(f"\n_Versión canónica: {MASTER['version']}_")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_ayuda(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Menú de ayuda."""
    await cmd_start(update, context)


# ── Flujo de factura ───────────────────────────────────────────────────────
async def cmd_factura(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Inicia el flujo de creación de factura."""
    await update.message.reply_text(
        "🧾 *Nueva Factura*\n\n¿Nombre del cliente?",
        parse_mode="Markdown"
    )
    return FACTURA_CLIENTE


async def factura_cliente(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Recibe el nombre del cliente."""
    context.user_data['cliente'] = update.message.text.strip()
    await update.message.reply_text(
        f"Cliente: *{context.user_data['cliente']}*\n\n"
        "Ahora ingresá los items en este formato:\n"
        "`Arroz 1kg, 3, 850`\n"
        "`Frijoles, 2, 1200`\n\n"
        "Un item por línea. Enviá /listo cuando termines.",
        parse_mode="Markdown"
    )
    context.user_data['items'] = []
    return FACTURA_ITEMS


async def factura_items(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Procesa items de la factura."""
    texto = update.message.text.strip()

    if texto == "/listo":
        if not context.user_data['items']:
            await update.message.reply_text("❌ No hay items. Agregá al menos uno.")
            return FACTURA_ITEMS

        # Mostrar resumen para confirmar
        items = context.user_data['items']
        subtotal = sum(i['cantidad'] * i['precio_unitario'] for i in items)
        iva = subtotal * 0.13
        total = subtotal + iva

        lines = [f"📋 *Confirmar Factura*\n\nCliente: {context.user_data['cliente']}\n\nItems:"]
        for it in items:
            linea = it['cantidad'] * it['precio_unitario']
            lines.append(f"  • {it['descripcion']} × {it['cantidad']} = ₡{linea:,.2f}")
        lines.append(f"\nSubtotal: ₡{subtotal:,.2f}")
        lines.append(f"IVA 13%: ₡{iva:,.2f}")
        lines.append(f"*TOTAL: ₡{total:,.2f}*")
        lines.append("\n¿Confirmar? /si o /no")

        await update.message.reply_text("\n".join(lines), parse_mode="Markdown")
        return FACTURA_CONFIRMAR

    # Parsear item: "descripcion, cantidad, precio"
    try:
        partes = [p.strip() for p in texto.split(",")]
        if len(partes) != 3:
            raise ValueError("Formato incorrecto")
        desc = partes[0]
        cant = int(partes[1])
        precio = float(partes[2])
        context.user_data['items'].append({
            "descripcion": desc,
            "cantidad": cant,
            "precio_unitario": precio
        })
        await update.message.reply_text(
            f"✅ Item agregado: {desc} × {cant}\n"
            "Seguí agregando o enviá /listo"
        )
    except:
        await update.message.reply_text(
            "❌ Formato inválido. Usá:\n`Descripcion, cantidad, precio`\nEjemplo: `Arroz 1kg, 3, 850`",
            parse_mode="Markdown"
        )
    return FACTURA_ITEMS


async def factura_confirmar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Confirma y emite la factura."""
    resp = update.message.text.strip().lower()
    if resp in ["/si", "si", "sí", "yes"]:
        factura = crear_factura(
            con, CELL_ID,
            context.user_data['cliente'],
            context.user_data['items']
        )
        await update.message.reply_text(
            f"✅ *Factura #{factura['id']} emitida*\n\n"
            f"Cliente: {factura['cliente']}\n"
            f"Total: ₡{factura['total']:,.2f}\n"
            f"Timestamp: {factura['timestamp'][:19]}\n\n"
            f"_Registrada en memoria inmutable de ACHE._",
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text("❌ Factura cancelada. No se registró ningún dato.")
        log_event(con, CELL_ID, "FACTURA_CANCELADA", {"cliente": context.user_data.get('cliente')})

    context.user_data.clear()
    return ConversationHandler.END


async def factura_cancelar(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancela el flujo de factura."""
    context.user_data.clear()
    await update.message.reply_text("❌ Factura cancelada.")
    return ConversationHandler.END


async def mensaje_desconocido(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Maneja mensajes que no son comandos."""
    await update.message.reply_text(
        "💬 No entendí ese mensaje.\nUsá /ayuda para ver los comandos disponibles."
    )


# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

def main():
    print(f"🤖 Bot de Telegram iniciando para célula {CELL_ID}...")
    app = Application.builder().token(TOKEN).build()

    # Comandos simples
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("ayuda", cmd_ayuda))
    app.add_handler(CommandHandler("estado", cmd_estado))
    app.add_handler(CommandHandler("hoy", cmd_hoy))
    app.add_handler(CommandHandler("log", cmd_log))
    app.add_handler(CommandHandler("principios", cmd_principios))

    # Flujo de factura
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("factura", cmd_factura)],
        states={
            FACTURA_CLIENTE:   [MessageHandler(filters.TEXT & ~filters.COMMAND, factura_cliente)],
            FACTURA_ITEMS:     [MessageHandler(filters.TEXT, factura_items)],
            FACTURA_CONFIRMAR: [MessageHandler(filters.TEXT, factura_confirmar)],
        },
        fallbacks=[CommandHandler("cancelar", factura_cancelar)],
    )
    app.add_handler(conv_handler)

    # Mensajes desconocidos
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, mensaje_desconocido))

    print(f"✅ Bot activo. Buscá tu bot en Telegram y enviá /start")
    print(f"   Presioná Ctrl+C para detener.")
    app.run_polling()


if __name__ == "__main__":
    main()
