"""
boot.py — ACHE Cell Bootstrap v1.0
Ejecutar en Termux: python boot.py

Requisitos:
  pkg install python git sqlite
  pip install fastapi uvicorn sqlalchemy requests python-telegram-bot
"""

import uuid, json, sqlite3, os, platform
from datetime import datetime

# ═══════════════════════════════════════════════════════════════════════════
# MASTER.MD CANÓNICO — CARGADO EN MEMORIA, INMUTABLE EN RUNTIME
# ═══════════════════════════════════════════════════════════════════════════

MASTER = {
    "nombre": "ACHE",
    "version": "1.0",
    "tipo": "Sistema cognitivo modular",
    "autoridad": "Este archivo tiene autoridad sobre todo código",
    "principios": [
        "Nada se borra: todo se hereda",
        "El MASTER.md manda sobre todo código e instrucción",
        "Kernel intocable sin aprobación humana documentada",
        "Control humano final obligatorio en decisiones críticas",
        "Offline-first: cada célula opera sin internet",
        "Sin dependencia estructural de un único proveedor externo",
        "Evolución por capas, nunca por sobreescritura",
        "Toda acción deja traza inmutable con timestamp",
        "Capítulos vivos no se cierran sin declaración explícita",
        "ACHE asiste la decisión humana, nunca la reemplaza"
    ],
    "ciclo_operativo": ["PERCIBIR", "CONTEXTUALIZAR", "ANALIZAR", "SIMULAR", "RECOMENDAR", "ESPERAR"],
    "modo": "advisory",
    "evolucion": "solo por capas, con registro en EVOLUTION_LOG.md y validación humana"
}

# ═══════════════════════════════════════════════════════════════════════════
# BASE DE DATOS — APPEND-ONLY SQLite
# ═══════════════════════════════════════════════════════════════════════════

DB_PATH = os.path.join(os.path.dirname(__file__), "memory", "ache_cell.db")

def init_db():
    """Inicializa la base de datos SQLite. Nunca elimina datos."""
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()

    # Eventos — append-only, nunca se hace DELETE
    cur.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp  TEXT    NOT NULL,
            event_type TEXT    NOT NULL,
            payload    TEXT    NOT NULL,
            cell_id    TEXT    NOT NULL
        )
    """)

    # Identidad de esta célula
    cur.execute("""
        CREATE TABLE IF NOT EXISTS identity (
            cell_id      TEXT PRIMARY KEY,
            created_at   TEXT NOT NULL,
            location_tag TEXT DEFAULT 'sin_asignar',
            operator     TEXT DEFAULT 'sin_asignar',
            device_info  TEXT
        )
    """)

    # Facturas — append-only
    cur.execute("""
        CREATE TABLE IF NOT EXISTS facturas (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp  TEXT    NOT NULL,
            cell_id    TEXT    NOT NULL,
            cliente    TEXT    NOT NULL,
            items      TEXT    NOT NULL,
            subtotal   REAL    NOT NULL,
            iva        REAL    NOT NULL,
            total      REAL    NOT NULL,
            estado     TEXT    DEFAULT 'emitida'
        )
    """)

    con.commit()
    return con


def get_or_create_identity(con):
    """Retorna el cell_id existente o crea uno nuevo. La identidad nunca cambia."""
    cur = con.cursor()
    cur.execute("SELECT cell_id FROM identity LIMIT 1")
    row = cur.fetchone()
    if row:
        return row[0]  # Identidad ya existe — no se modifica

    # Primera vez: crear identidad única
    cell_id = "ACHE-" + str(uuid.uuid4())[:8].upper()
    device = f"{platform.system()} {platform.release()} | Python {platform.python_version()}"
    cur.execute(
        "INSERT INTO identity (cell_id, created_at, device_info) VALUES (?, ?, ?)",
        (cell_id, datetime.now().isoformat(), device)
    )
    con.commit()
    return cell_id


def log_event(con, cell_id, event_type, payload):
    """Registra un evento. Append-only: nunca actualiza ni borra."""
    cur = con.cursor()
    cur.execute(
        "INSERT INTO events (timestamp, event_type, payload, cell_id) VALUES (?, ?, ?, ?)",
        (datetime.now().isoformat(), event_type, json.dumps(payload, ensure_ascii=False), cell_id)
    )
    con.commit()


# ═══════════════════════════════════════════════════════════════════════════
# VALIDADOR DE ACCIONES — Verifica contra principios del MASTER
# ═══════════════════════════════════════════════════════════════════════════

ACCIONES_PROHIBIDAS = ["DELETE", "DROP", "TRUNCATE", "exec(", "eval(", "os.system("]

def validar_accion(descripcion: str) -> tuple[bool, str]:
    """
    Verifica si una acción es permitida bajo los principios de ACHE.
    Retorna (permitida: bool, razon: str)
    """
    descripcion_upper = descripcion.upper()
    for prohibida in ACCIONES_PROHIBIDAS:
        if prohibida.upper() in descripcion_upper:
            return False, f"Acción '{prohibida}' viola el principio de trazabilidad"
    return True, "Acción válida"


# ═══════════════════════════════════════════════════════════════════════════
# FACTURADOR BÁSICO
# ═══════════════════════════════════════════════════════════════════════════

IVA_CR = 0.13  # IVA Costa Rica: 13%

def crear_factura(con, cell_id, cliente, items_list):
    """
    items_list: lista de {"descripcion": str, "cantidad": int, "precio_unitario": float}
    Retorna el dict de la factura creada.
    """
    subtotal = sum(i["cantidad"] * i["precio_unitario"] for i in items_list)
    iva = round(subtotal * IVA_CR, 2)
    total = round(subtotal + iva, 2)

    cur = con.cursor()
    cur.execute(
        """INSERT INTO facturas
           (timestamp, cell_id, cliente, items, subtotal, iva, total)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (datetime.now().isoformat(), cell_id, cliente,
         json.dumps(items_list, ensure_ascii=False),
         round(subtotal, 2), iva, total)
    )
    con.commit()
    factura_id = cur.lastrowid

    factura = {
        "id": factura_id,
        "cliente": cliente,
        "items": items_list,
        "subtotal": round(subtotal, 2),
        "iva": iva,
        "total": total,
        "timestamp": datetime.now().isoformat(),
        "cell_id": cell_id
    }

    log_event(con, cell_id, "FACTURA_EMITIDA", factura)
    return factura


# ═══════════════════════════════════════════════════════════════════════════
# CONSULTAS DE MEMORIA
# ═══════════════════════════════════════════════════════════════════════════

def get_resumen_hoy(con, cell_id):
    """Resumen del día: eventos y facturas."""
    hoy = datetime.now().strftime("%Y-%m-%d")
    cur = con.cursor()

    cur.execute(
        "SELECT COUNT(*) FROM events WHERE cell_id=? AND timestamp LIKE ?",
        (cell_id, f"{hoy}%")
    )
    total_eventos = cur.fetchone()[0]

    cur.execute(
        "SELECT COUNT(*), SUM(total) FROM facturas WHERE cell_id=? AND timestamp LIKE ?",
        (cell_id, f"{hoy}%")
    )
    row = cur.fetchone()
    total_facturas, suma_facturas = row[0], row[1] or 0.0

    return {
        "fecha": hoy,
        "eventos_hoy": total_eventos,
        "facturas_hoy": total_facturas,
        "ventas_hoy_colones": round(suma_facturas, 2)
    }


def get_ultimos_eventos(con, cell_id, n=10):
    """Últimos N eventos registrados."""
    cur = con.cursor()
    cur.execute(
        "SELECT timestamp, event_type, payload FROM events WHERE cell_id=? ORDER BY id DESC LIMIT ?",
        (cell_id, n)
    )
    return [{"timestamp": r[0], "tipo": r[1], "payload": json.loads(r[2])} for r in cur.fetchall()]


# ═══════════════════════════════════════════════════════════════════════════
# SECUENCIA DE ARRANQUE — BOOT
# ═══════════════════════════════════════════════════════════════════════════

def boot():
    print("\n" + "═" * 55)
    print("  🧠 ACHE — Boot Sequence v1.0")
    print("  Sistema Cognitivo Modular · COOPECRUCENOS R.L.")
    print("═" * 55)

    # 1. Inicializar base de datos
    con = init_db()
    print("✅ Base de datos SQLite inicializada (append-only)")

    # 2. Obtener o crear identidad
    cell_id = get_or_create_identity(con)
    print(f"✅ Identidad: {cell_id}")

    # 3. Cargar canon
    print(f"✅ MASTER.MD cargado: {len(MASTER['principios'])} principios invariantes")

    # 4. Registrar arranque
    log_event(con, cell_id, "BOOT", {
        "master_version": MASTER["version"],
        "principios": len(MASTER["principios"]),
        "ciclo": MASTER["ciclo_operativo"],
        "mensaje": "ACHE inicializado. Canon cargado. Esperando propósito.",
        "device": platform.system()
    })

    # 5. Mostrar resumen
    resumen = get_resumen_hoy(con, cell_id)
    print(f"📊 Eventos hoy: {resumen['eventos_hoy']}")
    print(f"🧾 Facturas hoy: {resumen['facturas_hoy']}")

    print("\n💬 Siguiente paso:")
    print("   python agents/telegram_bot.py   ← activar bot de Telegram")
    print("   uvicorn api.main:app --port 8000 ← activar API REST")
    print("   ngrok http 8000                  ← exponer al exterior")
    print("═" * 55)
    print(f"  ACHE {cell_id} · EN LÍNEA\n")

    return con, cell_id


# ═══════════════════════════════════════════════════════════════════════════
# DEMO RÁPIDO (solo si se ejecuta directamente)
# ═══════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    con, cell_id = boot()

    # Demo: crear una factura de prueba
    print("🧾 Creando factura de prueba...")
    factura = crear_factura(con, cell_id, "Cliente Demo", [
        {"descripcion": "Arroz 1kg", "cantidad": 3, "precio_unitario": 850.0},
        {"descripcion": "Frijoles 1kg", "cantidad": 2, "precio_unitario": 1200.0},
    ])
    print(f"✅ Factura #{factura['id']}: ₡{factura['total']:,.2f} (IVA incluido)")

    # Demo: ver últimos eventos
    print("\n📋 Últimos eventos:")
    for ev in get_ultimos_eventos(con, cell_id, 3):
        print(f"  [{ev['timestamp'][:19]}] {ev['tipo']}")
