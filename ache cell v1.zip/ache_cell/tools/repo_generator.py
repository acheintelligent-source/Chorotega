"""
tools/repo_generator.py — Generador de Nuevas Células ACHE
Uso: python tools/repo_generator.py --name supermercado_2 --location "Supermercado #2 La Cruz"

Este script crea la estructura completa de una nueva célula ACHE
lista para instalar en otro celular o dispositivo.
"""

import os, sys, argparse, json, shutil
from datetime import datetime

# ── Estructura de directorios ──────────────────────────────────────────────
DIRS = [
    "memory",
    "config",
    "core",
    "api",
    "agents",
    "workflows",
    "schema",
    "docs",
    "tools",
]

# ── Archivos base ──────────────────────────────────────────────────────────
def get_files(cell_name, location, operator="sin_asignar"):
    return {

        "MASTER.md": f"""# ACHE MASTER.MD — Libro Maestro Canónico
## Versión 1.0 · {datetime.now().strftime('%Y-%m-%d')}

**Este archivo tiene autoridad suprema sobre todo código, instrucción o modelo.**
**Si algo contradice este archivo → se rechaza.**

---

## Identidad

- **Nombre:** ACHE
- **Célula:** {cell_name}
- **Ubicación:** {location}
- **Tipo:** Sistema Cognitivo Modular

## Los 10 Principios Invariantes

1. Nada se borra: todo se hereda
2. El MASTER.md manda sobre todo código e instrucción
3. Kernel intocable sin aprobación humana documentada
4. Control humano final obligatorio en decisiones críticas
5. Offline-first: esta célula opera sin internet
6. Sin dependencia estructural de un único proveedor externo
7. Evolución por capas, nunca por sobreescritura
8. Toda acción deja traza inmutable con timestamp
9. Capítulos vivos no se cierran sin declaración explícita
10. ACHE asiste la decisión humana, nunca la reemplaza

## Ciclo Operativo

PERCIBIR → CONTEXTUALIZAR → ANALIZAR → SIMULAR → RECOMENDAR → ESPERAR

## Modo

**advisory** — ACHE propone. El humano decide.

## Regla de Evolución

Un cambio es válido SOLO si:
- No contradice este archivo
- Se registra en EVOLUTION_LOG.md
- Es reversible
- Tiene aprobación humana documentada
""",

        "README.md": f"""# ACHE Cell — {cell_name}

Sistema Cognitivo Modular · COOPECRUCENOS R.L. · Guanacaste, Costa Rica

## Esta célula

- **Nombre:** {cell_name}
- **Ubicación:** {location}
- **Operador:** {operator}
- **Creada:** {datetime.now().strftime('%Y-%m-%d %H:%M')}

## Arranque rápido (Termux / Android)

```bash
# 1. Instalar dependencias
pkg update && pkg install python git sqlite
pip install fastapi uvicorn sqlalchemy requests python-telegram-bot

# 2. Arrancar ACHE
python boot.py

# 3. Activar bot de Telegram
python agents/telegram_bot.py

# 4. Exponer al exterior (opcional)
ngrok http 8000
```

## Configuración requerida

Crear `config/config.env` con:
```
TELEGRAM_TOKEN=tu_token_de_botfather
CELL_LOCATION={location}
OPERATOR_NAME={operator}
```

## Principio fundamental

ACHE no borra. ACHE no reemplaza al humano. ACHE asiste.

Ver MASTER.md para el canon completo.
""",

        "requirements.txt": """fastapi==0.111.0
uvicorn==0.30.1
sqlalchemy==2.0.31
requests==2.32.3
python-telegram-bot==21.3
pydantic==2.8.2
""",

        "config/config.env.example": f"""# Configurar este archivo y renombrarlo a config.env
# NO subir config.env a GitHub (ya está en .gitignore)

TELEGRAM_TOKEN=obtener_de_botfather
CELL_LOCATION={location}
OPERATOR_NAME={operator}
SUPABASE_URL=obtener_de_supabase.com
SUPABASE_KEY=obtener_de_supabase.com
""",

        "config/cell_config.yaml": f"""# Configuración de esta célula específica
cell_name: "{cell_name}"
cell_location: "{location}"
operator: "{operator}"
created_at: "{datetime.now().isoformat()}"

# Comportamiento
sync_interval_minutes: 15
offline_buffer_events: 10000
log_level: "INFO"

# Módulos activos
modules:
  facturacion: true
  telegram_bot: true
  licitaciones: true
  sensores: false    # Activar cuando haya sensores físicos conectados
""",

        ".gitignore": """# ACHE Cell .gitignore
config/config.env
memory/ache_cell.db
memory/events.log
__pycache__/
*.pyc
.env
""",

        "docs/EVOLUTION_LOG.md": f"""# EVOLUTION LOG — {cell_name}

Registro append-only de cambios. Nunca se borra una entrada.

---

## EVO-001 · {datetime.now().strftime('%Y-%m-%d')}

**Descripción:** Creación inicial de la célula  
**Aprobado por:** Sistema de generación automática  
**Reversible:** N/A (creación)  
**Notas:** Generado desde repo_generator.py
""",

        "schema/ache_core.schema.json": json.dumps({
            "$schema": "http://json-schema.org/draft-07/schema#",
            "title": "ACHE Cell Event",
            "type": "object",
            "required": ["cell_id", "timestamp", "event_type", "payload"],
            "properties": {
                "cell_id": {"type": "string", "description": "ID único de la célula"},
                "timestamp": {"type": "string", "format": "date-time"},
                "event_type": {"type": "string"},
                "payload": {"type": "object"},
            }
        }, indent=2),

        "workflows/flows.yaml": """# Workflows ACHE — Definición en YAML
# Estos flujos son ejecutados por n8n o por el motor de workflows interno

flows:
  - id: "factura_emitida"
    trigger: "event:FACTURA_EMITIDA"
    steps:
      - action: "notify_telegram"
        message: "Nueva factura emitida: ₡{total}"
      - action: "sync_supabase"
        table: "facturas"

  - id: "boot_diario"
    trigger: "schedule:08:00"
    steps:
      - action: "generar_resumen_dia_anterior"
      - action: "notify_telegram"
        message: "Resumen del día: {eventos} eventos, {facturas} facturas"

  - id: "alerta_offline"
    trigger: "event:CONNECTIVITY_LOST"
    steps:
      - action: "buffer_eventos_local"
      - action: "retry_sync_on_reconnect"
""",

    }


def generate_cell(cell_name, location, operator, output_dir="."):
    """Genera la estructura completa de una nueva célula ACHE."""
    base = os.path.join(output_dir, f"ache-{cell_name}")

    if os.path.exists(base):
        print(f"⚠️  Directorio {base} ya existe.")
        resp = input("¿Sobreescribir? (s/N): ").strip().lower()
        if resp != "s":
            print("Cancelado.")
            return

    print(f"\n🚀 Generando célula ACHE: {cell_name}")
    print(f"   Ubicación: {location}")
    print(f"   Directorio: {base}\n")

    # Crear directorios
    for d in DIRS:
        path = os.path.join(base, d)
        os.makedirs(path, exist_ok=True)
        print(f"   📁 {d}/")

    # Crear archivos
    files = get_files(cell_name, location, operator)
    for rel_path, content in files.items():
        full_path = os.path.join(base, rel_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"   📄 {rel_path}")

    # Copiar boot.py y agents desde la célula actual
    current_dir = os.path.dirname(os.path.dirname(__file__))
    for src_rel in ["boot.py", "agents/telegram_bot.py"]:
        src = os.path.join(current_dir, src_rel)
        dst = os.path.join(base, src_rel)
        if os.path.exists(src):
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            print(f"   📄 {src_rel} (copiado)")

    print(f"\n✅ Célula {cell_name} generada en: {base}")
    print("\n📋 Próximos pasos:")
    print(f"   1. cd {base}")
    print(f"   2. cp config/config.env.example config/config.env")
    print(f"   3. nano config/config.env  ← agregar TELEGRAM_TOKEN")
    print(f"   4. python boot.py")
    print(f"   5. python agents/telegram_bot.py")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generador de Células ACHE")
    parser.add_argument("--name", required=True, help="Nombre de la célula (ej: supermercado_2)")
    parser.add_argument("--location", default="sin_asignar", help="Descripción de ubicación")
    parser.add_argument("--operator", default="sin_asignar", help="Nombre del operador")
    parser.add_argument("--output", default=".", help="Directorio de salida")
    args = parser.parse_args()

    generate_cell(args.name, args.location, args.operator, args.output)
