# ═══════════════════════════════════════════════════════════════════
# ACHE_INGEST.ps1 — Recolector Universal de Archivos ACHE
# φ=1.6180339887 · GONZAGA-CBM-Ω · COOPECRUCENOS R.L.
# Uso: .\ACHE_INGEST.ps1
# Genera: ACHE_INSUMOS_<fecha>.json con todo el ecosistema detectado
# ═══════════════════════════════════════════════════════════════════
param(
    [string]$OutputDir = ".",
    [switch]$AbrirResultado
)

$PHI = 1.6180339887
$FECHA = Get-Date -Format "yyyy-MM-dd_HH-mm"
$OUTPUT = Join-Path $OutputDir "ACHE_INSUMOS_$FECHA.json"

Write-Host ""
Write-Host "╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  φ ACHE INGEST · Recolector Universal de Ecosistema ACHE   ║" -ForegroundColor Cyan
Write-Host "║  GONZAGA-CBM-Ω · PCL-φ-1618 · COOPECRUCENOS R.L.          ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""

# ── Patrones de búsqueda ACHE ───────────────────────────────────────
$PATRONES_ACHE = @(
    "ACHE*.html", "NAHUA*.html", "aurora*.html", "hotel*.html",
    "ache*.py", "ache*.ps1", "ache*.json", "ache*.db",
    "ALMA*.html", "COSMOS*.html", "NEXUS*.html", "GENESIS*.html",
    "OMEGA*.html", "SUPREMO*.html", "MADRE*.html", "TRAILERO*.html",
    "CLAUDE.md", "ache_memory.db", "ache_universal.db",
    "boot.py", "main*.py", "ache_*.py"
)

$BUSCAR_EN = @(
    $env:USERPROFILE,
    "$env:USERPROFILE\Desktop",
    "$env:USERPROFILE\Downloads",
    "$env:USERPROFILE\Documents",
    "C:\ACHE",
    "C:\ACHE_UNIVERSAL",
    "$env:USERPROFILE\OneDrive",
    (Get-Location).Path
)

Write-Host "🔍 Buscando archivos ACHE en el sistema..." -ForegroundColor Yellow

$archivos_encontrados = @()
$total_size = 0

foreach ($dir in $BUSCAR_EN) {
    if (-not (Test-Path $dir)) { continue }
    Write-Host "  → Escaneando: $dir" -ForegroundColor DarkCyan
    
    foreach ($patron in $PATRONES_ACHE) {
        try {
            $files = Get-ChildItem -Path $dir -Filter $patron -Recurse -ErrorAction SilentlyContinue -Depth 5
            foreach ($f in $files) {
                $archivos_encontrados += $f
                $total_size += $f.Length
                Write-Host "    ✓ $($f.Name) ($([math]::Round($f.Length/1KB,1))KB)" -ForegroundColor Green
            }
        } catch {}
    }
}

Write-Host ""
Write-Host "📦 Total encontrado: $($archivos_encontrados.Count) archivos ($([math]::Round($total_size/1MB,2))MB)" -ForegroundColor Cyan

# ── Leer contenido de archivos HTML/PY/MD (no DB) ──────────────────
$insumos = @{
    meta = @{
        generado     = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        nodo         = "GONZAGA-CBM-Ω-001"
        phi          = $PHI
        entidad      = "COOPECRUCENOS R.L. · 3-004-757068"
        total_files  = $archivos_encontrados.Count
        total_kb     = [math]::Round($total_size/1KB, 1)
        version      = "INGEST-v1"
    }
    archivos = @()
    db_summary = @()
    config_detectada = @{}
}

foreach ($f in $archivos_encontrados) {
    $ext = $f.Extension.ToLower()
    $entry = @{
        nombre   = $f.Name
        ruta     = $f.FullName
        tamaño_kb = [math]::Round($f.Length/1KB, 1)
        modified = $f.LastWriteTime.ToString("yyyy-MM-dd HH:mm")
        tipo     = "binario"
        contenido = $null
    }
    
    # Leer contenido de archivos de texto
    if ($ext -in @('.html','.py','.ps1','.json','.md','.txt','.js','.css')) {
        try {
            $content = Get-Content $f.FullName -Raw -Encoding UTF8 -ErrorAction SilentlyContinue
            if ($content) {
                $entry.tipo = "texto"
                # Para HTML grandes solo leer primeras/últimas 200 líneas
                if ($f.Length -gt 200KB) {
                    $lines = $content -split "`n"
                    $entry.contenido = ($lines[0..199] -join "`n") + "`n...[TRUNCADO $($lines.Count) líneas total]...`n" + ($lines[-50..-1] -join "`n")
                    $entry.truncado = $true
                } else {
                    $entry.contenido = $content
                }
                
                # Detectar configuración en el archivo
                if ($content -match 'sinpe["\s:]+([0-9\-]+)') { $insumos.config_detectada.sinpe = $matches[1] }
                if ($content -match 'cedula["\s:]+([0-9\-]+)') { $insumos.config_detectada.cedula = $matches[1] }
                if ($content -match 'GONZAGA-CBM') { $entry.es_ache = $true }
            }
        } catch {
            $entry.tipo = "error_lectura"
        }
    } elseif ($ext -eq '.db') {
        $entry.tipo = "sqlite"
        # Intentar leer con sqlite3 si está disponible
        try {
            $sqlite = where.exe sqlite3 2>$null
            if ($sqlite) {
                $tables = & sqlite3 $f.FullName ".tables" 2>$null
                $entry.tablas_sql = $tables
            }
        } catch {}
    }
    
    $insumos.archivos += $entry
}

# ── Detectar entorno Python ─────────────────────────────────────────
Write-Host ""
Write-Host "🐍 Verificando entorno Python..." -ForegroundColor Yellow
try {
    $pyver = python --version 2>&1
    $insumos.meta.python = "$pyver"
    Write-Host "  ✓ $pyver" -ForegroundColor Green
    
    # Verificar paquetes ACHE
    $paquetes = @('fastapi','uvicorn','anthropic','requests','sqlite3')
    $pkgs_ok = @()
    foreach ($pkg in $paquetes) {
        $r = python -c "import $pkg; print('ok')" 2>&1
        if ($r -eq 'ok') { $pkgs_ok += $pkg }
    }
    $insumos.meta.python_packages = $pkgs_ok
    Write-Host "  ✓ Paquetes disponibles: $($pkgs_ok -join ', ')" -ForegroundColor Green
} catch {
    $insumos.meta.python = "no disponible"
}

# ── Detectar puertos activos ─────────────────────────────────────────
Write-Host "🔌 Verificando puertos ACHE..." -ForegroundColor Yellow
$puertos_ache = @(8080, 9000, 7777, 5000, 3001, 8090, 3000)
$puertos_activos = @()
foreach ($puerto in $puertos_ache) {
    try {
        $conn = Test-NetConnection -ComputerName localhost -Port $puerto -WarningAction SilentlyContinue -ErrorAction SilentlyContinue
        if ($conn.TcpTestSucceeded) {
            $puertos_activos += $puerto
            Write-Host "  ✓ Puerto $puerto ACTIVO" -ForegroundColor Green
        }
    } catch {}
}
$insumos.meta.puertos_activos = $puertos_activos

# ── Detectar API Keys en variables de entorno ───────────────────────
$api_vars = @('ANTHROPIC_API_KEY','GROQ_API_KEY','OPENAI_API_KEY')
$apis_detectadas = @()
foreach ($var in $api_vars) {
    $val = [Environment]::GetEnvironmentVariable($var)
    if ($val) {
        $apis_detectadas += @{ nombre=$var; tiene_key=$true; preview=$val.Substring(0,[Math]::Min(12,$val.Length))+"..." }
    }
}
$insumos.meta.apis_detectadas = $apis_detectadas

# ── Hardware info ────────────────────────────────────────────────────
try {
    $cpu = (Get-CimInstance Win32_Processor -ErrorAction SilentlyContinue).Name
    $ram = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory/1GB, 1)
    $insumos.meta.hardware = @{ cpu=$cpu; ram_gb=$ram; nodo="GONZAGA-CBM-Ω-001" }
} catch {}

# ── Exportar JSON ────────────────────────────────────────────────────
Write-Host ""
Write-Host "💾 Exportando insumos a: $OUTPUT" -ForegroundColor Yellow
$json = $insumos | ConvertTo-Json -Depth 10 -Compress:$false
[System.IO.File]::WriteAllText($OUTPUT, $json, [System.Text.Encoding]::UTF8)

$out_size = (Get-Item $OUTPUT).Length
Write-Host "  ✓ Exportado: $([math]::Round($out_size/1KB,1))KB" -ForegroundColor Green

# ── Resumen final ────────────────────────────────────────────────────
Write-Host ""
Write-Host "╔═══════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║  φ RECOLECCIÓN COMPLETADA                                  ║" -ForegroundColor Cyan
Write-Host "╠═══════════════════════════════════════════════════════════╣" -ForegroundColor Cyan
Write-Host "║  Archivos ACHE encontrados: $($archivos_encontrados.Count.ToString().PadRight(30))║" -ForegroundColor White
Write-Host "║  Tamaño total: $([math]::Round($total_size/1MB,2))MB$((' ' * (35 - "$([math]::Round($total_size/1MB,2))MB".Length)))║" -ForegroundColor White
Write-Host "║  Puertos activos: $($puertos_activos.Count)$((' ' * 39))║" -ForegroundColor White
Write-Host "║  APIs detectadas: $($apis_detectadas.Count)$((' ' * 39))║" -ForegroundColor White
Write-Host "║  Output: $($OUTPUT.Substring([Math]::Max(0,$OUTPUT.Length-45)))$((' ' * [Math]::Max(0,46-[Math]::Min(45,$OUTPUT.Length))))║" -ForegroundColor White
Write-Host "╚═══════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
Write-Host ""
Write-Host "💡 Siguiente paso: Abrí ACHE_ALMA_OMEGA_v1.html en Chrome/Edge" -ForegroundColor Yellow
Write-Host "   Luego ⚙ Config → pegá tu API Key de Groq (groq.com · GRATIS)" -ForegroundColor Yellow
Write-Host "   φ = $PHI · GONZAGA-CBM-Ω · Con amor para los niños del laboratorio ❤" -ForegroundColor Magenta
Write-Host ""

if ($AbrirResultado) {
    Start-Process $OUTPUT
}
