"""
╔══════════════════════════════════════════════════════════════════════════════╗
║  CHOROTEGA NEXUS SUPREMO v3.0                                              ║
║  El corazón del ecosistema. El puente hacia Claude.                        ║
║  COOPECRUCENOS R.L. · La Cruz, Guanacaste, Costa Rica                     ║
║  PCL-φ-1618 · GONZAGA-CBM-Ω-001                                           ║
║                                                                              ║
║  INSTALACIÓN:                                                                ║
║    pip install flask flask-cors flask-socketio requests python-dotenv       ║
║                                                                              ║
║  EJECUCIÓN:                                                                  ║
║    python nexus_supremo.py                                                  ║
║    python nexus_supremo.py --port 8080                                      ║
║    python nexus_supremo.py --dev  (debug mode)                             ║
║                                                                              ║
║  ENDPOINTS:                                                                  ║
║    /           → Info del nodo                                              ║
║    /health     → Estado del ecosistema                                      ║
║    /claude     → Proxy Claude API (el puente)                               ║
║    /groq        → Proxy Groq API                                             ║
║    /network    → Estado de todos los servicios ACHE                         ║
║    /memory     → KV store compartido                                        ║
║    /hotel      → API REST del hotel (reservas, habitaciones)               ║
║    /trailero   → API REST aduana Peñas Blancas                              ║
║    /chorotega  → Sirve CHOROTEGA_SUPREMO.html                               ║
║    /ws         → WebSocket (SocketIO) — sync real-time                     ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os, sys, time, json, logging, threading, hashlib
from datetime import datetime
from pathlib import Path

# ── ARGS ──────────────────────────────────────────────────────────────────────
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--port', type=int, default=8080)
parser.add_argument('--dev',  action='store_true')
args, _ = parser.parse_known_args()

# ── IMPORTS ───────────────────────────────────────────────────────────────────
try:
    from flask import Flask, request, jsonify, make_response, send_from_directory
    from flask_cors import CORS
    from flask_socketio import SocketIO, emit, join_room, leave_room
    import requests
except ImportError:
    print("\n  Instalando dependencias...")
    os.system(f"{sys.executable} -m pip install flask flask-cors flask-socketio requests --quiet")
    from flask import Flask, request, jsonify, make_response, send_from_directory
    from flask_cors import CORS
    from flask_socketio import SocketIO, emit, join_room, leave_room
    import requests

# Cargar .env si existe
ENV_FILE = Path(__file__).parent / "ache.env"
if ENV_FILE.exists():
    for line in ENV_FILE.read_text().splitlines():
        if line.strip() and not line.startswith('#') and '=' in line:
            k, v = line.split('=', 1)
            os.environ.setdefault(k.strip(), v.strip())

# ── CONFIGURACIÓN ─────────────────────────────────────────────────────────────
PORT          = args.port
DEV           = args.dev
BASE          = Path(__file__).parent
CLAUDE_KEY    = os.environ.get('ANTHROPIC_API_KEY', '')
GROQ_KEY      = os.environ.get('GROQ_API_KEY', '')
CLAUDE_MODEL  = 'claude-sonnet-4-20250514'
ENTITY        = 'COOPECRUCENOS R.L.'
CELULA        = 'GONZAGA-CBM-Ω-001'
REF           = 'PCL-φ-1618'

# Servidores ACHE en la red
ACHE_SERVICES = {
    'brain':    {'url': 'http://localhost:5099', 'name': 'ACHE BRAIN'},
    'universal':{'url': 'http://localhost:5600', 'name': 'ACHE UNIVERSAL'},
    'fase9':    {'url': 'http://localhost:5700', 'name': 'ACHE FASE9'},
    'meta':     {'url': 'http://localhost:5299', 'name': 'ACHE META'},
    'aurora':   {'url': 'http://localhost:7777', 'name': 'AURORA Suprema'},
    'central':  {'url': 'http://localhost:9999', 'name': 'ACHE CENTRAL'},
    'mobile':   {'url': 'http://localhost:3001', 'name': 'ACHE Mobile'},
}

# ── LOGGING ───────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.DEBUG if DEV else logging.INFO,
    format='%(asctime)s [NEXUS] %(levelname)s %(message)s',
    datefmt='%H:%M:%S'
)
log = logging.getLogger('CHOROTEGA-NEXUS')

# ── FLASK + SOCKETIO ──────────────────────────────────────────────────────────
app = Flask(__name__, static_folder=str(BASE), static_url_path='/static')
CORS(app, resources={r'/*': {
    'origins': '*',
    'methods': ['GET','POST','PUT','DELETE','OPTIONS','PATCH'],
    'allow_headers': ['Content-Type','Authorization','x-api-key','anthropic-version',
                      'anthropic-dangerous-direct-browser-access','Accept','Origin','X-Requested-With']
}})
socketio = SocketIO(app, cors_allowed_origins='*', async_mode='threading', logger=DEV, engineio_logger=DEV)

# ── SHA-256 CHAIN ─────────────────────────────────────────────────────────────
_chain: list[dict] = []
_chain_prev = '0' * 64

def chain_add(tipo: str, agente: str, payload: str) -> str:
    global _chain_prev
    ts    = datetime.now().isoformat()
    raw   = f"{_chain_prev}|{ts}|{tipo}|{agente}|{payload}"
    h     = hashlib.sha256(raw.encode()).hexdigest()
    entry = {'ts': ts, 'tipo': tipo, 'agente': agente, 'payload': payload[:120], 'hash': h, 'prev': _chain_prev[-16:]}
    _chain.append(entry)
    if len(_chain) > 500:
        _chain.pop(0)
    _chain_prev = h
    socketio.emit('chain_update', entry, namespace='/')
    return h

# ── MEMORIA COMPARTIDA ────────────────────────────────────────────────────────
_kv: dict = {}
_connected: dict = {}   # sid → {name, ip, cell}
_chat_history: list = []

# ── CORS HELPERS ──────────────────────────────────────────────────────────────
@app.after_request
def add_cors(r):
    r.headers['Access-Control-Allow-Origin']  = '*'
    r.headers['Access-Control-Allow-Methods'] = 'GET,POST,PUT,DELETE,OPTIONS,PATCH'
    r.headers['Access-Control-Allow-Headers'] = (
        'Content-Type,Authorization,x-api-key,anthropic-version,'
        'anthropic-dangerous-direct-browser-access,Accept,Origin,X-Requested-With'
    )
    r.headers['X-ACHE-Node']    = f'NEXUS:{PORT}'
    r.headers['X-ACHE-Version'] = '3.0'
    return r

@app.before_request
def preflight():
    if request.method == 'OPTIONS':
        r = make_response()
        r.headers['Access-Control-Allow-Origin']  = '*'
        r.headers['Access-Control-Allow-Methods'] = 'GET,POST,PUT,DELETE,OPTIONS'
        r.headers['Access-Control-Allow-Headers'] = (
            'Content-Type,Authorization,x-api-key,anthropic-version,'
            'anthropic-dangerous-direct-browser-access'
        )
        return r

# ══════════════════════════════════════════════════════════════════════════════
# RUTAS HTTP
# ══════════════════════════════════════════════════════════════════════════════

@app.route('/')
def root():
    return jsonify({
        'ache'    : 'CHOROTEGA NEXUS SUPREMO v3',
        'entity'  : ENTITY,
        'celula'  : CELULA,
        'ref'     : REF,
        'port'    : PORT,
        'status'  : 'online',
        'cors'    : 'all-origins',
        'claude'  : 'configured' if CLAUDE_KEY else 'missing',
        'groq'    : 'configured' if GROQ_KEY else 'missing',
        'ws'      : f'ws://localhost:{PORT}',
        'clients' : len(_connected),
        'time'    : datetime.now().isoformat(),
    })

@app.route('/health')
def health():
    svcs = {}
    for name, info in ACHE_SERVICES.items():
        try:
            r = requests.get(info['url'], timeout=1)
            svcs[name] = {'status': 'online', 'code': r.status_code}
        except:
            svcs[name] = {'status': 'offline'}
    return jsonify({
        'status'   : 'healthy',
        'ts'       : datetime.now().isoformat(),
        'nexus'    : f':{PORT}-ONLINE',
        'claude'   : 'configured' if CLAUDE_KEY else 'MISSING - configura ANTHROPIC_API_KEY',
        'groq'     : 'configured' if GROQ_KEY else 'MISSING - obtené clave gratis en console.groq.com',
        'clients'  : len(_connected),
        'chain_len': len(_chain),
        'services' : svcs,
    })

# ── CLAUDE PROXY — EL PUENTE ──────────────────────────────────────────────────
@app.route('/claude', methods=['POST','OPTIONS'])
def proxy_claude():
    """
    Proxy transparente hacia Anthropic API.
    Este es el puente entre CHOROTEGA y Claude.
    Permite que cualquier dispositivo en la red use Claude
    sin exponer la API key en el browser.
    """
    if request.method == 'OPTIONS':
        return make_response('', 200)

    d   = request.get_json(force=True, silent=True) or {}
    key = d.get('api_key') or CLAUDE_KEY

    if not key:
        return jsonify({
            'error': 'ANTHROPIC_API_KEY no configurada en el servidor.',
            'fix': 'Editá C:\\Chorotega\\ache.env y agrega ANTHROPIC_API_KEY=sk-ant-...',
            'alt': 'O pasá la key en el body: {"api_key":"sk-ant-...", "prompt":"..."}'
        }), 400

    model    = d.get('model', CLAUDE_MODEL)
    max_tok  = d.get('max_tokens', 1600)
    system   = d.get('system', f'Sos CHOROTEGA, la IA de {ENTITY}. La Cruz, Guanacaste, CR.')
    messages = d.get('messages') or [{'role': 'user', 'content': d.get('prompt', '')}]

    try:
        t0 = time.time()
        r  = requests.post(
            'https://api.anthropic.com/v1/messages',
            json    = {'model': model, 'max_tokens': max_tok, 'system': system, 'messages': messages},
            headers = {'x-api-key': key, 'anthropic-version': '2023-06-01', 'Content-Type': 'application/json'},
            timeout = 45
        )
        r.raise_for_status()
        rd    = r.json()
        reply = rd.get('content', [{}])[0].get('text', '')
        ms    = int((time.time() - t0) * 1000)
        usage = rd.get('usage', {})
        h     = chain_add('CLAUDE_CALL', 'NEXUS', f'model:{model} tok_in:{usage.get("input_tokens",0)} tok_out:{usage.get("output_tokens",0)}')

        log.info(f"Claude OK | {ms}ms | {usage} | hash:{h[:8]}")
        socketio.emit('claude_response', {'ms': ms, 'model': model, 'hash': h[:8]}, namespace='/')

        return jsonify({
            'reply'    : reply,
            'provider' : 'Claude',
            'model'    : model,
            'ms'       : ms,
            'usage'    : usage,
            'hash'     : h[:8],
        })

    except requests.exceptions.Timeout:
        log.error("Claude timeout")
        return jsonify({'error': 'Claude API timeout (45s)'}), 504
    except requests.exceptions.HTTPError as e:
        status_code = e.response.status_code if e.response else 500
        log.error(f"Claude HTTP {status_code}")
        return jsonify({'error': f'Claude API {status_code}'}), status_code
    except Exception as e:
        log.error(f"Claude error: {e}")
        return jsonify({'error': str(e)}), 500

# ── GROQ PROXY ────────────────────────────────────────────────────────────────
@app.route('/groq', methods=['POST','OPTIONS'])
def proxy_groq():
    if request.method == 'OPTIONS':
        return make_response('', 200)
    d      = request.get_json(force=True, silent=True) or {}
    key    = d.get('api_key') or GROQ_KEY
    if not key:
        return jsonify({'error': 'GROQ_API_KEY no configurada. Gratis en console.groq.com'}), 400
    model  = d.get('model', 'llama-3.3-70b-versatile')
    msgs   = d.get('messages') or [{'role': 'user', 'content': d.get('prompt', '')}]
    system = d.get('system', '')
    try:
        t0 = time.time()
        r  = requests.post(
            'https://api.groq.com/openai/v1/chat/completions',
            json    = {'model': model, 'max_tokens': d.get('max_tokens', 1400),
                       'messages': ([{'role':'system','content':system}] if system else []) + msgs},
            headers = {'Authorization': f'Bearer {key}', 'Content-Type': 'application/json'},
            timeout = 25
        )
        r.raise_for_status()
        rd    = r.json()
        reply = rd['choices'][0]['message']['content']
        ms    = int((time.time() - t0) * 1000)
        h     = chain_add('GROQ_CALL', 'NEXUS', f'model:{model}')
        log.info(f"Groq OK | {ms}ms")
        return jsonify({'reply': reply, 'provider': 'Groq', 'model': model, 'ms': ms, 'hash': h[:8]})
    except Exception as e:
        log.error(f"Groq error: {e}")
        return jsonify({'error': str(e)}), 500

# ── NETWORK STATUS ────────────────────────────────────────────────────────────
@app.route('/network')
def network():
    results = {}
    for name, info in ACHE_SERVICES.items():
        t0 = time.time()
        try:
            r = requests.get(info['url'], timeout=1.5)
            results[name] = {'url': info['url'], 'name': info['name'],
                             'status': 'online', 'ms': int((time.time()-t0)*1000), 'code': r.status_code}
        except requests.exceptions.ConnectionError:
            results[name] = {'url': info['url'], 'name': info['name'], 'status': 'offline', 'ms': -1}
        except:
            results[name] = {'url': info['url'], 'name': info['name'], 'status': 'error', 'ms': -1}
    online = sum(1 for v in results.values() if v['status'] == 'online')
    return jsonify({
        'ts': datetime.now().isoformat(), 'nexus': f':{PORT}',
        'online': online, 'total': len(ACHE_SERVICES), 'services': results,
        'clients_ws': len(_connected), 'chain_len': len(_chain),
    })

# ── MEMORIA KV ────────────────────────────────────────────────────────────────
@app.route('/memory', methods=['GET','POST','DELETE'])
def memory():
    if request.method == 'GET':
        k = request.args.get('key')
        return jsonify({k: _kv.get(k)} if k else _kv)
    if request.method == 'DELETE':
        k = request.args.get('key')
        if k and k in _kv:
            del _kv[k]
            return jsonify({'ok': True, 'deleted': k})
        return jsonify({'error': 'key no encontrada'}), 404
    d = request.get_json(force=True, silent=True) or {}
    if not d.get('key'):
        return jsonify({'error': 'key requerida'}), 400
    _kv[d['key']] = d.get('value')
    chain_add('MEMORY_SET', request.remote_addr or 'unknown', d['key'])
    socketio.emit('memory_update', {'key': d['key']}, namespace='/')
    return jsonify({'ok': True, 'key': d['key']})

# ── HOTEL API ─────────────────────────────────────────────────────────────────
_HABS = [
    {'id':1,'num':'101','tipo':'Estándar Simple','cap':2,'base':18000,'estado':'libre'},
    {'id':2,'num':'102','tipo':'Estándar Doble','cap':4,'base':25000,'estado':'libre'},
    {'id':3,'num':'103','tipo':'Estándar Doble','cap':4,'base':25000,'estado':'libre'},
    {'id':4,'num':'104','tipo':'Familiar','cap':5,'base':35000,'estado':'libre'},
    {'id':5,'num':'105','tipo':'Familiar','cap':5,'base':35000,'estado':'ocupada'},
    {'id':6,'num':'201','tipo':'Superior Doble','cap':4,'base':32000,'estado':'libre'},
    {'id':7,'num':'202','tipo':'Superior Doble','cap':4,'base':32000,'estado':'libre'},
    {'id':8,'num':'203','tipo':'Suite Junior','cap':4,'base':48000,'estado':'ocupada'},
    {'id':9,'num':'204','tipo':'Suite Junior','cap':4,'base':48000,'estado':'libre'},
    {'id':10,'num':'205','tipo':'Suite Familiar','cap':5,'base':58000,'estado':'libre'},
    {'id':11,'num':'301','tipo':'Suite Ejecutiva','cap':3,'base':65000,'estado':'libre'},
    {'id':12,'num':'302','tipo':'Penthouse','cap':5,'base':85000,'estado':'mantenimiento'},
    {'id':13,'num':'303','tipo':'Accesible','cap':4,'base':22000,'estado':'libre'},
]
_RESERVAS: list[dict] = []

@app.route('/hotel', methods=['GET'])
def hotel_get():
    libres = sum(1 for h in _HABS if h['estado'] == 'libre')
    return jsonify({'habitaciones': _HABS, 'reservas': _RESERVAS,
                    'libres': libres, 'total': len(_HABS), 'sinpe': '8301-0520'})

@app.route('/hotel/reserva', methods=['POST'])
def hotel_reserva():
    d = request.get_json(force=True, silent=True) or {}
    hab = next((h for h in _HABS if h['id'] == d.get('hab_id')), None)
    if not hab:
        return jsonify({'error': 'Habitación no encontrada'}), 404
    if hab['estado'] != 'libre':
        return jsonify({'error': f"Habitación {hab['num']} no está libre"}), 409
    ci = d.get('checkin'); co = d.get('checkout')
    if not ci or not co or not d.get('nombre'):
        return jsonify({'error': 'Faltan campos: nombre, checkin, checkout'}), 400
    from datetime import date
    try:
        nights = (date.fromisoformat(co) - date.fromisoformat(ci)).days
    except:
        return jsonify({'error': 'Fechas inválidas (formato YYYY-MM-DD)'}), 400
    if nights <= 0:
        return jsonify({'error': 'checkout debe ser posterior a checkin'}), 400
    sub = hab['base'] * nights; iva = round(sub * 0.13, 2); total = sub + iva
    rid = f"RES-{int(time.time())}"
    raw = f"{rid}|{d.get('nombre')}|{ci}|{co}|{total}"
    h   = hashlib.sha256(raw.encode()).hexdigest()[:16].upper()
    res = {'id': rid, 'hab_id': hab['id'], 'hab_num': hab['num'],
           'nombre': d['nombre'], 'cedula': d.get('cedula',''),
           'email': d.get('email',''), 'tel': d.get('tel',''),
           'checkin': ci, 'checkout': co, 'noches': nights,
           'subtotal': sub, 'iva': iva, 'total': total,
           'estado': 'activa', 'hash': h, 'ts': datetime.now().isoformat()}
    _RESERVAS.append(res)
    hab['estado'] = 'ocupada'
    chain_add('HOTEL_RESERVA', 'API', f"hab:{hab['num']} cliente:{d['nombre']} total:{total}")
    socketio.emit('hotel_update', {'tipo':'reserva','hab':hab['num'],'nombre':d['nombre']}, namespace='/')
    log.info(f"Reserva: Hab.{hab['num']} → {d['nombre']} ({nights}n) ₡{total:,.0f}")
    return jsonify({'ok': True, 'reserva': res, 'mensaje': f"Reserva confirmada. Total: ₡{total:,.0f}. SINPE: 8301-0520"})

@app.route('/hotel/reserva/<rid>', methods=['DELETE'])
def hotel_cancel(rid):
    res = next((r for r in _RESERVAS if r['id'] == rid), None)
    if not res:
        return jsonify({'error': 'Reserva no encontrada'}), 404
    res['estado'] = 'cancelada'
    hab = next((h for h in _HABS if h['id'] == res['hab_id']), None)
    if hab:
        hab['estado'] = 'libre'
    chain_add('HOTEL_CANCEL', 'API', f"res:{rid}")
    socketio.emit('hotel_update', {'tipo': 'cancelacion', 'res': rid}, namespace='/')
    return jsonify({'ok': True, 'mensaje': 'Reserva cancelada'})

# ── TRAILERO API ──────────────────────────────────────────────────────────────
_MANIFIESTOS: list[dict] = []
_WAIT_TIME   = {'minutos': 35, 'updated': datetime.now().isoformat(), 'estado': 'normal'}

@app.route('/trailero', methods=['GET'])
def trailero_get():
    activos = [m for m in _MANIFIESTOS if m['estado'] in ('pendiente','en_proceso')]
    return jsonify({
        'frontera'  : 'Peñas Blancas · Costa Rica / Nicaragua',
        'horario'   : '06:00 - 22:00 (DUCA) · 24h (personas)',
        'espera'    : _WAIT_TIME,
        'manifiestos': activos,
        'total_hoy' : len(_MANIFIESTOS),
        'sinpe'     : '8301-0520',
    })

@app.route('/trailero/manifiesto', methods=['POST'])
def trailero_manifiesto():
    d  = request.get_json(force=True, silent=True) or {}
    mid = f"DUCA-{datetime.now().strftime('%y%m%d')}-{len(_MANIFIESTOS)+1:04d}"
    h   = hashlib.sha256(f"{mid}{d.get('placa','')}{d.get('mercancia','')}".encode()).hexdigest()[:12].upper()
    m   = {
        'id': mid, 'placa': d.get('placa',''), 'conductor': d.get('conductor',''),
        'cedula': d.get('cedula',''), 'empresa': d.get('empresa',''),
        'mercancia': d.get('mercancia',''), 'peso_kg': d.get('peso_kg',0),
        'origen': d.get('origen','Nicaragua'), 'destino': d.get('destino','Costa Rica'),
        'valor_usd': d.get('valor_usd',0), 'estado': 'pendiente',
        'hash': h, 'ts': datetime.now().isoformat(),
    }
    _MANIFIESTOS.append(m)
    chain_add('TRAILERO_DUCA', 'API', f"placa:{m['placa']} mercanica:{m['mercancia'][:40]}")
    socketio.emit('trailero_update', {'tipo': 'nuevo_manifiesto', 'id': mid, 'placa': m['placa']}, namespace='/')
    log.info(f"DUCA: {mid} | {m['placa']} | {m['mercancia'][:30]}")
    return jsonify({'ok': True, 'id': mid, 'hash': h, 'manifiesto': m,
                    'mensaje': f"Manifiesto {mid} registrado. Estado: pendiente de revisión."})

@app.route('/trailero/espera', methods=['GET','POST'])
def trailero_espera():
    global _WAIT_TIME
    if request.method == 'POST':
        d = request.get_json(force=True, silent=True) or {}
        _WAIT_TIME = {'minutos': d.get('minutos', _WAIT_TIME['minutos']),
                      'estado': d.get('estado', _WAIT_TIME['estado']),
                      'updated': datetime.now().isoformat()}
        socketio.emit('espera_update', _WAIT_TIME, namespace='/')
        return jsonify({'ok': True, 'espera': _WAIT_TIME})
    return jsonify(_WAIT_TIME)

# ── SHA CHAIN ─────────────────────────────────────────────────────────────────
@app.route('/chain')
def get_chain():
    limit = int(request.args.get('limit', 50))
    return jsonify({'chain': _chain[-limit:], 'total': len(_chain), 'latest': _chain[-1] if _chain else None})

# ── SERVIR ARCHIVOS ───────────────────────────────────────────────────────────
@app.route('/chorotega')
@app.route('/v2')
@app.route('/v3')
@app.route('/trailero-ui')
@app.route('/dashboard')
def serve_html():
    files = {
        '/v2': 'CHOROTEGA_v2.html',
        '/v3': 'CHOROTEGA_v3_OMEGA.html',
        '/trailero-ui': 'CHOROTEGA_TRAILERO.html',
    }
    fname = files.get(request.path, 'CHOROTEGA_SUPREMO.html')
    try:
        return send_from_directory(str(BASE), fname)
    except:
        return jsonify({'error': f'{fname} no encontrado en {BASE}',
                        'tip': f'Copiá {fname} a {BASE}'}), 404

@app.route('/<path:filename>')
def serve_static(filename):
    try:
        return send_from_directory(str(BASE), filename)
    except:
        return jsonify({'error': f'{filename} no encontrado'}), 404

# ══════════════════════════════════════════════════════════════════════════════
# WEBSOCKET — SYNC EN TIEMPO REAL ENTRE MÁQUINAS
# ══════════════════════════════════════════════════════════════════════════════

@socketio.on('connect')
def ws_connect():
    sid  = request.sid
    ip   = request.remote_addr or 'unknown'
    name = request.args.get('name', f'CÉLULA-{sid[:6]}')
    cell = request.args.get('cell', 'unknown')
    _connected[sid] = {'name': name, 'ip': ip, 'cell': cell, 'ts': datetime.now().isoformat()}
    log.info(f"WS CONNECT: {name} ({ip}) | Células activas: {len(_connected)}")
    chain_add('WS_CONNECT', name, f"ip:{ip} cell:{cell}")
    emit('welcome', {
        'msg'    : f'Bienvenido a CHOROTEGA NEXUS v3, {name}. La Cruz, Guanacaste te recibe.',
        'clients': len(_connected),
        'celula' : CELULA,
        'chain'  : len(_chain),
        'hotel'  : {'libres': sum(1 for h in _HABS if h['estado'] == 'libre'), 'total': len(_HABS)},
    })
    socketio.emit('client_joined', {
        'name': name, 'ip': ip, 'cell': cell, 'clients': len(_connected)
    }, skip_sid=sid)

@socketio.on('disconnect')
def ws_disconnect():
    sid  = request.sid
    info = _connected.pop(sid, {'name': 'desconocido'})
    log.info(f"WS DISCONNECT: {info.get('name')} | Restantes: {len(_connected)}")
    socketio.emit('client_left', {'name': info.get('name'), 'clients': len(_connected)})

@socketio.on('chat_message')
def ws_chat(data):
    """Broadcast de mensajes de chat entre todas las células conectadas"""
    data['from_cell'] = _connected.get(request.sid, {}).get('name', 'unknown')
    data['ts']        = datetime.now().isoformat()
    _chat_history.append(data)
    if len(_chat_history) > 200:
        _chat_history.pop(0)
    emit('chat_message', data, broadcast=True, include_self=False)

@socketio.on('hotel_sync')
def ws_hotel_sync(data):
    """Sincronizar estado del hotel entre GONZAGA y Nicoya"""
    tipo = data.get('tipo')
    if tipo == 'request':
        emit('hotel_state', {
            'habs'    : _HABS,
            'reservas': [r for r in _RESERVAS if r['estado'] == 'activa'],
        })
    elif tipo == 'update' and data.get('habs'):
        socketio.emit('hotel_state', data, broadcast=True, include_self=False)

@socketio.on('trailero_sync')
def ws_trailero(data):
    """Sincronizar manifiestos de aduana"""
    socketio.emit('trailero_update', data, broadcast=True, include_self=False)

@socketio.on('ping_ache')
def ws_ping(data):
    emit('pong_ache', {'ts': datetime.now().isoformat(), 'clients': len(_connected), 'chain': len(_chain)})

@socketio.on('broadcast_all')
def ws_broadcast(data):
    """Envía mensaje a todas las células conectadas"""
    data['from']  = _connected.get(request.sid, {}).get('name', 'unknown')
    data['ts']    = datetime.now().isoformat()
    chain_add('BROADCAST', data['from'], str(data.get('msg',''))[:80])
    socketio.emit('broadcast_msg', data)

# ── AUTO-HEAL BACKGROUND ──────────────────────────────────────────────────────
def auto_heal():
    """Verifica el estado del ecosistema cada 60s y alerta por WebSocket"""
    while True:
        time.sleep(60)
        problems = []
        if not CLAUDE_KEY:
            problems.append('ANTHROPIC_API_KEY no configurada')
        if not GROQ_KEY:
            problems.append('GROQ_API_KEY no configurada')
        for name, info in ACHE_SERVICES.items():
            try:
                requests.get(info['url'], timeout=1)
            except:
                pass  # services offline is normal
        if problems:
            socketio.emit('health_warning', {'problems': problems, 'ts': datetime.now().isoformat()})

threading.Thread(target=auto_heal, daemon=True).start()

# ── MAIN ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    import socket
    try:
        ip = socket.gethostbyname(socket.gethostname())
    except:
        ip = '127.0.0.1'

    print(f"""
  ╔══════════════════════════════════════════════════════════════════════╗
  ║  CHOROTEGA NEXUS SUPREMO v3.0 · EL PUENTE                         ║
  ║  COOPECRUCENOS R.L. · La Cruz, Guanacaste, Costa Rica             ║
  ╠══════════════════════════════════════════════════════════════════════╣
  ║  Local:    http://localhost:{PORT}/chorotega                          ║
  ║  LAN:      http://{ip}:{PORT}/chorotega                   ║
  ║  Nicoya:   http://{ip}:{PORT}/chorotega  (misma URL)      ║
  ║  API:      http://localhost:{PORT}/claude  (PUENTE A CLAUDE)         ║
  ║  WS:       ws://localhost:{PORT}                                      ║
  ╠══════════════════════════════════════════════════════════════════════╣
  ║  Claude:   {"CONFIGURADO ✓" if CLAUDE_KEY else "FALTA — ache.env → ANTHROPIC_API_KEY=sk-ant-...":<42}  ║
  ║  Groq:     {"CONFIGURADO ✓" if GROQ_KEY else "FALTA — ache.env → GROQ_API_KEY=gsk_...    ":<42}  ║
  ╚══════════════════════════════════════════════════════════════════════╝
    """)

    chain_add('NEXUS_BOOT', 'SISTEMA', f'v3.0 port:{PORT} claude:{"ok" if CLAUDE_KEY else "missing"}')

    socketio.run(app, host='0.0.0.0', port=PORT, debug=DEV, allow_unsafe_werkzeug=True)
